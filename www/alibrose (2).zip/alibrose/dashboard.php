<?php

date_default_timezone_set('Asia/Kolkata');

require_once 'includes/auth.php';
require_once 'config/db.php';

$page_title = 'Dashboard';

function getInstallmentDueDate($openingDate, $plan, $installmentNo)
{
    $opening = new DateTime(
        $openingDate,
        new DateTimeZone('Asia/Kolkata')
    );

    if ($plan === 'Monthly') {

        $day = (int)$opening->format('d');

        if ($day <= 10) {

            $due = new DateTime(
                $opening->format('Y-m-10'),
                new DateTimeZone('Asia/Kolkata')
            );

        } else {

            $due = new DateTime(
                $opening->format('Y-m-01'),
                new DateTimeZone('Asia/Kolkata')
            );

            $due->modify('+1 month');

            $due->setDate(
                (int)$due->format('Y'),
                (int)$due->format('m'),
                10
            );
        }

        if ($installmentNo > 1) {

            $due->modify(
                '+' . ($installmentNo - 1) . ' months'
            );
        }

        return $due->format('Y-m-d');
    }

    $opening->modify('+7 days');

    if ($installmentNo > 1) {

        $opening->modify(
            '+' . (($installmentNo - 1) * 7) . ' days'
        );
    }

    return $opening->format('Y-m-d');
}

$today = new DateTime(
    'today',
    new DateTimeZone('Asia/Kolkata')
);

$todayDate = $today->format('Y-m-d');

$currentMonth = $today->format('Y-m');

$currentWeek = $today->format('o-W');

$customers = [];

$payments = [];

$customerResult = $conn->query("
    SELECT
        id,
        name,
        phone,
        opening_date,
        plan,
        amount,
        paid_installments,
        total_installments,
        status
    FROM customers
    ORDER BY id DESC
");

while ($row = $customerResult->fetch_assoc()) {

    $customers[] = $row;
}

$paymentResult = $conn->query("
    SELECT
        customer_id,
        installment_no,
        amount,
        payment_date,
        due_date
    FROM installment_payments
    ORDER BY id ASC
");

while ($row = $paymentResult->fetch_assoc()) {

    $customerId = (int)$row['customer_id'];

    $installmentNo = (int)$row['installment_no'];

    $payments[$customerId][$installmentNo] = $row;
}

$totalCustomers = count($customers);

$monthlyCustomers = 0;

$weeklyCustomers = 0;

$monthlyAllTimeCollection = 0;

$weeklyAllTimeCollection = 0;

$todayMonthlyCollection = 0;

$todayWeeklyCollection = 0;

$thisMonthMonthlyCollection = 0;

$thisWeekWeeklyCollection = 0;

$monthlyReceived = 0;

$weeklyReceived = 0;

$monthlyDue = 0;

$weeklyDue = 0;

$monthlyExpected = 0;

$weeklyExpected = 0;

$monthlyDueInstallments = 0;

$weeklyDueInstallments = 0;

$monthlyPaidInstallments = 0;

$weeklyPaidInstallments = 0;

$monthlyTotalInstallments = 0;

$weeklyTotalInstallments = 0;

foreach ($customers as $customer) {

    $customerId = (int)$customer['id'];

    $plan = $customer['plan'];

    $amount = (float)$customer['amount'];

    $openingDate = $customer['opening_date'];

    if ($plan === 'Monthly') {

        $monthlyCustomers++;

        $totalInstallments = 12;

        $monthlyTotalInstallments += 12;

    } else {

        $weeklyCustomers++;

        $totalInstallments = 52;

        $weeklyTotalInstallments += 52;
    }

    if (isset($payments[$customerId])) {

        foreach (
            $payments[$customerId]
            as $payment
        ) {

            $paymentAmount =
                (float)$payment['amount'];

            $paymentDate =
                $payment['payment_date'];

            if ($plan === 'Monthly') {

                $monthlyAllTimeCollection +=
                    $paymentAmount;

                $monthlyPaidInstallments++;

                if (
                    !empty($paymentDate) &&
                    $paymentDate === $todayDate
                ) {

                    $todayMonthlyCollection +=
                        $paymentAmount;
                }

                if (
                    !empty($paymentDate) &&
                    date(
                        'Y-m',
                        strtotime($paymentDate)
                    ) === $currentMonth
                ) {

                    $thisMonthMonthlyCollection +=
                        $paymentAmount;

                    $monthlyReceived +=
                        $paymentAmount;
                }

            } else {

                $weeklyAllTimeCollection +=
                    $paymentAmount;

                $weeklyPaidInstallments++;

                if (
                    !empty($paymentDate) &&
                    $paymentDate === $todayDate
                ) {

                    $todayWeeklyCollection +=
                        $paymentAmount;
                }

                if (
                    !empty($paymentDate) &&
                    date(
                        'o-W',
                        strtotime($paymentDate)
                    ) === $currentWeek
                ) {

                    $thisWeekWeeklyCollection +=
                        $paymentAmount;

                    $weeklyReceived +=
                        $paymentAmount;
                }
            }
        }
    }

    if (empty($openingDate)) {

        continue;
    }

    for (
        $installmentNo = 1;
        $installmentNo <= $totalInstallments;
        $installmentNo++
    ) {

        $dueDate =
            getInstallmentDueDate(
                $openingDate,
                $plan,
                $installmentNo
            );

        if ($dueDate > $todayDate) {

            continue;
        }

        if (
            isset(
                $payments[$customerId][$installmentNo]
            )
        ) {

            continue;
        }

        if ($plan === 'Monthly') {

            $monthlyExpected +=
                $amount;

            $monthlyDue +=
                $amount;

            $monthlyDueInstallments++;

        } else {

            $weeklyExpected +=
                $amount;

            $weeklyDue +=
                $amount;

            $weeklyDueInstallments++;
        }
    }
}

$monthlyExpected +=
    $monthlyReceived;

$weeklyExpected +=
    $weeklyReceived;

$monthlyProgress = 0;

if ($monthlyExpected > 0) {

    $monthlyProgress =
        (
            $monthlyReceived /
            $monthlyExpected
        ) * 100;
}

$monthlyProgress =
    min(
        100,
        max(
            0,
            $monthlyProgress
        )
    );

$weeklyProgress = 0;

if ($weeklyExpected > 0) {

    $weeklyProgress =
        (
            $weeklyReceived /
            $weeklyExpected
        ) * 100;
}

$weeklyProgress =
    min(
        100,
        max(
            0,
            $weeklyProgress
        )
    );

$todayTotalCollection =
    $todayMonthlyCollection +
    $todayWeeklyCollection;

$recentPayments = $conn->query("
    SELECT
        ip.id,
        ip.amount,
        ip.installment_no,
        ip.payment_date,
        ip.due_date,
        c.name,
        c.phone,
        c.plan
    FROM installment_payments ip
    INNER JOIN customers c
        ON c.id = ip.customer_id
    ORDER BY ip.id DESC
    LIMIT 10
");

include 'includes/header.php';

?>

<style>

.dashboard-title{
    font-size:29px;
    font-weight:850;
    letter-spacing:-.8px;
}

.dashboard-subtitle{
    color:#6b756e;
    font-size:13px;
}

.stat-card{
    background:#fff;
    border:1px solid #e7ece9;
    border-radius:20px;
    padding:22px;
    height:100%;
    box-shadow:0 10px 30px rgba(9,18,12,.055);
    position:relative;
    overflow:hidden;
    transition:.25s;
}

.stat-card:hover{
    transform:translateY(-3px);
    box-shadow:0 16px 38px rgba(9,18,12,.09);
}

.stat-card:after{
    content:"";
    position:absolute;
    width:120px;
    height:120px;
    border-radius:50%;
    right:-55px;
    top:-55px;
    background:#eaf8ef;
}

.stat-icon{
    width:50px;
    height:50px;
    border-radius:15px;
    display:flex;
    align-items:center;
    justify-content:center;
    background:#eaf8ef;
    color:#16a34a;
    font-size:22px;
    position:relative;
    z-index:1;
}

.stat-label{
    color:#6f7a73;
    font-size:11px;
    font-weight:650;
}

.stat-value{
    font-size:25px;
    font-weight:850;
    margin-top:6px;
}

.stat-note{
    color:#87918b;
    font-size:10px;
    margin-top:4px;
}

.today-card{
    background:
        linear-gradient(
            135deg,
            #050806,
            #0d2015,
            #166534
        );
    color:#fff;
    border:0;
}

.today-card:after{
    background:rgba(34,197,94,.10);
}

.today-card .stat-label{
    color:#a9c3b0;
}

.today-card .stat-note{
    color:#8fa99a;
}

.today-card .stat-value{
    color:#fff;
}

.today-card .stat-icon{
    background:rgba(255,255,255,.09);
    color:#4ade80;
}

.collection-card{
    background:#fff;
    border:1px solid #e7ece9;
    border-radius:22px;
    padding:25px;
    height:100%;
    box-shadow:0 10px 30px rgba(9,18,12,.055);
}

.collection-card-dark{
    background:
        linear-gradient(
            135deg,
            #050806,
            #0b1810,
            #14532d
        );
    border:0;
    color:#fff;
    box-shadow:0 15px 35px rgba(5,20,10,.13);
}

.collection-title{
    font-size:18px;
    font-weight:850;
}

.collection-subtitle{
    color:#78837c;
    font-size:11px;
}

.collection-card-dark
.collection-subtitle{
    color:#9db5a5;
}

.big-amount{
    font-size:31px;
    font-weight:900;
    margin-top:18px;
}

.green-amount{
    color:#15803d;
}

.light-green{
    color:#4ade80;
}

.info-box{
    background:#f7faf8;
    border:1px solid #edf2ee;
    border-radius:15px;
    padding:15px;
}

.collection-card-dark
.info-box{
    background:rgba(255,255,255,.06);
    border-color:rgba(255,255,255,.08);
}

.info-label{
    color:#738078;
    font-size:10px;
}

.collection-card-dark
.info-label{
    color:#98afa0;
}

.info-value{
    font-size:18px;
    font-weight:800;
    margin-top:5px;
}

.info-value.due{
    color:#dc2626;
}

.collection-card-dark
.info-value.due{
    color:#fca5a5;
}

.info-value.success{
    color:#15803d;
}

.collection-card-dark
.info-value.success{
    color:#4ade80;
}

.progress-wrap{
    height:8px;
    background:#e8efea;
    border-radius:20px;
    overflow:hidden;
}

.collection-card-dark
.progress-wrap{
    background:rgba(255,255,255,.10);
}

.progress-fill{
    height:100%;
    border-radius:20px;
    background:
        linear-gradient(
            90deg,
            #15803d,
            #22c55e
        );
}

.collection-card-dark
.progress-fill{
    background:#4ade80;
}

.section-card{
    background:#fff;
    border:1px solid #e7ece9;
    border-radius:22px;
    padding:25px;
    box-shadow:0 10px 30px rgba(9,18,12,.05);
}

.section-title{
    font-size:17px;
    font-weight:850;
}

.section-subtitle{
    color:#78837c;
    font-size:11px;
}

.payment-table{
    width:100%;
}

.payment-table th{
    color:#738078;
    font-size:11px;
    font-weight:750;
    padding:13px 10px;
    border-bottom:1px solid #edf1ee;
}

.payment-table td{
    padding:14px 10px;
    font-size:12px;
    border-bottom:1px solid #f0f3f1;
}

.payment-table tr:last-child td{
    border-bottom:0;
}

.avatar-small{
    width:36px;
    height:36px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    border-radius:50%;
    background:#dcfce7;
    color:#15803d;
    font-weight:800;
    margin-right:8px;
}

.plan-badge{
    display:inline-flex;
    align-items:center;
    gap:5px;
    padding:5px 10px;
    border-radius:20px;
    font-size:10px;
    font-weight:750;
}

.monthly-badge{
    background:#dcfce7;
    color:#15803d;
}

.weekly-badge{
    background:#d1fae5;
    color:#047857;
}

@media(max-width:767px){

    .dashboard-title{
        font-size:24px;
    }

    .big-amount{
        font-size:25px;
    }

}

</style>

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <div class="dashboard-title">
            Dashboard
        </div>

        <div class="dashboard-subtitle">
            Monthly & Weekly collection overview
        </div>

    </div>

    <div class="text-end">

        <div class="small muted">
            Today
        </div>

        <strong>
            <?= date('d M Y') ?>
        </strong>

    </div>

</div>

<div class="row g-4 mb-4">

    <div class="col-xl-3 col-md-6">

        <div class="stat-card">

            <div class="d-flex justify-content-between">

                <div>

                    <div class="stat-label">
                        TOTAL CUSTOMERS
                    </div>

                    <div class="stat-value">
                        <?= number_format(
                            $totalCustomers
                        ) ?>
                    </div>

                    <div class="stat-note">
                        All customers
                    </div>

                </div>

                <div class="stat-icon">
                    <i class="bi bi-people-fill"></i>
                </div>

            </div>

        </div>

    </div>

    <div class="col-xl-3 col-md-6">

        <div class="stat-card">

            <div class="d-flex justify-content-between">

                <div>

                    <div class="stat-label">
                        MONTHLY CUSTOMERS
                    </div>

                    <div class="stat-value">
                        <?= number_format(
                            $monthlyCustomers
                        ) ?>
                    </div>

                    <div class="stat-note">
                        Monthly plan only
                    </div>

                </div>

                <div class="stat-icon">
                    <i class="bi bi-calendar-month-fill"></i>
                </div>

            </div>

        </div>

    </div>

    <div class="col-xl-3 col-md-6">

        <div class="stat-card">

            <div class="d-flex justify-content-between">

                <div>

                    <div class="stat-label">
                        WEEKLY CUSTOMERS
                    </div>

                    <div class="stat-value">
                        <?= number_format(
                            $weeklyCustomers
                        ) ?>
                    </div>

                    <div class="stat-note">
                        Weekly plan only
                    </div>

                </div>

                <div class="stat-icon">
                    <i class="bi bi-calendar-week-fill"></i>
                </div>

            </div>

        </div>

    </div>

    <div class="col-xl-3 col-md-6">

        <div class="stat-card">

            <div class="d-flex justify-content-between">

                <div>

                    <div class="stat-label">
                        TODAY TOTAL
                    </div>

                    <div class="stat-value">
                        ₹<?= number_format(
                            $todayTotalCollection,
                            2
                        ) ?>
                    </div>

                    <div class="stat-note">
                        <?= date('d M Y') ?>
                    </div>

                </div>

                <div class="stat-icon">
                    <i class="bi bi-cash-stack"></i>
                </div>

            </div>

        </div>

    </div>

</div>

<div class="row g-4 mb-4">

    <div class="col-xl-3 col-md-6">

        <div class="stat-card today-card">

            <div class="d-flex justify-content-between">

                <div>

                    <div class="stat-label">
                        TODAY MONTHLY
                    </div>

                    <div class="stat-value">
                        ₹<?= number_format(
                            $todayMonthlyCollection,
                            2
                        ) ?>
                    </div>

                    <div class="stat-note">
                        Monthly payments today
                    </div>

                </div>

                <div class="stat-icon">
                    <i class="bi bi-calendar-month-fill"></i>
                </div>

            </div>

        </div>

    </div>

    <div class="col-xl-3 col-md-6">

        <div class="stat-card today-card">

            <div class="d-flex justify-content-between">

                <div>

                    <div class="stat-label">
                        TODAY WEEKLY
                    </div>

                    <div class="stat-value">
                        ₹<?= number_format(
                            $todayWeeklyCollection,
                            2
                        ) ?>
                    </div>

                    <div class="stat-note">
                        Weekly payments today
                    </div>

                </div>

                <div class="stat-icon">
                    <i class="bi bi-calendar-week-fill"></i>
                </div>

            </div>

        </div>

    </div>

    <div class="col-xl-3 col-md-6">

        <div class="stat-card">

            <div class="d-flex justify-content-between">

                <div>

                    <div class="stat-label">
                        THIS MONTH MONTHLY
                    </div>

                    <div class="stat-value">
                        ₹<?= number_format(
                            $thisMonthMonthlyCollection,
                            2
                        ) ?>
                    </div>

                    <div class="stat-note">
                        <?= date('F Y') ?>
                    </div>

                </div>

                <div class="stat-icon">
                    <i class="bi bi-graph-up-arrow"></i>
                </div>

            </div>

        </div>

    </div>

    <div class="col-xl-3 col-md-6">

        <div class="stat-card">

            <div class="d-flex justify-content-between">

                <div>

                    <div class="stat-label">
                        THIS WEEK WEEKLY
                    </div>

                    <div class="stat-value">
                        ₹<?= number_format(
                            $thisWeekWeeklyCollection,
                            2
                        ) ?>
                    </div>

                    <div class="stat-note">
                        Current week
                    </div>

                </div>

                <div class="stat-icon">
                    <i class="bi bi-graph-up-arrow"></i>
                </div>

            </div>

        </div>

    </div>

</div>

<div class="row g-4 mb-4">

    <div class="col-xl-6">

        <div class="collection-card">

            <div class="d-flex justify-content-between align-items-start">

                <div>

                    <div class="collection-title">
                        Monthly Collection
                    </div>

                    <div class="collection-subtitle">
                        Only Monthly customers · <?= date('F Y') ?>
                    </div>

                </div>

                <div class="stat-icon">
                    <i class="bi bi-calendar-month-fill"></i>
                </div>

            </div>

            <div class="big-amount green-amount">

                ₹<?= number_format(
                    $thisMonthMonthlyCollection,
                    2
                ) ?>

            </div>

            <div class="collection-subtitle">
                Current month received collection
            </div>

            <div class="row g-3 mt-3">

                <div class="col-4">

                    <div class="info-box">

                        <div class="info-label">
                            EXPECTED
                        </div>

                        <div class="info-value">

                            ₹<?= number_format(
                                $monthlyExpected,
                                2
                            ) ?>

                        </div>

                    </div>

                </div>

                <div class="col-4">

                    <div class="info-box">

                        <div class="info-label">
                            RECEIVED
                        </div>

                        <div class="info-value success">

                            ₹<?= number_format(
                                $monthlyReceived,
                                2
                            ) ?>

                        </div>

                    </div>

                </div>

                <div class="col-4">

                    <div class="info-box">

                        <div class="info-label">
                            DUE
                        </div>

                        <div class="info-value due">

                            ₹<?= number_format(
                                $monthlyDue,
                                2
                            ) ?>

                        </div>

                    </div>

                </div>

            </div>

            <div class="mt-4">

                <div class="d-flex justify-content-between mb-2">

                    <small class="muted">
                        Monthly Progress
                    </small>

                    <small class="fw-bold">

                        <?= number_format(
                            $monthlyProgress,
                            1
                        ) ?>%

                    </small>

                </div>

                <div class="progress-wrap">

                    <div
                        class="progress-fill"
                        style="width:<?= $monthlyProgress ?>%"
                    ></div>

                </div>

            </div>

            <div class="d-flex justify-content-between mt-3">

                <small class="muted">
                    Due Installments
                </small>

                <strong>
                    <?= $monthlyDueInstallments ?>
                </strong>

            </div>

        </div>

    </div>

    <div class="col-xl-6">

        <div class="collection-card collection-card-dark">

            <div class="d-flex justify-content-between align-items-start">

                <div>

                    <div class="collection-title">
                        Weekly Collection
                    </div>

                    <div class="collection-subtitle">
                        Only Weekly customers · Current week
                    </div>

                </div>

                <div
                    class="stat-icon"
                    style="
                    background:rgba(255,255,255,.08);
                    color:#4ade80;
                    "
                >
                    <i class="bi bi-calendar-week-fill"></i>
                </div>

            </div>

            <div class="big-amount light-green">

                ₹<?= number_format(
                    $thisWeekWeeklyCollection,
                    2
                ) ?>

            </div>

            <div class="collection-subtitle">
                Current week received collection
            </div>

            <div class="row g-3 mt-3">

                <div class="col-4">

                    <div class="info-box">

                        <div class="info-label">
                            EXPECTED
                        </div>

                        <div class="info-value">

                            ₹<?= number_format(
                                $weeklyExpected,
                                2
                            ) ?>

                        </div>

                    </div>

                </div>

                <div class="col-4">

                    <div class="info-box">

                        <div class="info-label">
                            RECEIVED
                        </div>

                        <div class="info-value success">

                            ₹<?= number_format(
                                $weeklyReceived,
                                2
                            ) ?>

                        </div>

                    </div>

                </div>

                <div class="col-4">

                    <div class="info-box">

                        <div class="info-label">
                            DUE
                        </div>

                        <div class="info-value due">

                            ₹<?= number_format(
                                $weeklyDue,
                                2
                            ) ?>

                        </div>

                    </div>

                </div>

            </div>

            <div class="mt-4">

                <div class="d-flex justify-content-between mb-2">

                    <small class="collection-subtitle">
                        Weekly Progress
                    </small>

                    <small
                        style="
                        color:#fff;
                        font-weight:700;
                        "
                    >
                        <?= number_format(
                            $weeklyProgress,
                            1
                        ) ?>%
                    </small>

                </div>

                <div class="progress-wrap">

                    <div
                        class="progress-fill"
                        style="width:<?= $weeklyProgress ?>%"
                    ></div>

                </div>

            </div>

            <div class="d-flex justify-content-between mt-3">

                <small class="collection-subtitle">
                    Due Installments
                </small>

                <strong>
                    <?= $weeklyDueInstallments ?>
                </strong>

            </div>

        </div>

    </div>

</div>

<div class="row g-4 mb-4">

    <div class="col-xl-6">

        <div class="stat-card">

            <div class="d-flex justify-content-between">

                <div>

                    <div class="stat-label">
                        MONTHLY PAID INSTALLMENTS
                    </div>

                    <div class="stat-value">

                        <?= $monthlyPaidInstallments ?>

                        /

                        <?= $monthlyTotalInstallments ?>

                    </div>

                    <div class="stat-note">
                        Monthly payment records
                    </div>

                </div>

                <div class="stat-icon">
                    <i class="bi bi-check2-circle"></i>
                </div>

            </div>

        </div>

    </div>

    <div class="col-xl-6">

        <div class="stat-card">

            <div class="d-flex justify-content-between">

                <div>

                    <div class="stat-label">
                        WEEKLY PAID INSTALLMENTS
                    </div>

                    <div class="stat-value">

                        <?= $weeklyPaidInstallments ?>

                        /

                        <?= $weeklyTotalInstallments ?>

                    </div>

                    <div class="stat-note">
                        Weekly payment records
                    </div>

                </div>

                <div class="stat-icon">
                    <i class="bi bi-check2-circle"></i>
                </div>

            </div>

        </div>

    </div>

</div>

<div class="section-card">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <div class="section-title">
                Recent Payments
            </div>

            <div class="section-subtitle">
                Latest Monthly and Weekly payments
            </div>

        </div>

        <a
            href="customers.php"
            class="btn btn-sm btn-outline-success"
        >
            Customers
        </a>

    </div>

    <div class="table-responsive">

        <table class="payment-table">

            <thead>

                <tr>

                    <th>
                        Customer
                    </th>

                    <th>
                        Plan
                    </th>

                    <th>
                        Installment
                    </th>

                    <th>
                        Amount
                    </th>

                    <th>
                        Payment Date
                    </th>

                    <th>
                        Due Date
                    </th>

                </tr>

            </thead>

            <tbody>

            <?php if (
                $recentPayments &&
                $recentPayments->num_rows > 0
            ): ?>

                <?php while (
                    $payment =
                    $recentPayments->fetch_assoc()
                ): ?>

                    <tr>

                        <td>

                            <span class="avatar-small">

                                <?= strtoupper(
                                    substr(
                                        $payment['name'],
                                        0,
                                        1
                                    )
                                ) ?>

                            </span>

                            <?= htmlspecialchars(
                                $payment['name']
                            ) ?>

                        </td>

                        <td>

                            <?php if (
                                $payment['plan'] === 'Monthly'
                            ): ?>

                                <span
                                    class="
                                    plan-badge
                                    monthly-badge
                                    "
                                >

                                    <i class="bi bi-calendar-month"></i>

                                    Monthly

                                </span>

                            <?php else: ?>

                                <span
                                    class="
                                    plan-badge
                                    weekly-badge
                                    "
                                >

                                    <i class="bi bi-calendar-week"></i>

                                    Weekly

                                </span>

                            <?php endif; ?>

                        </td>

                        <td>

                            #<?= (int)
                            $payment[
                                'installment_no'
                            ] ?>

                        </td>

                        <td>

                            <strong
                                style="color:#15803d"
                            >

                                ₹<?= number_format(
                                    (float)
                                    $payment['amount'],
                                    2
                                ) ?>

                            </strong>

                        </td>

                        <td class="muted">

                            <?= !empty(
                                $payment['payment_date']
                            )
                                ? date(
                                    'd M Y',
                                    strtotime(
                                        $payment[
                                            'payment_date'
                                        ]
                                    )
                                )
                                : '-'
                            ?>

                        </td>

                        <td class="muted">

                            <?= !empty(
                                $payment['due_date']
                            )
                                ? date(
                                    'd M Y',
                                    strtotime(
                                        $payment[
                                            'due_date'
                                        ]
                                    )
                                )
                                : '-'
                            ?>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td
                        colspan="6"
                        class="text-center py-5"
                    >

                        <i
                            class="bi bi-receipt"
                            style="
                            font-size:30px;
                            color:#b8c2bb;
                            "
                        ></i>

                        <div class="muted mt-2">
                            No payment found
                        </div>

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

<?php

include 'includes/footer.php';

?>