INVENTORY PRO - ADVANCED UI
=============================

1. Extract this folder into:
   C:\laragon\www\inventory_system

2. Existing database:
   This build is compatible with the products table you showed:
   id, product_name, category_id, price, stock, description, created_at, purchase_price

3. If your database already exists, DO NOT drop it.
   Open:
   http://localhost/inventory_system/login.php

4. If admin user does not exist, open setup.php once:
   http://localhost/inventory_system/setup.php

Login:
Email: admin@gmail.com
Password: admin123

5. After setup, delete setup.php for safety.

IMPORTANT:
- Keep your existing database if it already contains data.
- The UI has been upgraded without changing the existing database column names.
