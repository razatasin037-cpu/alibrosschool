<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Categories";

require "../includes/header.php";
require "../includes/sidebar.php";

$q = trim($_GET['q'] ?? '');
$like = "%$q%";

$s = $conn->prepare("
    SELECT *
    FROM category
    WHERE category_name LIKE ?
    ORDER BY id DESC
");

$s->bind_param("s", $like);
$s->execute();

$rows = $s->get_result();

$totalCategories = $conn->query("
    SELECT COUNT(*) AS total
    FROM category
")->fetch_assoc()['total'];

?>

<div class="w-full">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">

        <div>

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-11 h-11
                        rounded-2xl
                        bg-blue-50
                        text-blue-600
                        flex items-center justify-center
                    "
                >

                    <i data-lucide="folder-kanban" class="w-5 h-5"></i>

                </div>

                <div>

                    <h2 class="text-2xl font-bold text-slate-800">
                        Categories
                    </h2>

                    <p class="text-sm text-slate-500 mt-1">
                        Organize and manage your product categories
                    </p>

                </div>

            </div>

        </div>


        <a
            href="add.php"
            class="
                btn
                bg-blue-600
                hover:bg-blue-700
                text-white
                shadow-lg
                shadow-blue-600/20
            "
        >

            <i data-lucide="plus" class="w-4 h-4"></i>

            Add Category

        </a>

    </div>


    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">

        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-blue-50
                        text-blue-600
                        flex items-center justify-center
                    "
                >

                    <i data-lucide="folder" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Total Categories
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">
                        <?= $totalCategories ?>
                    </h3>

                </div>

            </div>

        </div>


        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-emerald-50
                        text-emerald-600
                        flex items-center justify-center
                    "
                >

                    <i data-lucide="package" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Products
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">

                        <?php

                        $totalProducts = $conn->query("
                            SELECT COUNT(*) AS total
                            FROM products
                        ")->fetch_assoc()['total'];

                        echo $totalProducts;

                        ?>

                    </h3>

                </div>

            </div>

        </div>


        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-violet-50
                        text-violet-600
                        flex items-center justify-center
                    "
                >

                    <i data-lucide="layers-3" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Showing
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">
                        <?= $rows->num_rows ?>
                    </h3>

                </div>

            </div>

        </div>

    </div>


    <div class="card overflow-hidden">

        <div
            class="
                p-5
                md:p-6
                border-b
                border-slate-100
                flex
                flex-col
                lg:flex-row
                lg:items-center
                justify-between
                gap-4
            "
        >

            <div>

                <h3 class="font-bold text-lg text-slate-800">
                    Category List
                </h3>

                <p class="text-sm text-slate-500 mt-1">
                    View and manage all product categories
                </p>

            </div>


            <form
                method="get"
                class="
                    flex
                    w-full
                    lg:w-auto
                    gap-2
                "
            >

                <div class="relative flex-1 lg:w-80">

                    <i
                        data-lucide="search"
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            w-4
                            text-slate-400
                        "
                    ></i>

                    <input
                        type="text"
                        name="q"
                        value="<?= htmlspecialchars($q) ?>"
                        placeholder="Search category..."
                        class="input pl-11"
                    >

                </div>


                <button
                    type="submit"
                    class="
                        btn
                        bg-slate-900
                        hover:bg-slate-800
                        text-white
                        px-5
                    "
                >

                    Search

                </button>


                <?php if ($q): ?>

                    <a
                        href="view.php"
                        class="
                            btn
                            bg-slate-100
                            hover:bg-slate-200
                            text-slate-700
                        "
                    >

                        Clear

                    </a>

                <?php endif; ?>

            </form>

        </div>


        <div class="table-wrap">

            <table class="table">

                <thead>

                    <tr>

                        <th>
                            Category
                        </th>

                        <th>
                            Description
                        </th>

                        <th>
                            Products
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody>

                    <?php if ($rows->num_rows > 0): ?>

                        <?php while ($r = $rows->fetch_assoc()): ?>

                            <?php

                            $categoryId = $r['id'];

                            $productCount = $conn->query("
                                SELECT COUNT(*) AS total
                                FROM products
                                WHERE category_id = $categoryId
                            ")->fetch_assoc()['total'];

                            ?>

                            <tr>

                                <td>

                                    <div class="flex items-center gap-3">

                                        <div
                                            class="
                                                w-10 h-10
                                                rounded-xl
                                                bg-blue-50
                                                text-blue-600
                                                flex items-center justify-center
                                            "
                                        >

                                            <i
                                                data-lucide="folder"
                                                class="w-5"
                                            ></i>

                                        </div>


                                        <div>

                                            <div class="font-semibold text-slate-800">

                                                <?= htmlspecialchars(
                                                    $r['category_name']
                                                ) ?>

                                            </div>

                                            <div class="text-xs text-slate-400">

                                                Category #<?= $r['id'] ?>

                                            </div>

                                        </div>

                                    </div>

                                </td>


                                <td>

                                    <div class="max-w-[350px]">

                                        <?php if (!empty($r['description'])): ?>

                                            <span class="text-slate-600">

                                                <?= htmlspecialchars(
                                                    $r['description']
                                                ) ?>

                                            </span>

                                        <?php else: ?>

                                            <span class="text-slate-400">

                                                No description

                                            </span>

                                        <?php endif; ?>

                                    </div>

                                </td>


                                <td>

                                    <span
                                        class="
                                            badge
                                            bg-blue-50
                                            text-blue-700
                                        "
                                    >

                                        <?= $productCount ?>

                                        Products

                                    </span>

                                </td>


                                <td>

                                    <?php if ($productCount > 0): ?>

                                        <span
                                            class="
                                                badge
                                                bg-emerald-50
                                                text-emerald-700
                                            "
                                        >

                                            <span
                                                class="
                                                    w-1.5 h-1.5
                                                    rounded-full
                                                    bg-emerald-500
                                                    mr-1.5
                                                "
                                            ></span>

                                            Active

                                        </span>

                                    <?php else: ?>

                                        <span
                                            class="
                                                badge
                                                bg-slate-100
                                                text-slate-500
                                            "
                                        >

                                            Empty

                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <div class="flex items-center gap-2">

                                        <a
                                            href="edit.php?id=<?= $r['id'] ?>"
                                            class="
                                                inline-flex
                                                items-center
                                                gap-1.5
                                                px-3
                                                py-2
                                                rounded-xl
                                                bg-blue-50
                                                text-blue-600
                                                hover:bg-blue-100
                                                text-xs
                                                font-semibold
                                                transition
                                            "
                                        >

                                            <i
                                                data-lucide="pencil"
                                                class="w-4"
                                            ></i>

                                            Edit

                                        </a>


                                        <a
                                            href="delete.php?id=<?= $r['id'] ?>"
                                            onclick="return confirm('Are you sure you want to delete this category?')"
                                            class="
                                                inline-flex
                                                items-center
                                                gap-1.5
                                                px-3
                                                py-2
                                                rounded-xl
                                                bg-red-50
                                                text-red-600
                                                hover:bg-red-100
                                                text-xs
                                                font-semibold
                                                transition
                                            "
                                        >

                                            <i
                                                data-lucide="trash-2"
                                                class="w-4"
                                            ></i>

                                            Delete

                                        </a>

                                    </div>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>

                            <td
                                colspan="5"
                                class="text-center py-12"
                            >

                                <div class="flex flex-col items-center">

                                    <div
                                        class="
                                            w-14 h-14
                                            rounded-2xl
                                            bg-slate-100
                                            text-slate-400
                                            flex items-center justify-center
                                            mb-3
                                        "
                                    >

                                        <i
                                            data-lucide="folder-x"
                                            class="w-7"
                                        ></i>

                                    </div>


                                    <h3 class="font-semibold text-slate-700">

                                        No categories found

                                    </h3>


                                    <p class="text-sm text-slate-400 mt-1">

                                        <?php if ($q): ?>

                                            No category matches
                                            "<?= htmlspecialchars($q) ?>".

                                        <?php else: ?>

                                            Add your first category to get started.

                                        <?php endif; ?>

                                    </p>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<?php

require "../includes/footer.php";

?>