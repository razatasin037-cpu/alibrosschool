<?php

require "../includes/auth.php";
require "../includes/connection.php";

$id = (int)($_GET['id'] ?? 0);

if ($id < 1) {
    header("Location: view.php");
    exit;
}

$s = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM products
    WHERE category_id = ?
");

$s->bind_param("i", $id);
$s->execute();

$total = $s->get_result()->fetch_assoc()['total'];

if ($total > 0) {
    echo "<script>
        alert('This category cannot be deleted because products are using it.');
        window.location.href='view.php';
    </script>";
    exit;
}

$s = $conn->prepare("
    DELETE FROM category
    WHERE id = ?
");

$s->bind_param("i", $id);
$s->execute();

header("Location: view.php");
exit;
?>