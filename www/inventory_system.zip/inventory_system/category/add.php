<?php
require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Add Category";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $n = trim($_POST['category_name']);
    $d = trim($_POST['description']);

    $s = $conn->prepare(
        "INSERT INTO category(category_name,description) VALUES(?,?)"
    );

    $s->bind_param("ss", $n, $d);
    $s->execute();

    header("Location:view.php");
    exit;
}

require "../includes/header.php";
require "../includes/sidebar.php";
?>

<div class="w-full">

    <!-- Heading -->
    <div class="mb-6">
        <h2 class="text-2xl font-bold text-slate-800">
            Add New Category
        </h2>

        <p class="text-sm text-slate-500 mt-1">
            Create a new product category
        </p>
    </div>


    <!-- Full Width Form -->
    <div class="card w-full p-6 md:p-8">

        <form method="post" class="grid grid-cols-1 md:grid-cols-2 gap-6">

            <!-- Category Name -->
            <div>
                <label class="block text-sm font-semibold text-slate-700 mb-2">
                    Category Name
                </label>

                <input
                    type="text"
                    name="category_name"
                    required
                    placeholder="Enter category name"
                    class="input"
                >
            </div>


            <!-- Status -->
            <div>
                <label class="block text-sm font-semibold text-slate-700 mb-2">
                    Status
                </label>

                <select
                    class="input"
                    name="status"
                >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>


            <!-- Description -->
            <div class="md:col-span-2">

                <label class="block text-sm font-semibold text-slate-700 mb-2">
                    Description
                </label>

                <textarea
                    name="description"
                    rows="6"
                    placeholder="Enter category description..."
                    class="input resize-none"
                ></textarea>

            </div>


            <!-- Buttons -->
            <div class="md:col-span-2 flex justify-end gap-3 pt-3">

                <a
                    href="view.php"
                    class="px-6 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                    Cancel
                </a>

                <button
                    type="submit"
                    class="btn btn-primary px-7"
                >
                    <i data-lucide="plus" class="w-4"></i>
                    Save Category
                </button>

            </div>

        </form>

    </div>

</div>

<?php require "../includes/footer.php"; ?>