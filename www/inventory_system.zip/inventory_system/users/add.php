<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Add User";

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];
    $role = $_POST["role"];

    if ($name == "" || $email == "" || $password == "") {
        $error = "Please fill all fields.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {

        $name = $conn->real_escape_string($name);
        $email = $conn->real_escape_string($email);
        $role = $conn->real_escape_string($role);

        $check = $conn->query("SELECT id FROM users WHERE email='$email'");

        if ($check->num_rows > 0) {
            $error = "This email already exists.";
        } else {

            $password = password_hash($password, PASSWORD_DEFAULT);

            $sql = "
                INSERT INTO users
                (name, email, password, role)
                VALUES
                ('$name', '$email', '$password', '$role')
            ";

            if ($conn->query($sql)) {
                header("Location: view.php");
                exit;
            } else {
                $error = "User could not be created.";
            }
        }
    }
}

require "../includes/header.php";
require "../includes/sidebar.php";
?>

<div class="w-full">

    <div class="relative overflow-hidden rounded-[28px] bg-gradient-to-br from-slate-950 via-blue-950 to-indigo-950 text-white p-6 md:p-8 mb-6">

        <div class="absolute -right-20 -top-20 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl"></div>

        <div class="relative flex items-center justify-between gap-5">

            <div>
                <div class="text-blue-300 text-xs font-bold tracking-wider mb-3">USER MANAGEMENT</div>
                <h1 class="text-2xl md:text-4xl font-black">Add New User</h1>
                <p class="text-slate-300 mt-2">Create a new account for your Inventory Pro system.</p>
            </div>

            <div class="hidden sm:flex w-16 h-16 rounded-2xl bg-white/10 items-center justify-center">
                <i data-lucide="user-plus" class="w-8 h-8"></i>
            </div>

        </div>
    </div>

    <?php if ($error != ""): ?>
        <div class="mb-6 p-4 rounded-2xl bg-red-50 border border-red-100 text-red-600">
            <div class="flex items-center gap-3">
                <i data-lucide="circle-alert" class="w-5 h-5"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        </div>
    <?php endif; ?>

    <div class="grid lg:grid-cols-3 gap-6">

        <div class="lg:col-span-2">

            <form method="post" class="card p-6 md:p-8">

                <div class="mb-7">
                    <h2 class="text-xl font-black text-slate-800">User Information</h2>
                    <p class="text-sm text-slate-400 mt-1">Enter the login details of the new user.</p>
                </div>

                <div class="grid md:grid-cols-2 gap-5">

                    <div class="md:col-span-2">
                        <label class="block text-sm font-bold text-slate-700 mb-2">Full Name</label>
                        <div class="relative">
                            <i data-lucide="user" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400"></i>
                            <input type="text" name="name" required value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" placeholder="Enter full name" class="input pl-12">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2">Email</label>
                        <div class="relative">
                            <i data-lucide="mail" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400"></i>
                            <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" placeholder="admin@gmail.com" class="input pl-12">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2">Role</label>
                        <div class="relative">
                            <i data-lucide="shield" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400"></i>
                            <select name="role" class="input pl-12">
                                <option value="admin">Admin</option>
                                <option value="staff">Staff</option>
                            </select>
                        </div>
                    </div>

                    <div class="md:col-span-2">
                        <label class="block text-sm font-bold text-slate-700 mb-2">Password</label>
                        <div class="relative">
                            <i data-lucide="lock" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400"></i>
                            <input type="password" name="password" id="password" required minlength="6" placeholder="Enter password" class="input pl-12 pr-12">
                            <button type="button" onclick="showPassword()" class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-blue-600">
                                <i id="eye" data-lucide="eye" class="w-5 h-5"></i>
                            </button>
                        </div>
                        <p class="text-xs text-slate-400 mt-2">Password must contain at least 6 characters.</p>
                    </div>

                </div>

                <div class="mt-8 pt-6 border-t border-slate-100 flex flex-col sm:flex-row justify-end gap-3">
                    <a href="view.php" class="px-6 py-3 rounded-xl bg-slate-100 text-slate-700 font-bold text-center hover:bg-slate-200">Cancel</a>
                    <button type="submit" class="btn btn-primary px-7">
                        <i data-lucide="user-plus" class="w-4 h-4"></i>
                        Create User
                    </button>
                </div>

            </form>
        </div>

        <div>
            <div class="card p-6">

                <div class="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
                    <i data-lucide="shield-check" class="w-7 h-7"></i>
                </div>

                <h3 class="text-xl font-black mt-5">Account Security</h3>
                <p class="text-sm text-slate-500 mt-2 leading-6">User passwords are converted into a secure hash before being saved.</p>

                <div class="mt-6 space-y-4">

                    <div class="flex gap-3">
                        <div class="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                            <i data-lucide="check" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <div class="font-bold text-sm">Secure Password</div>
                            <div class="text-xs text-slate-400 mt-1">Password is hashed before database storage.</div>
                        </div>
                    </div>

                    <div class="flex gap-3">
                        <div class="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                            <i data-lucide="mail-check" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <div class="font-bold text-sm">Unique Email</div>
                            <div class="text-xs text-slate-400 mt-1">Same email cannot be registered twice.</div>
                        </div>
                    </div>

                    <div class="flex gap-3">
                        <div class="w-9 h-9 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center shrink-0">
                            <i data-lucide="shield" class="w-4 h-4"></i>
                        </div>
                        <div>
                            <div class="font-bold text-sm">Role Access</div>
                            <div class="text-xs text-slate-400 mt-1">Admin and Staff roles are available.</div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
</div>

<script>
function showPassword() {
    var password = document.getElementById("password");
    var eye = document.getElementById("eye");

    if (password.type == "password") {
        password.type = "text";
        eye.setAttribute("data-lucide", "eye-off");
    } else {
        password.type = "password";
        eye.setAttribute("data-lucide", "eye");
    }

    lucide.createIcons();
}

document.addEventListener("DOMContentLoaded", function() {
    lucide.createIcons();
});
</script>

<?php require "../includes/footer.php"; ?>
