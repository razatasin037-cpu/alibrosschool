<?php

require "../includes/auth.php";
require "../includes/connection.php";

$id = (int)($_GET['id'] ?? 0);

if ($id < 1) {
    header("Location: view.php");
    exit;
}

if ($id == $_SESSION['user_id']) {
    echo "<script>
        alert('You cannot delete your own account.');
        window.location.href='view.php';
    </script>";
    exit;
}

$s = $conn->prepare("
    DELETE FROM users
    WHERE id = ?
");

$s->bind_param("i", $id);
$s->execute();

header("Location: view.php");
exit;

?>