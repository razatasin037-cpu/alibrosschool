<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Users";

require "../includes/header.php";
require "../includes/sidebar.php";

$rows = $conn->query("
    SELECT id, name, email, role, status
    FROM users
    ORDER BY id DESC
");

?>

<div class="w-full">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">

        <div>

            <div class="flex items-center gap-3">

                <div class="w-11 h-11 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">

                    <i data-lucide="users" class="w-5 h-5"></i>

                </div>

                <div>

                    <h2 class="text-2xl font-bold text-slate-800">
                        Users
                    </h2>

                    <p class="text-sm text-slate-500 mt-1">
                        Manage system users and their access
                    </p>

                </div>

            </div>

        </div>

        <a
            href="add.php"
            class="btn bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/20"
        >

            <i data-lucide="user-plus" class="w-4 h-4"></i>

            Add User

        </a>

    </div>


    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">

        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">

                    <i data-lucide="users" class="w-5 h-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Total Users
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">

                        <?= $rows->num_rows ?>

                    </h3>

                </div>

            </div>

        </div>


        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div class="w-10 h-10 rounded-xl bg-violet-50 text-violet-600 flex items-center justify-center">

                    <i data-lucide="shield-check" class="w-5 h-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Administrators
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">

                        <?php

                        $adminCount = $conn->query("
                            SELECT COUNT(*) AS total
                            FROM users
                            WHERE role = 'admin'
                        ")->fetch_assoc()['total'];

                        echo $adminCount;

                        ?>

                    </h3>

                </div>

            </div>

        </div>


        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div class="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">

                    <i data-lucide="user-check" class="w-5 h-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Active Users
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">

                        <?php

                        $activeCount = $conn->query("
                            SELECT COUNT(*) AS total
                            FROM users
                            WHERE status = 'active'
                        ")->fetch_assoc()['total'];

                        echo $activeCount;

                        ?>

                    </h3>

                </div>

            </div>

        </div>

    </div>


    <div class="card overflow-hidden">

        <div class="p-5 md:p-6 border-b border-slate-100 flex items-center justify-between">

            <div>

                <h3 class="font-bold text-lg text-slate-800">
                    All Users
                </h3>

                <p class="text-sm text-slate-500 mt-1">
                    User accounts registered in the system
                </p>

            </div>

        </div>


        <div class="table-wrap">

            <table class="table">

                <thead>

                    <tr>

                        <th>
                            User
                        </th>

                        <th>
                            Email
                        </th>

                        <th>
                            Role
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody>

                    <?php if ($rows->num_rows > 0): ?>

                        <?php while ($r = $rows->fetch_assoc()): ?>

                            <tr>

                                <td>

                                    <div class="flex items-center gap-3">

                                        <div
                                            class="
                                                w-10 h-10
                                                rounded-xl
                                                bg-gradient-to-br
                                                from-blue-600
                                                to-indigo-600
                                                text-white
                                                flex
                                                items-center
                                                justify-center
                                                font-bold
                                            "
                                        >

                                            <?= strtoupper(
                                                substr(
                                                    $r['name'],
                                                    0,
                                                    1
                                                )
                                            ) ?>

                                        </div>


                                        <div>

                                            <div class="font-semibold text-slate-800">

                                                <?= htmlspecialchars(
                                                    $r['name']
                                                ) ?>

                                            </div>

                                            <div class="text-xs text-slate-400">

                                                User #<?= $r['id'] ?>

                                            </div>

                                        </div>

                                    </div>

                                </td>


                                <td>

                                    <span class="text-slate-600">

                                        <?= htmlspecialchars(
                                            $r['email']
                                        ) ?>

                                    </span>

                                </td>


                                <td>

                                    <?php if ($r['role'] === 'admin'): ?>

                                        <span
                                            class="
                                                badge
                                                bg-violet-50
                                                text-violet-700
                                            "
                                        >

                                            <i
                                                data-lucide="shield-check"
                                                class="w-3 h-3 mr-1"
                                            ></i>

                                            Administrator

                                        </span>

                                    <?php else: ?>

                                        <span
                                            class="
                                                badge
                                                bg-blue-50
                                                text-blue-700
                                            "
                                        >

                                            <i
                                                data-lucide="user-round"
                                                class="w-3 h-3 mr-1"
                                            ></i>

                                            Staff

                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <?php if ($r['status'] === 'active'): ?>

                                        <span
                                            class="
                                                badge
                                                bg-emerald-50
                                                text-emerald-700
                                            "
                                        >

                                            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5"></span>

                                            Active

                                        </span>

                                    <?php else: ?>

                                        <span
                                            class="
                                                badge
                                                bg-red-50
                                                text-red-600
                                            "
                                        >

                                            <span class="w-1.5 h-1.5 rounded-full bg-red-500 mr-1.5"></span>

                                            <?= htmlspecialchars(
                                                ucfirst($r['status'])
                                            ) ?>

                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <a
                                        href="delete.php?id=<?= $r['id'] ?>"
                                        onclick="return confirm('Are you sure you want to delete this user?')"
                                        class="
                                            inline-flex
                                            items-center
                                            gap-2
                                            px-3
                                            py-2
                                            rounded-xl
                                            bg-red-50
                                            text-red-600
                                            hover:bg-red-100
                                            text-xs
                                            font-semibold
                                            transition
                                        "
                                    >

                                        <i
                                            data-lucide="trash-2"
                                            class="w-4 h-4"
                                        ></i>

                                        Delete

                                    </a>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>

                            <td
                                colspan="5"
                                class="text-center py-12"
                            >

                                <div class="flex flex-col items-center">

                                    <div class="w-14 h-14 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mb-3">

                                        <i
                                            data-lucide="users"
                                            class="w-7 h-7"
                                        ></i>

                                    </div>

                                    <h3 class="font-semibold text-slate-700">
                                        No users found
                                    </h3>

                                    <p class="text-sm text-slate-400 mt-1">
                                        Add your first user to get started.
                                    </p>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<?php

require "../includes/footer.php";

?>