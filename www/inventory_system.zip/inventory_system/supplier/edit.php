<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Edit Supplier";

$id = (int)($_GET['id'] ?? 0);

if ($id < 1) {
    header("Location: view.php");
    exit;
}

$s = $conn->prepare("
    SELECT *
    FROM supplier
    WHERE id = ?
");

$s->bind_param("i", $id);
$s->execute();

$r = $s->get_result()->fetch_assoc();

if (!$r) {
    header("Location: view.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $n = trim($_POST['supplier_name'] ?? '');
    $c = trim($_POST['contact_person'] ?? '');
    $m = trim($_POST['mobile'] ?? '');
    $e = trim($_POST['email'] ?? '');
    $a = trim($_POST['address'] ?? '');

    if ($n === '') {

        $error = "Supplier name is required.";

    } else {

        $s = $conn->prepare("
            UPDATE supplier
            SET
                supplier_name = ?,
                contact_person = ?,
                mobile = ?,
                email = ?,
                address = ?
            WHERE id = ?
        ");

        $s->bind_param(
            "sssssi",
            $n,
            $c,
            $m,
            $e,
            $a,
            $id
        );

        $s->execute();

        header("Location: view.php");
        exit;
    }
}

require "../includes/header.php";
require "../includes/sidebar.php";

?>

<div class="w-full">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">

        <div>

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-11 h-11
                        rounded-2xl
                        bg-emerald-50
                        text-emerald-600
                        flex items-center justify-center
                    "
                >

                    <i data-lucide="truck" class="w-5 h-5"></i>

                </div>

                <div>

                    <h2 class="text-2xl font-bold text-slate-800">
                        Edit Supplier
                    </h2>

                    <p class="text-sm text-slate-500 mt-1">
                        Update supplier information
                    </p>

                </div>

            </div>

        </div>


        <a
            href="view.php"
            class="
                btn
                bg-slate-100
                hover:bg-slate-200
                text-slate-700
            "
        >

            <i data-lucide="arrow-left" class="w-4 h-4"></i>

            Back to Suppliers

        </a>

    </div>


    <?php if (!empty($error)): ?>

        <div
            class="
                mb-6
                p-4
                rounded-2xl
                bg-red-50
                border
                border-red-100
                text-red-600
                flex
                items-center
                gap-3
            "
        >

            <i data-lucide="circle-alert" class="w-5 h-5"></i>

            <?= htmlspecialchars($error) ?>

        </div>

    <?php endif; ?>


    <div class="card w-full p-6 md:p-8">

        <form
            method="post"
            class="
                grid
                grid-cols-1
                md:grid-cols-2
                gap-6
            "
        >

            <div>

                <label class="block text-sm font-semibold text-slate-700 mb-2">

                    Supplier Name

                    <span class="text-red-500">*</span>

                </label>

                <div class="relative">

                    <i
                        data-lucide="building-2"
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            w-5
                            text-slate-400
                        "
                    ></i>

                    <input
                        type="text"
                        name="supplier_name"
                        required
                        value="<?= htmlspecialchars($r['supplier_name']) ?>"
                        placeholder="Enter supplier name"
                        class="input pl-12"
                    >

                </div>

            </div>


            <div>

                <label class="block text-sm font-semibold text-slate-700 mb-2">

                    Contact Person

                </label>

                <div class="relative">

                    <i
                        data-lucide="user-round"
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            w-5
                            text-slate-400
                        "
                    ></i>

                    <input
                        type="text"
                        name="contact_person"
                        value="<?= htmlspecialchars($r['contact_person'] ?? '') ?>"
                        placeholder="Contact person name"
                        class="input pl-12"
                    >

                </div>

            </div>


            <div>

                <label class="block text-sm font-semibold text-slate-700 mb-2">

                    Mobile Number

                </label>

                <div class="relative">

                    <i
                        data-lucide="phone"
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            w-5
                            text-slate-400
                        "
                    ></i>

                    <input
                        type="tel"
                        name="mobile"
                        value="<?= htmlspecialchars($r['mobile'] ?? '') ?>"
                        placeholder="Enter mobile number"
                        class="input pl-12"
                    >

                </div>

            </div>


            <div>

                <label class="block text-sm font-semibold text-slate-700 mb-2">

                    Email Address

                </label>

                <div class="relative">

                    <i
                        data-lucide="mail"
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            w-5
                            text-slate-400
                        "
                    ></i>

                    <input
                        type="email"
                        name="email"
                        value="<?= htmlspecialchars($r['email'] ?? '') ?>"
                        placeholder="supplier@example.com"
                        class="input pl-12"
                    >

                </div>

            </div>


            <div class="md:col-span-2">

                <label class="block text-sm font-semibold text-slate-700 mb-2">

                    Address

                </label>

                <div class="relative">

                    <i
                        data-lucide="map-pin"
                        class="
                            absolute
                            left-4
                            top-4
                            w-5
                            text-slate-400
                        "
                    ></i>

                    <textarea
                        name="address"
                        rows="6"
                        placeholder="Enter complete supplier address..."
                        class="input pl-12 resize-none"
                    ><?= htmlspecialchars($r['address'] ?? '') ?></textarea>

                </div>

            </div>


            <div
                class="
                    md:col-span-2
                    flex
                    flex-col
                    sm:flex-row
                    justify-between
                    items-center
                    gap-4
                    pt-5
                    border-t
                    border-slate-100
                "
            >

                <div
                    class="
                        flex
                        items-center
                        gap-2
                        text-xs
                        text-slate-400
                    "
                >

                    <i
                        data-lucide="shield-check"
                        class="w-4 h-4"
                    ></i>

                    Supplier information will be updated securely.

                </div>


                <div class="flex gap-3 w-full sm:w-auto">

                    <a
                        href="view.php"
                        class="
                            flex-1
                            sm:flex-none
                            px-6
                            py-3
                            rounded-xl
                            bg-slate-100
                            hover:bg-slate-200
                            text-slate-700
                            font-semibold
                            text-center
                            transition
                        "
                    >

                        Cancel

                    </a>


                    <button
                        type="submit"
                        class="
                            btn
                            flex-1
                            sm:flex-none
                            bg-blue-600
                            hover:bg-blue-700
                            text-white
                            shadow-lg
                            shadow-blue-600/20
                        "
                    >

                        <i
                            data-lucide="save"
                            class="w-4 h-4"
                        ></i>

                        Update Supplier

                    </button>

                </div>

            </div>

        </form>

    </div>

</div>


<?php

require "../includes/footer.php";

?>