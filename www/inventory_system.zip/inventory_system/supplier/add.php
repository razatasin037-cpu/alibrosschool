<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "New Sale";

$error = "";


/* -------------------------------------------------
   PRODUCTS
------------------------------------------------- */

$products = [];

$result = $conn->query("
    SELECT
        id,
        product_name,
        stock,
        price
    FROM products
    ORDER BY product_name
");

while ($p = $result->fetch_assoc()) {

    $products[] = $p;
}


/* -------------------------------------------------
   FORM SUBMIT
------------------------------------------------- */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $customer_name = trim($_POST["customer_name"] ?? "");

    $date = $_POST["date"] ?? date("Y-m-d");

    $paid_amount = (float)($_POST["paid_amount"] ?? 0);

    $remarks = trim($_POST["remarks"] ?? "");

    $product_ids = $_POST["product_id"] ?? [];

    $quantities = $_POST["quantity"] ?? [];


    /* ---------------------------------------------
       BASIC VALIDATION
    --------------------------------------------- */

    if (empty($product_ids)) {

        $error = "Please add at least one product.";

    } elseif ($paid_amount < 0) {

        $error = "Paid amount cannot be negative.";

    } else {

        $items = [];

        $total_amount = 0;


        /* -----------------------------------------
           PRODUCTS CHECK
        ----------------------------------------- */

        foreach ($product_ids as $index => $product_id) {

            $product_id = (int)$product_id;

            $quantity = (int)($quantities[$index] ?? 0);


            if ($product_id <= 0) {

                $error = "Please select a valid product.";

                break;
            }


            if ($quantity < 1) {

                $error = "Quantity must be at least 1.";

                break;
            }


            /* Get current product */

            $check = $conn->prepare("
                SELECT
                    id,
                    product_name,
                    stock,
                    price
                FROM products
                WHERE id = ?
            ");

            $check->bind_param(
                "i",
                $product_id
            );

            $check->execute();

            $product =
                $check->get_result()->fetch_assoc();


            if (!$product) {

                $error = "Product not found.";

                break;
            }


            /* Stock check */

            if ($quantity > (int)$product["stock"]) {

                $error =
                    $product["product_name"] .
                    " ke paas sirf " .
                    $product["stock"] .
                    " stock available hai.";

                break;
            }


            /* Selling price */

            $price = (float)$product["price"];


            /* Item total */

            $item_total =
                $quantity * $price;


            $items[] = [

                "product_id" => $product_id,

                "product_name" =>
                    $product["product_name"],

                "quantity" =>
                    $quantity,

                "price" =>
                    $price,

                "total" =>
                    $item_total

            ];


            $total_amount +=
                $item_total;
        }


        /* -----------------------------------------
           PAID / DUE
        ----------------------------------------- */

        if (empty($error)) {

            if ($paid_amount > $total_amount) {

                $error =
                    "Paid amount total sale se zyada nahi ho sakta.";

            } else {

                $due_amount =
                    $total_amount -
                    $paid_amount;
            }
        }


        /* -----------------------------------------
           SAVE SALE
        ----------------------------------------- */

        if (empty($error)) {

            $conn->begin_transaction();

            try {

                /*
                 * 1. SAVE SALES
                 */

                $sale = $conn->prepare("
                    INSERT INTO sales
                    (
                        customer_name,
                        date,
                        total_amount,
                        paid_amount,
                        due_amount,
                        remarks
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

                $sale->bind_param(
                    "ssddds",
                    $customer_name,
                    $date,
                    $total_amount,
                    $paid_amount,
                    $due_amount,
                    $remarks
                );

                if (!$sale->execute()) {

                    throw new Exception(
                        "Sale save nahi ho saki."
                    );
                }


                /*
                 * Sale ID
                 */

                $sale_id =
                    $conn->insert_id;


                /*
                 * 2. SALE ITEMS
                 */

                $item_stmt = $conn->prepare("
                    INSERT INTO sale_items
                    (
                        sale_id,
                        product_id,
                        quantity,
                        price,
                        total
                    )
                    VALUES (?, ?, ?, ?, ?)
                ");


                /*
                 * 3. STOCK OUT
                 */

                $stock_out_stmt = $conn->prepare("
                    INSERT INTO stock_out
                    (
                        product_id,
                        quantity,
                        date,
                        remarks
                    )
                    VALUES (?, ?, ?, ?)
                ");


                /*
                 * 4. UPDATE PRODUCT STOCK
                 */

                $stock_update = $conn->prepare("
                    UPDATE products
                    SET stock = stock - ?
                    WHERE id = ?
                ");


                foreach ($items as $item) {


                    /*
                     * SALE ITEM
                     */

                    $item_stmt->bind_param(
                        "iiidd",
                        $sale_id,
                        $item["product_id"],
                        $item["quantity"],
                        $item["price"],
                        $item["total"]
                    );

                    if (!$item_stmt->execute()) {

                        throw new Exception(
                            "Sale item save nahi ho saka."
                        );
                    }


                    /*
                     * STOCK OUT
                     */

                    $stock_remarks =
                        "Sale #" .
                        $sale_id .
                        " - " .
                        ($customer_name ?: "Walk-in Customer");


                    $stock_out_stmt->bind_param(
                        "iiss",
                        $item["product_id"],
                        $item["quantity"],
                        $date,
                        $stock_remarks
                    );

                    if (!$stock_out_stmt->execute()) {

                        throw new Exception(
                            "Stock out save nahi ho saka."
                        );
                    }


                    /*
                     * DECREASE STOCK
                     */

                    $stock_update->bind_param(
                        "ii",
                        $item["quantity"],
                        $item["product_id"]
                    );

                    if (!$stock_update->execute()) {

                        throw new Exception(
                            "Product stock update nahi ho saka."
                        );
                    }

                }


                /*
                 * 5. PAYMENT
                 *
                 * Agar paid amount > 0 hai,
                 * to sale_payments mein save karenge.
                 */

                if ($paid_amount > 0) {

                    $payment = $conn->prepare("
                        INSERT INTO sale_payments
                        (
                            sale_id,
                            amount,
                            payment_date,
                            remarks
                        )
                        VALUES (?, ?, ?, ?)
                    ");


                    $payment->bind_param(
                        "idss",
                        $sale_id,
                        $paid_amount,
                        $date,
                        $remarks
                    );


                    /*
                     * Agar tumhare sale_payments
                     * table mein payment_method bhi hai,
                     * to isko baad mein uske according
                     * update karenge.
                     */

                    if (!$payment->execute()) {

                        throw new Exception(
                            "Payment save nahi ho saka."
                        );
                    }

                }


                /*
                 * COMPLETE TRANSACTION
                 */

                $conn->commit();


                /*
                 * SALE COMPLETE
                 */

                header(
                    "Location:view.php"
                );

                exit;


            } catch (Throwable $e) {

                $conn->rollback();

                $error =
                    $e->getMessage();
            }
        }
    }
}


require "../includes/header.php";
require "../includes/sidebar.php";

?>


<div class="w-full">


    <!-- HEADER -->

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">


        <div>

            <div class="flex items-center gap-3">


                <div
                    class="
                        w-12 h-12
                        rounded-2xl
                        bg-blue-50
                        text-blue-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i
                        data-lucide="shopping-cart"
                        class="w-6 h-6"
                    ></i>

                </div>


                <div>

                    <h2 class="text-2xl md:text-3xl font-black text-slate-800">

                        New Sale

                    </h2>


                    <p class="text-sm text-slate-500 mt-1">

                        Create a new customer sale

                    </p>

                </div>

            </div>

        </div>


        <a
            href="view.php"
            class="
                btn
                bg-slate-100
                text-slate-700
                hover:bg-slate-200
            "
        >

            <i
                data-lucide="arrow-left"
                class="w-4 h-4"
            ></i>

            Back to Sales

        </a>


    </div>



    <!-- ERROR -->

    <?php if ($error): ?>

        <div
            class="
                mb-6
                p-4
                rounded-2xl
                bg-red-50
                border
                border-red-100
                text-red-600
            "
        >

            <div class="flex items-center gap-3">

                <i
                    data-lucide="circle-alert"
                    class="w-5 h-5"
                ></i>


                <span>

                    <?= htmlspecialchars($error) ?>

                </span>

            </div>

        </div>

    <?php endif; ?>



    <form
        method="post"
        id="saleForm"
    >


        <div class="grid lg:grid-cols-3 gap-6">


            <!-- LEFT -->

            <div class="lg:col-span-2">


                <!-- CUSTOMER -->

                <div class="card p-6 mb-6">


                    <h3 class="font-black text-lg mb-5">

                        Customer Information

                    </h3>


                    <div class="grid md:grid-cols-2 gap-5">


                        <div>

                            <label class="block text-sm font-bold mb-2">

                                Customer Name

                            </label>


                            <input
                                type="text"
                                name="customer_name"
                                value="<?= htmlspecialchars(
                                    $_POST["customer_name"] ?? ""
                                ) ?>"
                                placeholder="Enter customer name"
                                class="input"
                            >

                        </div>


                        <div>

                            <label class="block text-sm font-bold mb-2">

                                Sale Date

                            </label>


                            <input
                                type="date"
                                name="date"
                                value="<?= htmlspecialchars(
                                    $_POST["date"] ?? date("Y-m-d")
                                ) ?>"
                                required
                                class="input"
                            >

                        </div>


                    </div>

                </div>



                <!-- PRODUCTS -->

                <div class="card p-6">


                    <div class="flex items-center justify-between mb-5">


                        <div>

                            <h3 class="font-black text-lg">

                                Products

                            </h3>


                            <p class="text-sm text-slate-500 mt-1">

                                Add one or more products

                            </p>

                        </div>


                        <button
                            type="button"
                            id="addProduct"
                            class="
                                w-10 h-10
                                rounded-xl
                                bg-blue-600
                                hover:bg-blue-700
                                text-white
                                flex
                                items-center
                                justify-center
                            "
                            title="Add Product"
                        >

                            <i
                                data-lucide="plus"
                                class="w-5 h-5"
                            ></i>

                        </button>


                    </div>



                    <div
                        id="productRows"
                        class="space-y-4"
                    >


                        <!-- FIRST PRODUCT -->

                        <div
                            class="
                                product-row
                                p-4
                                rounded-2xl
                                bg-slate-50
                                border
                                border-slate-200
                            "
                        >


                            <div class="grid md:grid-cols-12 gap-3 items-end">


                                <!-- PRODUCT -->

                                <div class="md:col-span-5">


                                    <label class="block text-xs font-bold text-slate-500 mb-2">

                                        Product

                                    </label>


                                    <select
                                        name="product_id[]"
                                        class="product-select input"
                                        required
                                    >

                                        <option value="">

                                            Select Product

                                        </option>


                                        <?php foreach ($products as $p): ?>

                                            <option
                                                value="<?= $p["id"] ?>"
                                                data-price="<?= $p["price"] ?>"
                                                data-stock="<?= $p["stock"] ?>"
                                            >

                                                <?= htmlspecialchars(
                                                    $p["product_name"]
                                                ) ?>

                                                — Stock:
                                                <?= $p["stock"] ?>

                                            </option>

                                        <?php endforeach; ?>

                                    </select>


                                    <div
                                        class="
                                            stock-info
                                            text-xs
                                            mt-2
                                            text-slate-400
                                        "
                                    >

                                        Select product

                                    </div>


                                </div>



                                <!-- PRICE -->

                                <div class="md:col-span-2">


                                    <label class="block text-xs font-bold text-slate-500 mb-2">

                                        Price

                                    </label>


                                    <input
                                        type="number"
                                        class="price-input input"
                                        readonly
                                        value="0"
                                    >

                                </div>



                                <!-- QUANTITY -->

                                <div class="md:col-span-2">


                                    <label class="block text-xs font-bold text-slate-500 mb-2">

                                        Quantity

                                    </label>


                                    <input
                                        type="number"
                                        name="quantity[]"
                                        class="quantity-input input"
                                        min="1"
                                        value="1"
                                        required
                                    >

                                </div>



                                <!-- TOTAL -->

                                <div class="md:col-span-2">


                                    <label class="block text-xs font-bold text-slate-500 mb-2">

                                        Total

                                    </label>


                                    <div
                                        class="
                                            row-total
                                            h-[46px]
                                            rounded-xl
                                            bg-white
                                            border
                                            border-slate-200
                                            flex
                                            items-center
                                            px-4
                                            font-black
                                            text-blue-600
                                        "
                                    >

                                        ₹0.00

                                    </div>

                                </div>



                                <!-- REMOVE -->

                                <div class="md:col-span-1">


                                    <button
                                        type="button"
                                        class="
                                            remove-row
                                            w-full
                                            h-[46px]
                                            rounded-xl
                                            bg-red-50
                                            text-red-600
                                            flex
                                            items-center
                                            justify-center
                                            hover:bg-red-100
                                        "
                                        title="Remove"
                                    >

                                        <i
                                            data-lucide="trash-2"
                                            class="w-4"
                                        ></i>

                                    </button>


                                </div>


                            </div>


                        </div>


                    </div>



                    <!-- REMARKS -->

                    <div class="mt-5">


                        <label class="block text-sm font-bold mb-2">

                            Remarks

                        </label>


                        <textarea
                            name="remarks"
                            rows="3"
                            class="input resize-none"
                            placeholder="Sale remarks..."
                        ><?= htmlspecialchars(
                            $_POST["remarks"] ?? ""
                        ) ?></textarea>


                    </div>


                </div>


            </div>



            <!-- RIGHT -->

            <div>


                <div class="card p-6 sticky top-24">


                    <h3 class="font-black text-lg mb-6">

                        Sale Summary

                    </h3>



                    <!-- TOTAL -->

                    <div
                        class="
                            p-5
                            rounded-2xl
                            bg-blue-50
                            mb-5
                        "
                    >

                        <div class="text-sm text-blue-600">

                            Total Sale

                        </div>


                        <div
                            id="totalAmount"
                            class="
                                text-3xl
                                font-black
                                text-blue-700
                                mt-1
                            "
                        >

                            ₹0.00

                        </div>

                    </div>



                    <!-- PAID -->

                    <div class="mb-5">


                        <label class="block text-sm font-bold mb-2">

                            Paid Amount

                        </label>


                        <div class="relative">


                            <span
                                class="
                                    absolute
                                    left-4
                                    top-1/2
                                    -translate-y-1/2
                                    font-bold
                                    text-slate-500
                                "
                            >

                                ₹

                            </span>


                            <input
                                type="number"
                                name="paid_amount"
                                id="paidAmount"
                                min="0"
                                step="0.01"
                                value="<?= htmlspecialchars(
                                    $_POST["paid_amount"] ?? "0"
                                ) ?>"
                                class="input pl-9"
                            >

                        </div>

                    </div>



                    <!-- DUE -->

                    <div
                        class="
                            p-5
                            rounded-2xl
                            bg-red-50
                            mb-6
                        "
                    >

                        <div class="text-sm text-red-600">

                            Due Amount

                        </div>


                        <div
                            id="dueAmount"
                            class="
                                text-2xl
                                font-black
                                text-red-600
                                mt-1
                            "
                        >

                            ₹0.00

                        </div>

                    </div>



                    <!-- SUBMIT -->

                    <button
                        type="submit"
                        class="
                            w-full
                            bg-blue-600
                            hover:bg-blue-700
                            text-white
                            py-3.5
                            rounded-xl
                            font-bold
                            flex
                            items-center
                            justify-center
                            gap-2
                            shadow-lg
                            shadow-blue-600/20
                        "
                    >

                        <i
                            data-lucide="check"
                            class="w-5"
                        ></i>

                        Complete Sale

                    </button>


                    <a
                        href="view.php"
                        class="
                            block
                            text-center
                            mt-3
                            py-3
                            rounded-xl
                            bg-slate-100
                            text-slate-700
                            font-bold
                        "
                    >

                        Cancel

                    </a>


                </div>

            </div>


        </div>


    </form>

</div>



<script>

/*
|--------------------------------------------------------------------------
| PRODUCT ROW
|--------------------------------------------------------------------------
*/

const productRows =
    document.getElementById(
        "productRows"
    );

const addProduct =
    document.getElementById(
        "addProduct"
    );

const totalAmount =
    document.getElementById(
        "totalAmount"
    );

const paidAmount =
    document.getElementById(
        "paidAmount"
    );

const dueAmount =
    document.getElementById(
        "dueAmount"
    );


/*
|--------------------------------------------------------------------------
| UPDATE TOTAL
|--------------------------------------------------------------------------
*/

function updateTotals() {

    let total = 0;


    document
        .querySelectorAll(".product-row")
        .forEach(function(row) {


            const select =
                row.querySelector(
                    ".product-select"
                );


            const quantity =
                parseInt(
                    row.querySelector(
                        ".quantity-input"
                    ).value || 0
                );


            const price =
                parseFloat(
                    row.querySelector(
                        ".price-input"
                    ).value || 0
                );


            const rowTotal =
                quantity * price;


            row.querySelector(
                ".row-total"
            ).textContent =
                "₹" +
                rowTotal.toFixed(2);


            total += rowTotal;

        });


    totalAmount.textContent =
        "₹" +
        total.toFixed(2);


    let paid =
        parseFloat(
            paidAmount.value || 0
        );


    if (paid > total) {

        paid = total;

        paidAmount.value =
            total.toFixed(2);
    }


    const due =
        total - paid;


    dueAmount.textContent =
        "₹" +
        due.toFixed(2);

}


/*
|--------------------------------------------------------------------------
| PRODUCT CHANGE
|--------------------------------------------------------------------------
*/

function setupRow(row) {


    const select =
        row.querySelector(
            ".product-select"
        );


    const price =
        row.querySelector(
            ".price-input"
        );


    const quantity =
        row.querySelector(
            ".quantity-input"
        );


    const stockInfo =
        row.querySelector(
            ".stock-info"
        );


    select.addEventListener(
        "change",
        function() {


            const option =
                select.options[
                    select.selectedIndex
                ];


            if (!option.value) {

                price.value = 0;

                stockInfo.textContent =
                    "Select product";

                stockInfo.className =
                    "stock-info text-xs mt-2 text-slate-400";

                updateTotals();

                return;
            }


            const productPrice =
                parseFloat(
                    option.dataset.price || 0
                );


            const stock =
                parseInt(
                    option.dataset.stock || 0
                );


            price.value =
                productPrice.toFixed(2);


            if (stock <= 0) {

                stockInfo.textContent =
                    "OUT OF STOCK";

                stockInfo.className =
                    "stock-info text-xs mt-2 text-red-600 font-bold";

            } else {

                stockInfo.textContent =
                    "Available Stock: " +
                    stock;

                stockInfo.className =
                    "stock-info text-xs mt-2 text-emerald-600 font-semibold";

            }


            quantity.max =
                stock;


            updateTotals();

        }
    );


    quantity.addEventListener(
        "input",
        function() {

            const option =
                select.options[
                    select.selectedIndex
                ];


            if (option && option.value) {

                const stock =
                    parseInt(
                        option.dataset.stock || 0
                    );


                if (
                    parseInt(
                        quantity.value || 0
                    ) > stock
                ) {

                    quantity.value =
                        stock;
                }

            }


            updateTotals();

        }
    );


    row.querySelector(
        ".remove-row"
    ).addEventListener(
        "click",
        function() {


            const rows =
                document.querySelectorAll(
                    ".product-row"
                );


            if (rows.length > 1) {

                row.remove();

                updateTotals();

            } else {

                alert(
                    "At least one product is required."
                );

            }

        }
    );

}


/*
|--------------------------------------------------------------------------
| FIRST ROW
|--------------------------------------------------------------------------
*/

setupRow(
    document.querySelector(
        ".product-row"
    )
);


/*
|--------------------------------------------------------------------------
| ADD NEW PRODUCT
|--------------------------------------------------------------------------
*/

addProduct.addEventListener(
    "click",
    function() {


        const firstRow =
            document.querySelector(
                ".product-row"
            );


        const newRow =
            firstRow.cloneNode(true);


        newRow.querySelector(
            ".product-select"
        ).value = "";


        newRow.querySelector(
            ".price-input"
        ).value = "0";


        newRow.querySelector(
            ".quantity-input"
        ).value = "1";


        newRow.querySelector(
            ".row-total"
        ).textContent =
            "₹0.00";


        newRow.querySelector(
            ".stock-info"
        ).textContent =
            "Select product";


        newRow.querySelector(
            ".stock-info"
        ).className =
            "stock-info text-xs mt-2 text-slate-400";


        productRows.appendChild(
            newRow
        );


        setupRow(
            newRow
        );


        if (window.lucide) {

            lucide.createIcons();

        }


        updateTotals();

    }
);


/*
|--------------------------------------------------------------------------
| PAID AMOUNT
|--------------------------------------------------------------------------
*/

paidAmount.addEventListener(
    "input",
    updateTotals
);


/*
|--------------------------------------------------------------------------
| FORM VALIDATION
|--------------------------------------------------------------------------
*/

document
    .getElementById("saleForm")
    .addEventListener(
        "submit",
        function(e) {


            let valid = true;


            const selects =
                document.querySelectorAll(
                    ".product-select"
                );


            const quantities =
                document.querySelectorAll(
                    ".quantity-input"
                );


            selects.forEach(
                function(select, index) {


                    const option =
                        select.options[
                            select.selectedIndex
                        ];


                    if (!select.value) {

                        valid = false;

                    }


                    if (option && option.value) {

                        const stock =
                            parseInt(
                                option.dataset.stock || 0
                            );


                        const quantity =
                            parseInt(
                                quantities[index].value || 0
                            );


                        if (
                            stock <= 0 ||
                            quantity < 1 ||
                            quantity > stock
                        ) {

                            valid = false;

                        }

                    }

                }
            );


            if (!valid) {

                e.preventDefault();

                alert(
                    "Please check product and quantity. Out of stock product cannot be sold."
                );

            }

        }
    );


/*
|--------------------------------------------------------------------------
| ICONS
|--------------------------------------------------------------------------
*/

if (window.lucide) {

    lucide.createIcons();

}


updateTotals();

</script>


<?php require "../includes/footer.php"; ?>