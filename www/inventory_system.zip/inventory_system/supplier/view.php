<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Suppliers";

require "../includes/header.php";
require "../includes/sidebar.php";

$q = trim($_GET['q'] ?? '');
$like = "%$q%";

$s = $conn->prepare("
    SELECT *
    FROM supplier
    WHERE supplier_name LIKE ?
       OR mobile LIKE ?
       OR email LIKE ?
    ORDER BY id DESC
");

$s->bind_param("sss", $like, $like, $like);
$s->execute();

$rows = $s->get_result();

$totalSuppliers = $conn->query("
    SELECT COUNT(*) AS total
    FROM supplier
")->fetch_assoc()['total'];

?>

<div class="w-full">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">

        <div>

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-11 h-11
                        rounded-2xl
                        bg-emerald-50
                        text-emerald-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i data-lucide="truck" class="w-5 h-5"></i>

                </div>

                <div>

                    <h2 class="text-2xl font-bold text-slate-800">
                        Suppliers
                    </h2>

                    <p class="text-sm text-slate-500 mt-1">
                        Manage your suppliers and contact information
                    </p>

                </div>

            </div>

        </div>


        <a
            href="add.php"
            class="
                btn
                bg-blue-600
                hover:bg-blue-700
                text-white
                shadow-lg
                shadow-blue-600/20
            "
        >

            <i data-lucide="plus" class="w-4 h-4"></i>

            Add Supplier

        </a>

    </div>


    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">

        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-emerald-50
                        text-emerald-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i data-lucide="truck" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Total Suppliers
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">
                        <?= number_format($totalSuppliers) ?>
                    </h3>

                </div>

            </div>

        </div>


        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-blue-50
                        text-blue-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i data-lucide="search" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Search Results
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">
                        <?= $rows->num_rows ?>
                    </h3>

                </div>

            </div>

        </div>


        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-violet-50
                        text-violet-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i data-lucide="contact-round" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Supplier Network
                    </p>

                    <h3 class="text-lg font-bold text-slate-800">
                        Active
                    </h3>

                </div>

            </div>

        </div>

    </div>


    <div class="card overflow-hidden">

        <div
            class="
                p-5
                md:p-6
                border-b
                border-slate-100
                flex
                flex-col
                lg:flex-row
                lg:items-center
                justify-between
                gap-4
            "
        >

            <div>

                <h3 class="font-bold text-lg text-slate-800">
                    Supplier List
                </h3>

                <p class="text-sm text-slate-500 mt-1">
                    View and manage all suppliers
                </p>

            </div>


            <form
                method="get"
                class="
                    flex
                    w-full
                    lg:w-auto
                    gap-2
                "
            >

                <div class="relative flex-1 lg:w-80">

                    <i
                        data-lucide="search"
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            w-4
                            text-slate-400
                        "
                    ></i>

                    <input
                        type="text"
                        name="q"
                        value="<?= htmlspecialchars($q) ?>"
                        placeholder="Search supplier..."
                        class="input pl-11"
                    >

                </div>


                <button
                    type="submit"
                    class="
                        btn
                        bg-slate-900
                        hover:bg-slate-800
                        text-white
                        px-5
                    "
                >

                    Search

                </button>


                <?php if ($q): ?>

                    <a
                        href="view.php"
                        class="
                            btn
                            bg-slate-100
                            hover:bg-slate-200
                            text-slate-700
                        "
                    >

                        Clear

                    </a>

                <?php endif; ?>

            </form>

        </div>


        <div class="table-wrap">

            <table class="table">

                <thead>

                    <tr>

                        <th>
                            Supplier
                        </th>

                        <th>
                            Contact Person
                        </th>

                        <th>
                            Mobile
                        </th>

                        <th>
                            Email
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody>

                    <?php if ($rows->num_rows > 0): ?>

                        <?php while ($r = $rows->fetch_assoc()): ?>

                            <tr>

                                <td>

                                    <div class="flex items-center gap-3">

                                        <div
                                            class="
                                                w-10 h-10
                                                rounded-xl
                                                bg-emerald-50
                                                text-emerald-600
                                                flex
                                                items-center
                                                justify-center
                                            "
                                        >

                                            <i
                                                data-lucide="building-2"
                                                class="w-5"
                                            ></i>

                                        </div>


                                        <div>

                                            <div
                                                class="
                                                    font-semibold
                                                    text-slate-800
                                                "
                                            >

                                                <?= htmlspecialchars(
                                                    $r['supplier_name']
                                                ) ?>

                                            </div>

                                            <div
                                                class="
                                                    text-xs
                                                    text-slate-400
                                                "
                                            >

                                                Supplier #<?= $r['id'] ?>

                                            </div>

                                        </div>

                                    </div>

                                </td>


                                <td>

                                    <?php if (!empty($r['contact_person'])): ?>

                                        <div
                                            class="
                                                flex
                                                items-center
                                                gap-2
                                                text-slate-600
                                            "
                                        >

                                            <i
                                                data-lucide="user-round"
                                                class="w-4 text-slate-400"
                                            ></i>

                                            <?= htmlspecialchars(
                                                $r['contact_person']
                                            ) ?>

                                        </div>

                                    <?php else: ?>

                                        <span class="text-slate-400">
                                            -
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <?php if (!empty($r['mobile'])): ?>

                                        <a
                                            href="tel:<?= htmlspecialchars($r['mobile']) ?>"
                                            class="
                                                inline-flex
                                                items-center
                                                gap-2
                                                text-slate-600
                                                hover:text-blue-600
                                            "
                                        >

                                            <i
                                                data-lucide="phone"
                                                class="w-4 text-slate-400"
                                            ></i>

                                            <?= htmlspecialchars(
                                                $r['mobile']
                                            ) ?>

                                        </a>

                                    <?php else: ?>

                                        <span class="text-slate-400">
                                            -
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <?php if (!empty($r['email'])): ?>

                                        <a
                                            href="mailto:<?= htmlspecialchars($r['email']) ?>"
                                            class="
                                                inline-flex
                                                items-center
                                                gap-2
                                                text-slate-600
                                                hover:text-blue-600
                                            "
                                        >

                                            <i
                                                data-lucide="mail"
                                                class="w-4 text-slate-400"
                                            ></i>

                                            <?= htmlspecialchars(
                                                $r['email']
                                            ) ?>

                                        </a>

                                    <?php else: ?>

                                        <span class="text-slate-400">
                                            -
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <span
                                        class="
                                            badge
                                            bg-emerald-50
                                            text-emerald-700
                                        "
                                    >

                                        <span
                                            class="
                                                w-1.5 h-1.5
                                                rounded-full
                                                bg-emerald-500
                                                mr-1.5
                                            "
                                        ></span>

                                        Active

                                    </span>

                                </td>


                                <td>

                                    <div class="flex items-center gap-2">

                                        <a
                                            href="edit.php?id=<?= $r['id'] ?>"
                                            class="
                                                inline-flex
                                                items-center
                                                gap-1.5
                                                px-3
                                                py-2
                                                rounded-xl
                                                bg-blue-50
                                                text-blue-600
                                                hover:bg-blue-100
                                                text-xs
                                                font-semibold
                                                transition
                                            "
                                        >

                                            <i
                                                data-lucide="pencil"
                                                class="w-4"
                                            ></i>

                                            Edit

                                        </a>


                                        <a
                                            href="delete.php?id=<?= $r['id'] ?>"
                                            onclick="return confirm('Are you sure you want to delete this supplier?')"
                                            class="
                                                inline-flex
                                                items-center
                                                gap-1.5
                                                px-3
                                                py-2
                                                rounded-xl
                                                bg-red-50
                                                text-red-600
                                                hover:bg-red-100
                                                text-xs
                                                font-semibold
                                                transition
                                            "
                                        >

                                            <i
                                                data-lucide="trash-2"
                                                class="w-4"
                                            ></i>

                                            Delete

                                        </a>

                                    </div>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>

                            <td
                                colspan="6"
                                class="text-center py-12"
                            >

                                <div class="flex flex-col items-center">

                                    <div
                                        class="
                                            w-14 h-14
                                            rounded-2xl
                                            bg-slate-100
                                            text-slate-400
                                            flex
                                            items-center
                                            justify-center
                                            mb-3
                                        "
                                    >

                                        <i
                                            data-lucide="truck"
                                            class="w-7"
                                        ></i>

                                    </div>


                                    <h3 class="font-semibold text-slate-700">
                                        No suppliers found
                                    </h3>


                                    <p class="text-sm text-slate-400 mt-1">

                                        <?php if ($q): ?>

                                            No supplier matches
                                            "<?= htmlspecialchars($q) ?>".

                                        <?php else: ?>

                                            Add your first supplier to get started.

                                        <?php endif; ?>

                                    </p>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<?php

require "../includes/footer.php";

?>