<?php

require "../includes/auth.php";
require "../includes/connection.php";

$id = (int)($_GET['id'] ?? 0);

if ($id < 1) {
    header("Location: view.php");
    exit;
}

$s = $conn->prepare("
    DELETE FROM supplier
    WHERE id = ?
");

$s->bind_param("i", $id);
$s->execute();

header("Location: view.php");
exit;

?>