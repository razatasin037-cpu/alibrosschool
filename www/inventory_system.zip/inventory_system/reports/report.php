<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Reports";

$in_result = $conn->query("
    SELECT COALESCE(SUM(quantity), 0) AS total
    FROM stock_in
");

$in = $in_result->fetch_assoc()['total'];


$out_result = $conn->query("
    SELECT COALESCE(SUM(quantity), 0) AS total
    FROM stock_out
");

$out = $out_result->fetch_assoc()['total'];


$stock_result = $conn->query("
    SELECT COALESCE(SUM(stock), 0) AS total
    FROM products
");

$stock = $stock_result->fetch_assoc()['total'];


$profit_result = $conn->query("
    SELECT
        COALESCE(SUM(so.quantity * p.price), 0) AS sales,
        COALESCE(SUM(so.quantity * p.purchase_price), 0) AS cost
    FROM stock_out so
    JOIN products p
        ON p.id = so.product_id
");

$profit_data = $profit_result->fetch_assoc();

$sales = (float)$profit_data['sales'];

$sales_cost = (float)$profit_data['cost'];

$profit = $sales - $sales_cost;


$stock_value_result = $conn->query("
    SELECT
        COALESCE(SUM(stock * purchase_price), 0) AS total
    FROM products
");

$stock_value = $stock_value_result->fetch_assoc()['total'];


require "../includes/header.php";
require "../includes/sidebar.php";

?>


<div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-7">

    <div>

        <div class="flex items-center gap-3">

            <div class="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">

                <i
                    data-lucide="chart-no-axes-combined"
                    class="w-6 h-6"
                ></i>

            </div>

            <div>

                <h1 class="text-2xl md:text-3xl font-black text-slate-800">
                    Reports & Analytics
                </h1>

                <p class="text-sm text-slate-500 mt-1">
                    Complete overview of your inventory and sales
                </p>

            </div>

        </div>

    </div>


    <button
        onclick="window.print()"
        class="btn bg-slate-900 hover:bg-slate-800 text-white shadow-lg"
    >

        <i data-lucide="printer" class="w-4 h-4"></i>

        Print Report

    </button>

</div>



<div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5 mb-6">


    <div class="card p-6">

        <div class="flex items-center justify-between">

            <div>

                <p class="text-sm text-slate-500 font-semibold">
                    Stock In
                </p>

                <h2 class="text-3xl font-black text-slate-800 mt-2">
                    <?= number_format($in) ?>
                </h2>

                <p class="text-xs text-emerald-600 mt-2 font-semibold">
                    Incoming quantity
                </p>

            </div>

            <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">

                <i
                    data-lucide="arrow-down-to-line"
                    class="w-5 h-5"
                ></i>

            </div>

        </div>

    </div>



    <div class="card p-6">

        <div class="flex items-center justify-between">

            <div>

                <p class="text-sm text-slate-500 font-semibold">
                    Stock Out
                </p>

                <h2 class="text-3xl font-black text-slate-800 mt-2">
                    <?= number_format($out) ?>
                </h2>

                <p class="text-xs text-orange-600 mt-2 font-semibold">
                    Sold quantity
                </p>

            </div>

            <div class="w-12 h-12 rounded-2xl bg-orange-50 text-orange-600 flex items-center justify-center">

                <i
                    data-lucide="shopping-cart"
                    class="w-5 h-5"
                ></i>

            </div>

        </div>

    </div>



    <div class="card p-6">

        <div class="flex items-center justify-between">

            <div>

                <p class="text-sm text-slate-500 font-semibold">
                    Current Stock
                </p>

                <h2 class="text-3xl font-black text-slate-800 mt-2">
                    <?= number_format($stock) ?>
                </h2>

                <p class="text-xs text-blue-600 mt-2 font-semibold">
                    Available quantity
                </p>

            </div>

            <div class="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">

                <i
                    data-lucide="boxes"
                    class="w-5 h-5"
                ></i>

            </div>

        </div>

    </div>



    <div class="card p-6">

        <div class="flex items-center justify-between">

            <div>

                <p class="text-sm text-slate-500 font-semibold">
                    Sales Value
                </p>

                <h2 class="text-2xl font-black text-slate-800 mt-2">
                    ₹<?= number_format($sales, 2) ?>
                </h2>

                <p class="text-xs text-violet-600 mt-2 font-semibold">
                    Total selling amount
                </p>

            </div>

            <div class="w-12 h-12 rounded-2xl bg-violet-50 text-violet-600 flex items-center justify-center">

                <i
                    data-lucide="indian-rupee"
                    class="w-5 h-5"
                ></i>

            </div>

        </div>

    </div>

</div>



<div class="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">


    <div class="card p-6">

        <div class="flex items-center gap-4">

            <div class="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center">

                <i
                    data-lucide="wallet-cards"
                    class="w-5 h-5"
                ></i>

            </div>

            <div>

                <p class="text-sm text-slate-500 font-semibold">
                    Sales Cost
                </p>

                <h2 class="text-2xl font-black text-slate-800 mt-1">
                    ₹<?= number_format($sales_cost, 2) ?>
                </h2>

                <p class="text-xs text-slate-400 mt-1">
                    Purchase cost of sold items
                </p>

            </div>

        </div>

    </div>



    <div class="card p-6">

        <div class="flex items-center gap-4">

            <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">

                <i
                    data-lucide="trending-up"
                    class="w-5 h-5"
                ></i>

            </div>

            <div>

                <p class="text-sm text-slate-500 font-semibold">
                    Net Profit
                </p>

                <h2 class="text-2xl font-black text-emerald-600 mt-1">
                    ₹<?= number_format($profit, 2) ?>
                </h2>

                <p class="text-xs text-slate-400 mt-1">
                    Sales minus purchase cost
                </p>

            </div>

        </div>

    </div>



    <div class="card p-6">

        <div class="flex items-center gap-4">

            <div class="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">

                <i
                    data-lucide="warehouse"
                    class="w-5 h-5"
                ></i>

            </div>

            <div>

                <p class="text-sm text-slate-500 font-semibold">
                    Stock Value
                </p>

                <h2 class="text-2xl font-black text-slate-800 mt-1">
                    ₹<?= number_format($stock_value, 2) ?>
                </h2>

                <p class="text-xs text-slate-400 mt-1">
                    Current stock purchase value
                </p>

            </div>

        </div>

    </div>

</div>



<div class="card overflow-hidden">

    <div class="p-6 border-b border-slate-100">

        <div>

            <h2 class="text-lg font-black text-slate-800">
                Current Inventory
            </h2>

            <p class="text-sm text-slate-500 mt-1">
                Product-wise stock and profit information
            </p>

        </div>

    </div>


    <div class="table-wrap">

        <table class="table">

            <thead>

                <tr>

                    <th>#</th>

                    <th>Product</th>

                    <th>Stock</th>

                    <th>Purchase Price</th>

                    <th>Sale Price</th>

                    <th>Profit / Unit</th>

                    <th>Stock Value</th>

                    <th>Status</th>

                </tr>

            </thead>


            <tbody>

                <?php

                $products = $conn->query("
                    SELECT
                        product_name,
                        stock,
                        purchase_price,
                        price
                    FROM products
                    ORDER BY product_name
                ");

                $count = 1;

                while ($product = $products->fetch_assoc()):

                    $unit_profit =
                        $product['price'] -
                        $product['purchase_price'];

                    $current_stock_value =
                        $product['stock'] *
                        $product['purchase_price'];

                ?>

                <tr>

                    <td>
                        <?= $count++ ?>
                    </td>


                    <td>

                        <div class="font-semibold text-slate-800">

                            <?= htmlspecialchars(
                                $product['product_name']
                            ) ?>

                        </div>

                    </td>


                    <td>

                        <span class="badge bg-blue-50 text-blue-700">

                            <?= number_format(
                                $product['stock']
                            ) ?>

                        </span>

                    </td>


                    <td>

                        ₹<?= number_format(
                            $product['purchase_price'],
                            2
                        ) ?>

                    </td>


                    <td>

                        ₹<?= number_format(
                            $product['price'],
                            2
                        ) ?>

                    </td>


                    <td>

                        <?php if ($unit_profit >= 0): ?>

                            <span class="font-bold text-emerald-600">

                                ₹<?= number_format(
                                    $unit_profit,
                                    2
                                ) ?>

                            </span>

                        <?php else: ?>

                            <span class="font-bold text-red-600">

                                -₹<?= number_format(
                                    abs($unit_profit),
                                    2
                                ) ?>

                            </span>

                        <?php endif; ?>

                    </td>


                    <td>

                        ₹<?= number_format(
                            $current_stock_value,
                            2
                        ) ?>

                    </td>


                    <td>

                        <?php if ($product['stock'] <= 0): ?>

                            <span class="badge bg-red-50 text-red-600">
                                Out of Stock
                            </span>

                        <?php elseif ($product['stock'] <= 5): ?>

                            <span class="badge bg-amber-50 text-amber-700">
                                Low Stock
                            </span>

                        <?php else: ?>

                            <span class="badge bg-emerald-50 text-emerald-700">
                                In Stock
                            </span>

                        <?php endif; ?>

                    </td>

                </tr>

                <?php endwhile; ?>

            </tbody>

        </table>

    </div>

</div>



<div class="mt-6 card p-6">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-5">

        <div>

            <h3 class="font-black text-lg text-slate-800">
                Profit Summary
            </h3>

            <p class="text-sm text-slate-500 mt-1">
                Total sales minus the purchase cost of sold products.
            </p>

        </div>


        <div class="text-left md:text-right">

            <div class="text-xs uppercase tracking-wider text-slate-400 font-bold">
                Net Profit
            </div>

            <div class="text-3xl font-black text-emerald-600 mt-1">

                ₹<?= number_format(
                    $profit,
                    2
                ) ?>

            </div>

        </div>

    </div>

</div>



<style>

@media print {

    body {
        background: white !important;
    }

    #sidebar,
    #backdrop,
    header,
    button,
    .btn {
        display: none !important;
    }

    main {
        padding: 0 !important;
        max-width: none !important;
    }

    .card {
        box-shadow: none !important;
        border: 1px solid #ddd !important;
        break-inside: avoid;
    }

    .table {
        width: 100% !important;
    }

    .table th,
    .table td {
        color: #000 !important;
    }

}

</style>


<?php require "../includes/footer.php"; ?>