<?php
require "includes/connection.php";
$name="Admin"; $email="admin@gmail.com"; $password=password_hash("admin123",PASSWORD_DEFAULT);
$stmt=$conn->prepare("SELECT id FROM users WHERE email=?"); $stmt->bind_param("s",$email); $stmt->execute();
if($stmt->get_result()->num_rows==0){
 $role="admin"; $stmt=$conn->prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)");
 $stmt->bind_param("ssss",$name,$email,$password,$role); $stmt->execute();
 echo "Admin created. Email: admin@gmail.com | Password: admin123";
}else echo "Admin already exists.";
?>