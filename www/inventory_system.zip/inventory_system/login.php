<?php

session_start();

require "includes/connection.php";

if (isset($_SESSION['user_id'])) {
    header("Location: admin/dashboard.php");
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $s = $conn->prepare("
        SELECT *
        FROM users
        WHERE email = ?
        LIMIT 1
    ");

    $s->bind_param("s", $email);
    $s->execute();

    $u = $s->get_result()->fetch_assoc();

    if (
        $u &&
        $u['status'] === 'active' &&
        password_verify($password, $u['password'])
    ) {

        $_SESSION['user_id'] = $u['id'];
        $_SESSION['user_name'] = $u['name'];
        $_SESSION['user_role'] = $u['role'];

        header("Location: admin/dashboard.php");
        exit;
    }

    $error = "Email or password is incorrect.";
}

?>

<!doctype html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Sign In | Inventory Pro</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <script src="https://unpkg.com/lucide@latest"></script>

</head>


<body class="min-h-screen bg-slate-950 text-slate-900">

<div class="min-h-screen grid lg:grid-cols-2">


    <div
        class="
            hidden
            lg:flex
            relative
            overflow-hidden
            flex-col
            justify-between
            p-12
            bg-gradient-to-br
            from-[#06101d]
            via-blue-950
            to-indigo-950
            text-white
        "
    >

        <div
            class="
                absolute
                -top-32
                -left-32
                w-96
                h-96
                rounded-full
                bg-blue-500/20
                blur-3xl
            "
        ></div>


        <div
            class="
                absolute
                -bottom-32
                -right-32
                w-96
                h-96
                rounded-full
                bg-indigo-500/20
                blur-3xl
            "
        ></div>


        <div class="relative">

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-12
                        h-12
                        rounded-2xl
                        bg-gradient-to-br
                        from-blue-500
                        to-indigo-600
                        flex
                        items-center
                        justify-center
                        shadow-lg
                        shadow-blue-600/30
                    "
                >

                    <i
                        data-lucide="boxes"
                        class="w-6 h-6"
                    ></i>

                </div>


                <div>

                    <div class="text-xl font-black">

                        Inventory<span class="text-blue-400">Pro</span>

                    </div>

                    <div class="text-[10px] text-slate-500 tracking-[.2em]">
                        CONTROL CENTER
                    </div>

                </div>

            </div>

        </div>


        <div class="relative max-w-xl">

            <div
                class="
                    inline-flex
                    items-center
                    gap-2
                    px-3
                    py-1.5
                    rounded-full
                    bg-blue-500/10
                    border
                    border-blue-400/10
                    text-blue-300
                    text-xs
                    font-bold
                    mb-5
                "
            >

                <span
                    class="
                        w-2
                        h-2
                        rounded-full
                        bg-emerald-400
                    "
                ></span>

                SMART INVENTORY CONTROL

            </div>


            <h1
                class="
                    text-5xl
                    xl:text-6xl
                    font-black
                    leading-[1.05]
                    tracking-tight
                "
            >

                Everything you need
                to manage inventory.

            </h1>


            <p
                class="
                    text-slate-400
                    mt-6
                    text-lg
                    leading-relaxed
                    max-w-lg
                "
            >

                Track products, stock movement, suppliers
                and sales from one powerful workspace.

            </p>


            <div class="grid grid-cols-3 gap-3 mt-9">

                <div
                    class="
                        bg-white/5
                        border
                        border-white/10
                        rounded-2xl
                        p-4
                        backdrop-blur-sm
                    "
                >

                    <div
                        class="
                            w-9
                            h-9
                            rounded-xl
                            bg-blue-500/10
                            text-blue-400
                            flex
                            items-center
                            justify-center
                        "
                    >

                        <i
                            data-lucide="package"
                            class="w-4 h-4"
                        ></i>

                    </div>

                    <div class="mt-3 text-sm font-bold">
                        Products
                    </div>

                    <div class="text-[10px] text-slate-500 mt-1">
                        Manage
                    </div>

                </div>


                <div
                    class="
                        bg-white/5
                        border
                        border-white/10
                        rounded-2xl
                        p-4
                        backdrop-blur-sm
                    "
                >

                    <div
                        class="
                            w-9
                            h-9
                            rounded-xl
                            bg-emerald-500/10
                            text-emerald-400
                            flex
                            items-center
                            justify-center
                        "
                    >

                        <i
                            data-lucide="truck"
                            class="w-4 h-4"
                        ></i>

                    </div>

                    <div class="mt-3 text-sm font-bold">
                        Suppliers
                    </div>

                    <div class="text-[10px] text-slate-500 mt-1">
                        Manage
                    </div>

                </div>


                <div
                    class="
                        bg-white/5
                        border
                        border-white/10
                        rounded-2xl
                        p-4
                        backdrop-blur-sm
                    "
                >

                    <div
                        class="
                            w-9
                            h-9
                            rounded-xl
                            bg-violet-500/10
                            text-violet-400
                            flex
                            items-center
                            justify-center
                        "
                    >

                        <i
                            data-lucide="chart-no-axes-combined"
                            class="w-4 h-4"
                        ></i>

                    </div>

                    <div class="mt-3 text-sm font-bold">
                        Reports
                    </div>

                    <div class="text-[10px] text-slate-500 mt-1">
                        Analyze
                    </div>

                </div>

            </div>

        </div>


        <div
            class="
                relative
                text-xs
                text-slate-600
            "
        >

            Inventory Pro
            <span class="mx-2">•</span>
            Secure Management Workspace

        </div>

    </div>


    <div
        class="
            bg-white
            flex
            items-center
            justify-center
            p-6
            md:p-12
        "
    >

        <div class="w-full max-w-md">


            <div class="lg:hidden flex justify-center mb-8">

                <div
                    class="
                        w-14
                        h-14
                        rounded-2xl
                        bg-gradient-to-br
                        from-blue-500
                        to-indigo-600
                        text-white
                        flex
                        items-center
                        justify-center
                        shadow-lg
                        shadow-blue-600/20
                    "
                >

                    <i
                        data-lucide="boxes"
                        class="w-7 h-7"
                    ></i>

                </div>

            </div>


            <div class="mb-8">

                <div
                    class="
                        inline-flex
                        items-center
                        gap-2
                        text-blue-600
                        font-bold
                        text-xs
                        tracking-wider
                        mb-3
                    "
                >

                    <span
                        class="
                            w-2
                            h-2
                            rounded-full
                            bg-blue-600
                        "
                    ></span>

                    WELCOME BACK

                </div>


                <h2
                    class="
                        text-3xl
                        md:text-4xl
                        font-black
                        tracking-tight
                        text-slate-900
                    "
                >

                    Sign in to your
                    workspace.

                </h2>


                <p class="text-slate-500 mt-3">

                    Enter your account details to continue.

                </p>

            </div>


            <?php if ($error): ?>

                <div
                    class="
                        mb-6
                        p-4
                        rounded-2xl
                        bg-red-50
                        border
                        border-red-100
                        text-red-600
                        flex
                        gap-3
                        items-start
                    "
                >

                    <div
                        class="
                            w-8
                            h-8
                            rounded-xl
                            bg-red-100
                            flex
                            items-center
                            justify-center
                            shrink-0
                        "
                    >

                        <i
                            data-lucide="circle-alert"
                            class="w-4 h-4"
                        ></i>

                    </div>


                    <div>

                        <div class="font-bold text-sm">
                            Login failed
                        </div>

                        <div class="text-xs mt-1">
                            <?= htmlspecialchars($error) ?>
                        </div>

                    </div>

                </div>

            <?php endif; ?>


            <form
                method="post"
                class="space-y-5"
            >

                <div>

                    <label
                        class="
                            block
                            text-sm
                            font-bold
                            text-slate-700
                            mb-2
                        "
                    >

                        Email Address

                    </label>


                    <div class="relative">

                        <i
                            data-lucide="mail"
                            class="
                                absolute
                                left-4
                                top-1/2
                                -translate-y-1/2
                                w-5
                                text-slate-400
                            "
                        ></i>


                        <input
                            name="email"
                            type="email"
                            value="<?= htmlspecialchars(
                                $_POST['email'] ?? ''
                            ) ?>"
                            required
                            autocomplete="email"
                            class="
                                w-full
                                border
                                border-slate-200
                                rounded-2xl
                                pl-12
                                pr-4
                                py-3.5
                                outline-none
                                transition
                                focus:border-blue-500
                                focus:ring-4
                                focus:ring-blue-100
                            "
                            placeholder="admin@gmail.com"
                        >

                    </div>

                </div>


                <div>

                    <div class="flex items-center justify-between mb-2">

                        <label
                            class="
                                block
                                text-sm
                                font-bold
                                text-slate-700
                            "
                        >

                            Password

                        </label>

                    </div>


                    <div class="relative">

                        <i
                            data-lucide="lock-keyhole"
                            class="
                                absolute
                                left-4
                                top-1/2
                                -translate-y-1/2
                                w-5
                                text-slate-400
                            "
                        ></i>


                        <input
                            id="password"
                            name="password"
                            type="password"
                            required
                            autocomplete="current-password"
                            class="
                                w-full
                                border
                                border-slate-200
                                rounded-2xl
                                pl-12
                                pr-12
                                py-3.5
                                outline-none
                                transition
                                focus:border-blue-500
                                focus:ring-4
                                focus:ring-blue-100
                            "
                            placeholder="Enter your password"
                        >


                        <button
                            type="button"
                            onclick="togglePassword()"
                            class="
                                absolute
                                right-4
                                top-1/2
                                -translate-y-1/2
                                text-slate-400
                                hover:text-slate-700
                            "
                        >

                            <i
                                id="eyeIcon"
                                data-lucide="eye"
                                class="w-5"
                            ></i>

                        </button>

                    </div>

                </div>


                <button
                    type="submit"
                    class="
                        w-full
                        bg-gradient-to-r
                        from-blue-600
                        to-indigo-600
                        hover:from-blue-700
                        hover:to-indigo-700
                        text-white
                        font-bold
                        py-3.5
                        rounded-2xl
                        shadow-lg
                        shadow-blue-600/20
                        transition
                        duration-200
                        hover:-translate-y-0.5
                    "
                >

                    <span class="flex items-center justify-center gap-2">

                        Sign In

                        <i
                            data-lucide="arrow-right"
                            class="w-4 h-4"
                        ></i>

                    </span>

                </button>

            </form>


            <div
                class="
                    mt-6
                    p-4
                    rounded-2xl
                    bg-slate-50
                    border
                    border-slate-100
                "
            >

                <div class="flex items-center gap-3">

                    <div
                        class="
                            w-9
                            h-9
                            rounded-xl
                            bg-blue-50
                            text-blue-600
                            flex
                            items-center
                            justify-center
                        "
                    >

                        <i
                            data-lucide="shield-check"
                            class="w-4"
                        ></i>

                    </div>


                    <div>

                        <div
                            class="
                                text-xs
                                font-bold
                                text-slate-700
                            "
                        >

                            Secure Login

                        </div>

                        <div
                            class="
                                text-[11px]
                                text-slate-400
                                mt-0.5
                            "
                        >

                            Your account information is protected.

                        </div>

                    </div>

                </div>

            </div>


            <div
                class="
                    text-center
                    text-xs
                    text-slate-400
                    mt-8
                "
            >

                © <?= date('Y') ?> Inventory Pro

            </div>

        </div>

    </div>

</div>


<script>

function togglePassword() {

    const password = document.getElementById("password");
    const icon = document.getElementById("eyeIcon");

    if (password.type === "password") {

        password.type = "text";

        icon.setAttribute("data-lucide", "eye-off");

    } else {

        password.type = "password";

        icon.setAttribute("data-lucide", "eye");

    }

    lucide.createIcons();

}

lucide.createIcons();

</script>

</body>

</html>