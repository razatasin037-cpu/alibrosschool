<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Sales";

$total_sales = $conn->query("
    SELECT COALESCE(SUM(total_amount),0) AS total
    FROM sales
")->fetch_assoc()['total'];

$total_paid = $conn->query("
    SELECT COALESCE(SUM(amount),0) AS total
    FROM sale_payments
")->fetch_assoc()['total'];

$total_due = max(0, $total_sales - $total_paid);

$rows = $conn->query("
    SELECT
        s.id,
        s.customer_name,
        s.date,
        s.total_amount,

        GROUP_CONCAT(
            CONCAT(
                p.product_name,
                ' × ',
                si.quantity,
                ' = ₹',
                FORMAT(si.total, 2)
            )
            ORDER BY si.id
            SEPARATOR '||'
        ) AS products,

        COALESCE(
            (
                SELECT SUM(sp.amount)
                FROM sale_payments sp
                WHERE sp.sale_id = s.id
            ),
            0
        ) AS paid

    FROM sales s

    LEFT JOIN sale_items si
        ON si.sale_id = s.id

    LEFT JOIN products p
        ON p.id = si.product_id

    GROUP BY
        s.id,
        s.customer_name,
        s.date,
        s.total_amount

    ORDER BY s.id DESC
");

require "../includes/header.php";
require "../includes/sidebar.php";

?>

<div class="w-full">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">

        <div>

            <h2 class="text-2xl font-bold text-slate-800">
                Sales
            </h2>

            <p class="text-sm text-slate-500 mt-1">
                Manage all sales and customer payments
            </p>

        </div>

        <a
            href="add.php"
            class="btn bg-blue-600 hover:bg-blue-700 text-white"
        >
            <i data-lucide="plus" class="w-4 h-4"></i>
            New Sale
        </a>

    </div>


    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">

        <div class="card p-6">

            <div class="text-sm text-slate-500">
                Total Sales
            </div>

            <div class="text-2xl font-black mt-2 text-blue-600">
                ₹<?= number_format($total_sales, 2) ?>
            </div>

        </div>


        <div class="card p-6">

            <div class="text-sm text-slate-500">
                Total Paid
            </div>

            <div class="text-2xl font-black mt-2 text-emerald-600">
                ₹<?= number_format($total_paid, 2) ?>
            </div>

        </div>


        <div class="card p-6">

            <div class="text-sm text-slate-500">
                Total Due
            </div>

            <div class="text-2xl font-black mt-2 text-red-600">
                ₹<?= number_format($total_due, 2) ?>
            </div>

        </div>

    </div>


    <div class="card overflow-x-auto">

        <table class="w-full text-sm">

            <thead class="bg-slate-50">

                <tr>

                    <th class="p-4 text-left">
                        Bill
                    </th>

                    <th class="p-4 text-left">
                        Customer
                    </th>

                    <th class="p-4 text-left">
                        Products Sold
                    </th>

                    <th class="p-4 text-left">
                        Date
                    </th>

                    <th class="p-4 text-right">
                        Total
                    </th>

                    <th class="p-4 text-right">
                        Paid
                    </th>

                    <th class="p-4 text-right">
                        Due
                    </th>

                    <th class="p-4 text-center">
                        Status
                    </th>

                    <th class="p-4 text-center">
                        Action
                    </th>

                </tr>

            </thead>

            <tbody>

            <?php if ($rows->num_rows == 0): ?>

                <tr>

                    <td
                        colspan="9"
                        class="p-10 text-center text-slate-400"
                    >
                        No sales found.
                    </td>

                </tr>

            <?php endif; ?>


            <?php while ($r = $rows->fetch_assoc()): ?>

                <?php

                $total = (float)$r['total_amount'];

                $paid = (float)$r['paid'];

                $due = max(0, $total - $paid);

                ?>

                <tr class="border-t hover:bg-slate-50">


                    <td class="p-4 font-bold">
                        #<?= $r['id'] ?>
                    </td>


                    <td class="p-4">

                        <?= htmlspecialchars(
                            $r['customer_name']
                            ?: 'Walk-in Customer'
                        ) ?>

                    </td>


                    <td class="p-4">

                        <?php if (!empty($r['products'])): ?>

                            <div class="space-y-2">

                                <?php

                                $productList =
                                    explode(
                                        '||',
                                        $r['products']
                                    );

                                ?>

                                <?php foreach ($productList as $product): ?>

                                    <div class="flex items-center gap-2">

                                        <div class="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">

                                            <i
                                                data-lucide="package"
                                                class="w-4 h-4"
                                            ></i>

                                        </div>

                                        <span class="font-semibold text-slate-700">

                                            <?= htmlspecialchars($product) ?>

                                        </span>

                                    </div>

                                <?php endforeach; ?>

                            </div>

                        <?php else: ?>

                            <span class="text-red-500">
                                No product found
                            </span>

                        <?php endif; ?>

                    </td>


                    <td class="p-4 text-slate-500">

                        <?= date(
                            'd M Y',
                            strtotime($r['date'])
                        ) ?>

                    </td>


                    <td class="p-4 text-right font-bold">

                        ₹<?= number_format(
                            $total,
                            2
                        ) ?>

                    </td>


                    <td class="p-4 text-right text-emerald-600 font-bold">

                        ₹<?= number_format(
                            $paid,
                            2
                        ) ?>

                    </td>


                    <td class="p-4 text-right text-red-600 font-bold">

                        ₹<?= number_format(
                            $due,
                            2
                        ) ?>

                    </td>


                    <td class="p-4 text-center">

                        <?php if ($due > 0): ?>

                            <span class="badge bg-red-50 text-red-600">
                                Due
                            </span>

                        <?php else: ?>

                            <span class="badge bg-emerald-50 text-emerald-600">
                                Paid
                            </span>

                        <?php endif; ?>

                    </td>


                    <td class="p-4">

                        <div class="flex items-center justify-center gap-2">

                            <a
                                href="bill.php?id=<?= $r['id'] ?>"
                                class="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center"
                                title="View Bill"
                            >

                                <i
                                    data-lucide="eye"
                                    class="w-4 h-4"
                                ></i>

                            </a>


                            <?php if ($due > 0): ?>

                                <a
                                    href="pay.php?id=<?= $r['id'] ?>"
                                    class="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center"
                                    title="Pay Due"
                                >

                                    <i
                                        data-lucide="indian-rupee"
                                        class="w-4 h-4"
                                    ></i>

                                </a>

                            <?php endif; ?>


                            <a
                                href="bill.php?id=<?= $r['id'] ?>&print=1"
                                class="w-9 h-9 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center"
                                title="Print"
                            >

                                <i
                                    data-lucide="printer"
                                    class="w-4 h-4"
                                ></i>

                            </a>

                        </div>

                    </td>

                </tr>

            <?php endwhile; ?>

            </tbody>

        </table>

    </div>

</div>

<?php require "../includes/footer.php"; ?>