<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "New Sale";

$error = "";

$products = $conn->query("
    SELECT id, product_name, stock, purchase_price, price
    FROM products
    ORDER BY product_name
");

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $product_id = (int)($_POST["product_id"] ?? 0);
    $customer_name = trim($_POST["customer_name"] ?? "");
    $quantity = (int)($_POST["quantity"] ?? 0);
    $date = $_POST["date"] ?? date("Y-m-d");
    $remarks = trim($_POST["remarks"] ?? "");

    $paid_amount = (float)($_POST["paid_amount"] ?? 0);
    $payment_method = trim($_POST["payment_method"] ?? "Cash");
    $payment_remarks = trim($_POST["payment_remarks"] ?? "");

    if ($customer_name === "") {

        $error = "Please enter customer name.";

    } elseif ($product_id <= 0) {

        $error = "Please select a product.";

    } elseif ($quantity < 1) {

        $error = "Quantity must be at least 1.";

    } elseif ($paid_amount < 0) {

        $error = "Paid amount cannot be negative.";

    } else {

        $conn->begin_transaction();

        try {

            $check = $conn->prepare("
                SELECT stock, price
                FROM products
                WHERE id = ?
                FOR UPDATE
            ");

            $check->bind_param("i", $product_id);
            $check->execute();

            $product = $check->get_result()->fetch_assoc();

            if (!$product) {
                throw new Exception("Product not found.");
            }

            if ($product["stock"] <= 0) {
                throw new Exception("Out of stock. This product cannot be sold.");
            }

            if ($quantity > $product["stock"]) {
                throw new Exception(
                    "Only " . $product["stock"] . " items are available."
                );
            }

            $total = $quantity * (float)$product["price"];

            if ($paid_amount > $total) {
                throw new Exception(
                    "Paid amount cannot be greater than total bill."
                );
            }

            $due = $total - $paid_amount;

            $final_remarks = "Customer: " . $customer_name;

            if ($remarks !== "") {
                $final_remarks .= " | " . $remarks;
            }

            $insert = $conn->prepare("
                INSERT INTO stock_out
                (product_id, quantity, date, remarks)
                VALUES (?, ?, ?, ?)
            ");

            $insert->bind_param(
                "iiss",
                $product_id,
                $quantity,
                $date,
                $final_remarks
            );

            if (!$insert->execute()) {
                throw new Exception("Sale could not be saved.");
            }

            $stock_out_id = $conn->insert_id;

            $update = $conn->prepare("
                UPDATE products
                SET stock = stock - ?
                WHERE id = ?
            ");

            $update->bind_param(
                "ii",
                $quantity,
                $product_id
            );

            if (!$update->execute()) {
                throw new Exception("Stock could not be updated.");
            }

            if ($paid_amount > 0) {

                $payment = $conn->prepare("
                    INSERT INTO payments
                    (
                        stock_out_id,
                        amount,
                        payment_method,
                        payment_date,
                        remarks
                    )
                    VALUES (?, ?, ?, ?, ?)
                ");

                $payment->bind_param(
                    "idsss",
                    $stock_out_id,
                    $paid_amount,
                    $payment_method,
                    $date,
                    $payment_remarks
                );

                if (!$payment->execute()) {
                    throw new Exception("Payment could not be saved.");
                }
            }

            $conn->commit();

            header("Location: view.php");
            exit;

        } catch (Throwable $e) {

            $conn->rollback();

            $error = $e->getMessage();
        }
    }
}

require "../includes/header.php";
require "../includes/sidebar.php";
?>

<div class="w-full">

    <div class="relative overflow-hidden rounded-[28px] bg-gradient-to-br from-slate-950 via-blue-950 to-indigo-950 text-white p-6 md:p-8 mb-6 shadow-xl">

        <div class="absolute -right-20 -top-20 w-72 h-72 rounded-full bg-blue-500/20 blur-3xl"></div>

        <div class="absolute right-32 bottom-[-100px] w-64 h-64 rounded-full bg-indigo-500/20 blur-3xl"></div>

        <div class="relative flex flex-col md:flex-row md:items-center justify-between gap-5">

            <div>

                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/10 text-blue-200 text-xs font-bold mb-4">

                    <span class="w-2 h-2 rounded-full bg-emerald-400"></span>

                    SALES MANAGEMENT

                </div>

                <h1 class="text-2xl md:text-4xl font-black">
                    Create New Sale
                </h1>

                <p class="text-slate-300 mt-2">
                    Add customer, product and payment details.
                </p>

            </div>

            <div class="hidden sm:flex w-16 h-16 rounded-3xl bg-white/10 border border-white/10 items-center justify-center">

                <i data-lucide="shopping-cart" class="w-8 h-8 text-blue-300"></i>

            </div>

        </div>

    </div>


    <?php if ($error): ?>

        <div class="mb-6 p-4 rounded-2xl bg-red-50 border border-red-100 text-red-600">

            <div class="flex items-center gap-3">

                <i data-lucide="circle-alert" class="w-5 h-5"></i>

                <span>
                    <?= htmlspecialchars($error) ?>
                </span>

            </div>

        </div>

    <?php endif; ?>


    <form method="post">

        <div class="grid lg:grid-cols-3 gap-6">

            <div class="lg:col-span-2">

                <div class="card p-6 md:p-8">

                    <div class="flex items-center gap-3 mb-7">

                        <div class="w-11 h-11 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">

                            <i data-lucide="receipt" class="w-5 h-5"></i>

                        </div>

                        <div>

                            <h2 class="text-lg font-extrabold">
                                Sale Information
                            </h2>

                            <p class="text-xs text-slate-400 mt-1">
                                Enter sale and payment details
                            </p>

                        </div>

                    </div>


                    <div class="grid md:grid-cols-2 gap-5">


                        <div class="md:col-span-2">

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Customer Name
                            </label>

                            <div class="relative">

                                <i data-lucide="user" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400"></i>

                                <input
                                    type="text"
                                    name="customer_name"
                                    id="customer_name"
                                    required
                                    value="<?= htmlspecialchars($_POST["customer_name"] ?? "") ?>"
                                    placeholder="Enter customer name"
                                    class="input pl-12"
                                >

                            </div>

                        </div>


                        <div class="md:col-span-2">

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Select Product
                            </label>

                            <div class="relative">

                                <i data-lucide="package" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 z-10"></i>

                                <select
                                    name="product_id"
                                    id="product_id"
                                    required
                                    class="input pl-12 appearance-none"
                                >

                                    <option value="">
                                        Select product
                                    </option>

                                    <?php while ($p = $products->fetch_assoc()): ?>

                                        <option
                                            value="<?= $p["id"] ?>"
                                            data-stock="<?= $p["stock"] ?>"
                                            data-price="<?= $p["price"] ?>"
                                            <?= (($_POST["product_id"] ?? "") == $p["id"]) ? "selected" : "" ?>
                                        >

                                            <?= htmlspecialchars($p["product_name"]) ?>
                                            — Stock: <?= $p["stock"] ?>

                                        </option>

                                    <?php endwhile; ?>

                                </select>

                            </div>

                            <div id="stockMessage" class="text-xs mt-2 text-slate-400">
                                Select a product to see available stock.
                            </div>

                        </div>


                        <div>

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Quantity
                            </label>

                            <div class="relative">

                                <i data-lucide="boxes" class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400"></i>

                                <input
                                    type="number"
                                    name="quantity"
                                    id="quantity"
                                    min="1"
                                    required
                                    value="<?= htmlspecialchars($_POST["quantity"] ?? "") ?>"
                                    placeholder="Enter quantity"
                                    class="input pl-12"
                                >

                            </div>

                        </div>


                        <div>

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Sale Date
                            </label>

                            <input
                                type="date"
                                name="date"
                                value="<?= htmlspecialchars($_POST["date"] ?? date("Y-m-d")) ?>"
                                class="input"
                            >

                        </div>


                        <div class="md:col-span-2">

                            <div class="border-t border-slate-100 pt-6">

                                <div class="flex items-center gap-2 mb-5">

                                    <div class="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">

                                        <i data-lucide="indian-rupee" class="w-5 h-5"></i>

                                    </div>

                                    <div>

                                        <h3 class="font-extrabold">
                                            Payment
                                        </h3>

                                        <p class="text-xs text-slate-400">
                                            Enter amount received from customer
                                        </p>

                                    </div>

                                </div>


                                <div class="grid md:grid-cols-2 gap-5">


                                    <div>

                                        <label class="block text-sm font-bold text-slate-700 mb-2">
                                            Paid Amount
                                        </label>

                                        <div class="relative">

                                            <span class="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-500">
                                                ₹
                                            </span>

                                            <input
                                                type="number"
                                                name="paid_amount"
                                                id="paid_amount"
                                                min="0"
                                                step="0.01"
                                                value="<?= htmlspecialchars($_POST["paid_amount"] ?? "0") ?>"
                                                class="input pl-9"
                                            >

                                        </div>

                                    </div>


                                    <div>

                                        <label class="block text-sm font-bold text-slate-700 mb-2">
                                            Payment Method
                                        </label>

                                        <select
                                            name="payment_method"
                                            class="input"
                                        >

                                            <option value="Cash">
                                                Cash
                                            </option>

                                            <option value="UPI">
                                                UPI
                                            </option>

                                            <option value="Card">
                                                Card
                                            </option>

                                            <option value="Bank Transfer">
                                                Bank Transfer
                                            </option>

                                        </select>

                                    </div>


                                    <div class="md:col-span-2">

                                        <label class="block text-sm font-bold text-slate-700 mb-2">
                                            Payment Remarks
                                        </label>

                                        <textarea
                                            name="payment_remarks"
                                            rows="2"
                                            placeholder="Payment note..."
                                            class="input resize-none"
                                        ><?= htmlspecialchars($_POST["payment_remarks"] ?? "") ?></textarea>

                                    </div>

                                </div>

                            </div>

                        </div>


                        <div class="md:col-span-2">

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Sale Remarks
                            </label>

                            <textarea
                                name="remarks"
                                rows="3"
                                placeholder="Other sale details..."
                                class="input resize-none"
                            ><?= htmlspecialchars($_POST["remarks"] ?? "") ?></textarea>

                        </div>

                    </div>


                    <div class="mt-8 pt-6 border-t border-slate-100 flex flex-col sm:flex-row justify-end gap-3">

                        <a
                            href="view.php"
                            class="px-6 py-3 rounded-xl bg-slate-100 text-slate-700 font-bold text-center"
                        >
                            Cancel
                        </a>

                        <button
                            type="submit"
                            id="saleButton"
                            class="btn bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/20 px-7"
                        >

                            <i data-lucide="check" class="w-4 h-4"></i>

                            Complete Sale

                        </button>

                    </div>

                </div>

            </div>


            <div>

                <div class="card p-6 sticky top-24">

                    <div class="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">

                        <i data-lucide="calculator" class="w-7 h-7"></i>

                    </div>

                    <h3 class="text-xl font-black mt-5">
                        Sale Summary
                    </h3>


                    <div class="mt-6 space-y-4">


                        <div class="flex justify-between gap-4 text-sm">

                            <span class="text-slate-500">
                                Customer
                            </span>

                            <span id="summaryCustomer" class="font-bold text-right">
                                —
                            </span>

                        </div>


                        <div class="flex justify-between gap-4 text-sm">

                            <span class="text-slate-500">
                                Product
                            </span>

                            <span id="summaryProduct" class="font-bold text-right">
                                —
                            </span>

                        </div>


                        <div class="flex justify-between text-sm">

                            <span class="text-slate-500">
                                Available Stock
                            </span>

                            <span id="summaryStock" class="font-bold text-blue-600">
                                0
                            </span>

                        </div>


                        <div class="flex justify-between text-sm">

                            <span class="text-slate-500">
                                Quantity
                            </span>

                            <span id="summaryQuantity" class="font-bold">
                                0
                            </span>

                        </div>


                        <div class="flex justify-between text-sm">

                            <span class="text-slate-500">
                                Sale Price
                            </span>

                            <span id="summaryPrice" class="font-bold">
                                ₹0.00
                            </span>

                        </div>


                        <div class="border-t border-slate-100 pt-4">

                            <div class="flex justify-between">

                                <span class="font-bold">
                                    Total Bill
                                </span>

                                <span id="summaryTotal" class="text-xl font-black text-blue-600">
                                    ₹0.00
                                </span>

                            </div>

                        </div>


                        <div class="flex justify-between">

                            <span class="font-bold text-emerald-600">
                                Paid
                            </span>

                            <span id="summaryPaid" class="font-black text-emerald-600">
                                ₹0.00
                            </span>

                        </div>


                        <div class="flex justify-between p-4 rounded-2xl bg-red-50">

                            <span class="font-bold text-red-600">
                                Due
                            </span>

                            <span id="summaryDue" class="text-xl font-black text-red-600">
                                ₹0.00
                            </span>

                        </div>

                    </div>


                    <div
                        id="summaryStatus"
                        class="mt-6 p-4 rounded-2xl bg-slate-50 text-xs text-slate-500"
                    >
                        Select a product to continue.
                    </div>

                </div>

            </div>

        </div>

    </form>

</div>


<script>

const customerInput = document.getElementById("customer_name");
const productSelect = document.getElementById("product_id");
const quantityInput = document.getElementById("quantity");
const paidInput = document.getElementById("paid_amount");

const stockMessage = document.getElementById("stockMessage");

const summaryCustomer = document.getElementById("summaryCustomer");
const summaryProduct = document.getElementById("summaryProduct");
const summaryStock = document.getElementById("summaryStock");
const summaryQuantity = document.getElementById("summaryQuantity");
const summaryPrice = document.getElementById("summaryPrice");
const summaryTotal = document.getElementById("summaryTotal");
const summaryPaid = document.getElementById("summaryPaid");
const summaryDue = document.getElementById("summaryDue");
const summaryStatus = document.getElementById("summaryStatus");
const saleButton = document.getElementById("saleButton");


function updateSummary() {

    const option = productSelect.options[productSelect.selectedIndex];

    summaryCustomer.textContent =
        customerInput.value.trim() || "—";


    if (!option || !option.value) {

        summaryProduct.textContent = "—";
        summaryStock.textContent = "0";
        summaryQuantity.textContent = "0";
        summaryPrice.textContent = "₹0.00";
        summaryTotal.textContent = "₹0.00";
        summaryPaid.textContent = "₹0.00";
        summaryDue.textContent = "₹0.00";

        saleButton.disabled = false;

        return;
    }


    const stock = parseInt(option.dataset.stock || 0);
    const price = parseFloat(option.dataset.price || 0);
    const quantity = parseInt(quantityInput.value || 0);
    const paid = parseFloat(paidInput.value || 0);

    const total = quantity * price;
    const due = Math.max(0, total - paid);


    summaryProduct.textContent =
        option.textContent.split("—")[0].trim();

    summaryStock.textContent = stock;
    summaryQuantity.textContent = quantity;

    summaryPrice.textContent =
        "₹" + price.toFixed(2);

    summaryTotal.textContent =
        "₹" + total.toFixed(2);

    summaryPaid.textContent =
        "₹" + paid.toFixed(2);

    summaryDue.textContent =
        "₹" + due.toFixed(2);


    if (stock <= 0) {

        stockMessage.textContent =
            "Out of stock. This product cannot be sold.";

        stockMessage.className =
            "text-xs mt-2 text-red-600 font-bold";

        summaryStatus.textContent =
            "Product is out of stock.";

        summaryStatus.className =
            "mt-6 p-4 rounded-2xl bg-red-50 text-red-600 text-xs font-bold";

        saleButton.disabled = true;

        return;
    }


    if (quantity > stock) {

        stockMessage.textContent =
            "Only " + stock + " items are available.";

        stockMessage.className =
            "text-xs mt-2 text-red-600 font-bold";

        summaryStatus.textContent =
            "Quantity is greater than available stock.";

        summaryStatus.className =
            "mt-6 p-4 rounded-2xl bg-red-50 text-red-600 text-xs font-bold";

        saleButton.disabled = true;

        return;
    }


    if (paid > total) {

        summaryStatus.textContent =
            "Paid amount cannot be greater than total bill.";

        summaryStatus.className =
            "mt-6 p-4 rounded-2xl bg-red-50 text-red-600 text-xs font-bold";

        saleButton.disabled = true;

        return;
    }


    stockMessage.textContent =
        stock + " items available.";

    stockMessage.className =
        "text-xs mt-2 text-blue-600 font-semibold";


    if (due === 0 && total > 0) {

        summaryStatus.textContent =
            "Bill fully paid.";

        summaryStatus.className =
            "mt-6 p-4 rounded-2xl bg-emerald-50 text-emerald-600 text-xs font-bold";

    } else if (paid > 0) {

        summaryStatus.textContent =
            "Partial payment. Due amount remains.";

        summaryStatus.className =
            "mt-6 p-4 rounded-2xl bg-blue-50 text-blue-600 text-xs font-bold";

    } else {

        summaryStatus.textContent =
            "Sale ready. Full amount is due.";

        summaryStatus.className =
            "mt-6 p-4 rounded-2xl bg-slate-50 text-slate-500 text-xs font-bold";
    }


    saleButton.disabled = false;
}


customerInput.addEventListener(
    "input",
    updateSummary
);

productSelect.addEventListener(
    "change",
    updateSummary
);

quantityInput.addEventListener(
    "input",
    updateSummary
);

paidInput.addEventListener(
    "input",
    updateSummary
);


document.addEventListener(
    "DOMContentLoaded",
    function () {

        if (window.lucide) {
            lucide.createIcons();
        }

        updateSummary();

    }
);

</script>


<?php require "../includes/footer.php"; ?>