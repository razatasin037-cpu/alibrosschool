<?php

require "../includes/auth.php";
require "../includes/connection.php";

$id = (int)($_GET['id'] ?? 0);

$s = $conn->prepare("
    SELECT *
    FROM sales
    WHERE id = ?
");

$s->bind_param("i", $id);
$s->execute();

$sale = $s->get_result()->fetch_assoc();

if (!$sale) {
    header("Location: view.php");
    exit;
}

$s = $conn->prepare("
    SELECT
        si.*,
        p.product_name
    FROM sale_items si
    JOIN products p
        ON p.id = si.product_id
    WHERE si.sale_id = ?
    ORDER BY si.id ASC
");

$s->bind_param("i", $id);
$s->execute();

$items = $s->get_result();

$page_title = "Sale Details";

require "../includes/header.php";
require "../includes/sidebar.php";

?>

<div class="w-full max-w-6xl mx-auto">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">

        <div>

            <h2 class="text-2xl font-bold text-slate-800">
                Sale Details
            </h2>

            <p class="text-sm text-slate-500 mt-1">
                Bill #<?= $sale['id'] ?>
            </p>

        </div>

        <div class="flex gap-2">

            <button
                onclick="window.print()"
                class="btn bg-slate-900 text-white"
            >
                <i data-lucide="printer" class="w-4 h-4"></i>
                Print
            </button>

            <a
                href="view.php"
                class="btn bg-slate-100 text-slate-700"
            >
                Back
            </a>

        </div>

    </div>


    <div id="bill" class="card overflow-hidden">

        <div class="p-6 md:p-8 border-b border-slate-100">

            <div class="flex flex-col md:flex-row md:items-start justify-between gap-5">

                <div>

                    <div class="flex items-center gap-3">

                        <div class="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center">

                            <i data-lucide="receipt" class="w-6 h-6"></i>

                        </div>

                        <div>

                            <h1 class="text-xl font-black">
                                Inventory<span class="text-blue-600">Pro</span>
                            </h1>

                            <p class="text-sm text-slate-500">
                                Sales Invoice
                            </p>

                        </div>

                    </div>

                </div>


                <div class="text-left md:text-right">

                    <div class="text-sm text-slate-400">
                        Bill Number
                    </div>

                    <div class="text-xl font-black">
                        #<?= $sale['id'] ?>
                    </div>

                    <div class="text-sm text-slate-500 mt-1">
                        <?= date(
                            'd M Y',
                            strtotime($sale['date'])
                        ) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="grid md:grid-cols-2 gap-5 p-6 md:p-8 bg-slate-50">

            <div>

                <div class="text-xs uppercase tracking-wider text-slate-400 font-bold">
                    Customer
                </div>

                <div class="text-lg font-bold mt-1">
                    <?= htmlspecialchars(
                        $sale['customer_name'] ?: 'Walk-in Customer'
                    ) ?>
                </div>

            </div>


            <div class="md:text-right">

                <div class="text-xs uppercase tracking-wider text-slate-400 font-bold">
                    Payment Status
                </div>

                <?php if ($sale['due_amount'] > 0): ?>

                    <span class="badge bg-red-50 text-red-600 mt-2">
                        Payment Due
                    </span>

                <?php else: ?>

                    <span class="badge bg-emerald-50 text-emerald-600 mt-2">
                        Fully Paid
                    </span>

                <?php endif; ?>

            </div>

        </div>


        <div class="overflow-x-auto">

            <table class="w-full text-sm">

                <thead class="bg-slate-50">

                    <tr>

                        <th class="p-4 text-left">
                            #
                        </th>

                        <th class="p-4 text-left">
                            Product
                        </th>

                        <th class="p-4 text-center">
                            Quantity
                        </th>

                        <th class="p-4 text-right">
                            Price
                        </th>

                        <th class="p-4 text-right">
                            Total
                        </th>

                    </tr>

                </thead>

                <tbody>

                    <?php

                    $count = 1;

                    while ($item = $items->fetch_assoc()):

                    ?>

                        <tr class="border-t">

                            <td class="p-4 text-slate-400">
                                <?= $count++ ?>
                            </td>

                            <td class="p-4 font-semibold text-slate-800">
                                <?= htmlspecialchars(
                                    $item['product_name']
                                ) ?>
                            </td>

                            <td class="p-4 text-center">

                                <span class="badge bg-blue-50 text-blue-600">
                                    <?= $item['quantity'] ?>
                                </span>

                            </td>

                            <td class="p-4 text-right">
                                ₹<?= number_format(
                                    $item['price'],
                                    2
                                ) ?>
                            </td>

                            <td class="p-4 text-right font-bold">
                                ₹<?= number_format(
                                    $item['total'],
                                    2
                                ) ?>
                            </td>

                        </tr>

                    <?php endwhile; ?>

                </tbody>

            </table>

        </div>


        <div class="p-6 md:p-8 border-t border-slate-100">

            <div class="flex justify-end">

                <div class="w-full md:w-96 space-y-4">

                    <div class="flex justify-between text-slate-500">

                        <span>
                            Grand Total
                        </span>

                        <span class="font-bold text-slate-900">
                            ₹<?= number_format(
                                $sale['total_amount'],
                                2
                            ) ?>
                        </span>

                    </div>


                    <div class="flex justify-between text-emerald-600">

                        <span>
                            Paid Amount
                        </span>

                        <span class="font-bold">
                            ₹<?= number_format(
                                $sale['paid_amount'],
                                2
                            ) ?>
                        </span>

                    </div>


                    <div class="flex justify-between p-4 rounded-2xl bg-red-50 text-red-600">

                        <span class="font-bold">
                            Due Amount
                        </span>

                        <span class="text-xl font-black">
                            ₹<?= number_format(
                                $sale['due_amount'],
                                2
                            ) ?>
                        </span>

                    </div>


                    <?php if ($sale['due_amount'] > 0): ?>

                        <a
                            href="pay.php?id=<?= $sale['id'] ?>"
                            class="btn bg-emerald-600 hover:bg-emerald-700 text-white w-full"
                        >

                            <i data-lucide="indian-rupee" class="w-4"></i>

                            Pay Due

                        </a>

                    <?php endif; ?>

                </div>

            </div>

        </div>


        <?php if (!empty($sale['remarks'])): ?>

            <div class="px-6 md:px-8 pb-8">

                <div class="p-4 rounded-2xl bg-slate-50">

                    <div class="text-xs font-bold text-slate-400 uppercase">
                        Remarks
                    </div>

                    <div class="text-sm text-slate-600 mt-1">
                        <?= htmlspecialchars($sale['remarks']) ?>
                    </div>

                </div>

            </div>

        <?php endif; ?>


        <div class="px-6 md:px-8 py-5 border-t border-slate-100 text-center text-xs text-slate-400">

            Thank you for your business.

        </div>

    </div>

</div>


<style>

@media print {

    body {
        background: white !important;
    }

    #sidebar,
    #backdrop,
    header,
    button,
    .btn {
        display: none !important;
    }

    main {
        padding: 0 !important;
        max-width: none !important;
    }

    #bill {
        display: block !important;
        width: 100% !important;
        border: none !important;
        box-shadow: none !important;
        border-radius: 0 !important;
    }

}

</style>


<?php require "../includes/footer.php"; ?>