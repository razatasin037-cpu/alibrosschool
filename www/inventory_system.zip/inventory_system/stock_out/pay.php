<?php

require "../includes/auth.php";
require "../includes/connection.php";

$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    header("Location:view.php");
    exit;
}

$s = $conn->prepare("
    SELECT
        id,
        customer_name,
        total_amount
    FROM sales
    WHERE id = ?
");

$s->bind_param("i", $id);
$s->execute();

$sale = $s->get_result()->fetch_assoc();

if (!$sale) {
    header("Location:view.php");
    exit;
}

$p = $conn->prepare("
    SELECT COALESCE(SUM(amount),0) AS paid
    FROM sale_payments
    WHERE sale_id = ?
");

$p->bind_param("i", $id);
$p->execute();

$paid = (float)$p->get_result()->fetch_assoc()['paid'];

$total = (float)$sale['total_amount'];

$due = max(0, $total - $paid);

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $amount = (float)($_POST['amount'] ?? 0);
    $payment_date = $_POST['payment_date'] ?? date('Y-m-d');
    $remarks = trim($_POST['remarks'] ?? '');

    if ($amount <= 0) {

        $error = "Enter a valid amount.";

    } elseif ($amount > $due) {

        $error = "Payment due amount se zyada nahi ho sakta.";

    } else {

        $conn->begin_transaction();

        try {

            $pay = $conn->prepare("
                INSERT INTO sale_payments
                (
                    sale_id,
                    amount,
                    payment_date,
                    remarks
                )
                VALUES (?, ?, ?, ?)
            ");

            $pay->bind_param(
                "idss",
                $id,
                $amount,
                $payment_date,
                $remarks
            );

            if (!$pay->execute()) {
                throw new Exception("Payment save nahi hua.");
            }

            $newPaid = $paid + $amount;

            $newDue = max(
                0,
                $total - $newPaid
            );

            $update = $conn->prepare("
                UPDATE sales
                SET
                    paid_amount = ?,
                    due_amount = ?
                WHERE id = ?
            ");

            $update->bind_param(
                "ddi",
                $newPaid,
                $newDue,
                $id
            );

            if (!$update->execute()) {
                throw new Exception("Sale update nahi hua.");
            }

            $conn->commit();

            header("Location:view.php");
            exit;

        } catch (Throwable $e) {

            $conn->rollback();

            $error = $e->getMessage();
        }
    }
}

$page_title = "Pay Due";

require "../includes/header.php";
require "../includes/sidebar.php";

?>

<div class="max-w-xl mx-auto">

    <div class="card p-6">

        <div class="flex items-center gap-3 mb-6">

            <div class="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">

                <i
                    data-lucide="indian-rupee"
                    class="w-6 h-6"
                ></i>

            </div>

            <div>

                <h2 class="text-2xl font-black">
                    Pay Due
                </h2>

                <p class="text-sm text-slate-500">
                    Bill #<?= $id ?>
                </p>

            </div>

        </div>


        <?php if ($error): ?>

            <div class="mb-5 p-4 rounded-xl bg-red-50 text-red-600">

                <?= htmlspecialchars($error) ?>

            </div>

        <?php endif; ?>


        <div class="space-y-4 mb-6">

            <div class="flex justify-between">

                <span class="text-slate-500">
                    Customer
                </span>

                <span class="font-bold">

                    <?= htmlspecialchars(
                        $sale['customer_name']
                        ?: 'Walk-in Customer'
                    ) ?>

                </span>

            </div>


            <div class="flex justify-between">

                <span class="text-slate-500">
                    Total
                </span>

                <span class="font-bold">
                    ₹<?= number_format($total, 2) ?>
                </span>

            </div>


            <div class="flex justify-between">

                <span class="text-emerald-600">
                    Already Paid
                </span>

                <span class="font-bold text-emerald-600">
                    ₹<?= number_format($paid, 2) ?>
                </span>

            </div>


            <div class="flex justify-between p-4 rounded-xl bg-red-50">

                <span class="font-bold text-red-600">
                    Due
                </span>

                <span class="text-xl font-black text-red-600">
                    ₹<?= number_format($due, 2) ?>
                </span>

            </div>

        </div>


        <?php if ($due > 0): ?>

            <form method="post">

                <div class="mb-5">

                    <label class="block text-sm font-bold mb-2">
                        Payment Amount
                    </label>

                    <input
                        type="number"
                        name="amount"
                        min="0.01"
                        max="<?= $due ?>"
                        step="0.01"
                        value="<?= $due ?>"
                        required
                        class="input"
                    >

                </div>


                <div class="mb-5">

                    <label class="block text-sm font-bold mb-2">
                        Payment Date
                    </label>

                    <input
                        type="date"
                        name="payment_date"
                        value="<?= date('Y-m-d') ?>"
                        required
                        class="input"
                    >

                </div>


                <div class="mb-5">

                    <label class="block text-sm font-bold mb-2">
                        Remarks
                    </label>

                    <textarea
                        name="remarks"
                        rows="3"
                        class="input resize-none"
                        placeholder="Payment remarks"
                    ></textarea>

                </div>


                <button
                    type="submit"
                    class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-bold"
                >
                    Save Payment
                </button>

            </form>

        <?php else: ?>

            <div class="p-4 rounded-xl bg-emerald-50 text-emerald-600 text-center font-bold">
                Fully Paid
            </div>

        <?php endif; ?>

    </div>

</div>

<?php require "../includes/footer.php"; ?>