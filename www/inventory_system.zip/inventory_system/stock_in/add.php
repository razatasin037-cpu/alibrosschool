<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Stock In";

$error = "";

$products = $conn->query("
    SELECT id, product_name, stock, purchase_price, price
    FROM products
    ORDER BY product_name
");

$suppliers = $conn->query("
    SELECT id, supplier_name
    FROM supplier
    ORDER BY supplier_name
");

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $product_id = (int)($_POST["product_id"] ?? 0);
    $supplier_id = (int)($_POST["supplier_id"] ?? 0);
    $quantity = (int)($_POST["quantity"] ?? 0);
    $purchase_price = (float)($_POST["purchase_price"] ?? 0);
    $selling_price = (float)($_POST["selling_price"] ?? 0);
    $date = $_POST["date"] ?? date("Y-m-d");
    $remarks = trim($_POST["remarks"] ?? "");

    if ($supplier_id <= 0) {

        $error = "Please select a supplier.";

    } elseif ($product_id <= 0) {

        $error = "Please select a product.";

    } elseif ($quantity < 1) {

        $error = "Quantity must be at least 1.";

    } elseif ($purchase_price < 0) {

        $error = "Purchase price cannot be negative.";

    } elseif ($selling_price < 0) {

        $error = "Selling price cannot be negative.";

    } else {

        $conn->begin_transaction();

        try {

            $check = $conn->prepare("
                SELECT id
                FROM products
                WHERE id = ?
                FOR UPDATE
            ");

            $check->bind_param(
                "i",
                $product_id
            );

            $check->execute();

            $product = $check->get_result()->fetch_assoc();

            if (!$product) {

                throw new Exception(
                    "Product not found."
                );
            }

            $insert = $conn->prepare("
                INSERT INTO stock_in
                (
                    product_id,
                    supplier_id,
                    quantity,
                    purchase_price,
                    date,
                    remarks
                )
                VALUES (?, ?, ?, ?, ?, ?)
            ");

            $insert->bind_param(
                "iiidss",
                $product_id,
                $supplier_id,
                $quantity,
                $purchase_price,
                $date,
                $remarks
            );

            if (!$insert->execute()) {

                throw new Exception(
                    "Stock could not be saved."
                );
            }

            $update = $conn->prepare("
                UPDATE products
                SET
                    stock = stock + ?,
                    purchase_price = ?,
                    price = ?
                WHERE id = ?
            ");

            $update->bind_param(
                "iddi",
                $quantity,
                $purchase_price,
                $selling_price,
                $product_id
            );

            if (!$update->execute()) {

                throw new Exception(
                    "Product stock could not be updated."
                );
            }

            $conn->commit();

            header("Location: view.php");
            exit;

        } catch (Throwable $e) {

            $conn->rollback();

            $error = $e->getMessage();
        }
    }
}

require "../includes/header.php";
require "../includes/sidebar.php";

?>

<div class="w-full">

    <div class="relative overflow-hidden rounded-[28px] bg-gradient-to-br from-slate-950 via-blue-950 to-indigo-950 text-white p-6 md:p-8 mb-6 shadow-xl">

        <div class="absolute -right-20 -top-20 w-72 h-72 rounded-full bg-blue-500/20 blur-3xl"></div>

        <div class="absolute right-32 bottom-[-100px] w-64 h-64 rounded-full bg-indigo-500/20 blur-3xl"></div>

        <div class="relative flex flex-col md:flex-row md:items-center justify-between gap-5">

            <div>

                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/10 text-blue-200 text-xs font-bold mb-4">

                    <span class="w-2 h-2 rounded-full bg-emerald-400"></span>

                    STOCK MANAGEMENT

                </div>

                <h1 class="text-2xl md:text-4xl font-black">
                    Add Stock
                </h1>

                <p class="text-slate-300 mt-2">
                    Add incoming stock from your supplier.
                </p>

            </div>

            <div class="hidden sm:flex w-16 h-16 rounded-3xl bg-white/10 border border-white/10 items-center justify-center">

                <i
                    data-lucide="arrow-down-to-line"
                    class="w-8 h-8 text-blue-300"
                ></i>

            </div>

        </div>

    </div>


    <?php if ($error): ?>

        <div class="mb-6 p-4 rounded-2xl bg-red-50 border border-red-100 text-red-600">

            <div class="flex items-center gap-3">

                <i
                    data-lucide="circle-alert"
                    class="w-5 h-5"
                ></i>

                <span>
                    <?= htmlspecialchars($error) ?>
                </span>

            </div>

        </div>

    <?php endif; ?>


    <form method="post">

        <div class="grid lg:grid-cols-3 gap-6">

            <div class="lg:col-span-2">

                <div class="card p-6 md:p-8">

                    <div class="flex items-center gap-3 mb-7">

                        <div class="w-11 h-11 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">

                            <i
                                data-lucide="package-plus"
                                class="w-5 h-5"
                            ></i>

                        </div>

                        <div>

                            <h2 class="text-lg font-extrabold">
                                Stock Information
                            </h2>

                            <p class="text-xs text-slate-400 mt-1">
                                Enter supplier and product details
                            </p>

                        </div>

                    </div>


                    <div class="grid md:grid-cols-2 gap-5">


                        <div>

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Select Supplier
                                <span class="text-red-500">*</span>
                            </label>

                            <div class="relative">

                                <i
                                    data-lucide="truck"
                                    class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 z-10"
                                ></i>

                                <select
                                    name="supplier_id"
                                    required
                                    class="input pl-12 appearance-none"
                                >

                                    <option value="">
                                        Select supplier
                                    </option>

                                    <?php while ($s = $suppliers->fetch_assoc()): ?>

                                        <option
                                            value="<?= $s["id"] ?>"
                                            <?= (($_POST["supplier_id"] ?? "") == $s["id"]) ? "selected" : "" ?>
                                        >

                                            <?= htmlspecialchars($s["supplier_name"]) ?>

                                        </option>

                                    <?php endwhile; ?>

                                </select>

                            </div>

                        </div>


                        <div>

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Select Product
                                <span class="text-red-500">*</span>
                            </label>

                            <div class="relative">

                                <i
                                    data-lucide="package"
                                    class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 z-10"
                                ></i>

                                <select
                                    name="product_id"
                                    id="product_id"
                                    required
                                    class="input pl-12 appearance-none"
                                >

                                    <option value="">
                                        Select product
                                    </option>

                                    <?php while ($p = $products->fetch_assoc()): ?>

                                        <option
                                            value="<?= $p["id"] ?>"
                                            data-stock="<?= $p["stock"] ?>"
                                            data-purchase="<?= $p["purchase_price"] ?>"
                                            data-price="<?= $p["price"] ?>"
                                            <?= (($_POST["product_id"] ?? "") == $p["id"]) ? "selected" : "" ?>
                                        >

                                            <?= htmlspecialchars($p["product_name"]) ?>

                                            — Stock:
                                            <?= $p["stock"] ?>

                                        </option>

                                    <?php endwhile; ?>

                                </select>

                            </div>

                            <div
                                id="stockMessage"
                                class="text-xs mt-2 text-slate-400"
                            >
                                Select a product to see current stock.
                            </div>

                        </div>


                        <div>

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Purchase Price
                                <span class="text-red-500">*</span>
                            </label>

                            <div class="relative">

                                <span class="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-500">
                                    ₹
                                </span>

                                <input
                                    type="number"
                                    name="purchase_price"
                                    id="purchase_price"
                                    step="0.01"
                                    min="0"
                                    required
                                    value="<?= htmlspecialchars($_POST["purchase_price"] ?? "") ?>"
                                    placeholder="Purchase price"
                                    class="input pl-9"
                                >

                            </div>

                        </div>


                        <div>

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Selling Price
                                <span class="text-red-500">*</span>
                            </label>

                            <div class="relative">

                                <span class="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-500">
                                    ₹
                                </span>

                                <input
                                    type="number"
                                    name="selling_price"
                                    id="selling_price"
                                    step="0.01"
                                    min="0"
                                    required
                                    value="<?= htmlspecialchars($_POST["selling_price"] ?? "") ?>"
                                    placeholder="Selling price"
                                    class="input pl-9"
                                >

                            </div>

                        </div>


                        <div>

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Quantity
                                <span class="text-red-500">*</span>
                            </label>

                            <div class="relative">

                                <i
                                    data-lucide="boxes"
                                    class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400"
                                ></i>

                                <input
                                    type="number"
                                    name="quantity"
                                    id="quantity"
                                    min="1"
                                    required
                                    value="<?= htmlspecialchars($_POST["quantity"] ?? "") ?>"
                                    placeholder="Enter quantity"
                                    class="input pl-12"
                                >

                            </div>

                        </div>


                        <div>

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Stock In Date
                            </label>

                            <input
                                type="date"
                                name="date"
                                value="<?= htmlspecialchars($_POST["date"] ?? date("Y-m-d")) ?>"
                                required
                                class="input"
                            >

                        </div>


                        <div>

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Total Purchase
                            </label>

                            <div
                                id="totalPurchase"
                                class="w-full border border-slate-200 rounded-[14px] px-4 py-[.78rem] bg-slate-50 font-black text-blue-600"
                            >
                                ₹0.00
                            </div>

                        </div>


                        <div>

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Expected Sale Value
                            </label>

                            <div
                                id="totalSale"
                                class="w-full border border-slate-200 rounded-[14px] px-4 py-[.78rem] bg-slate-50 font-black text-emerald-600"
                            >
                                ₹0.00
                            </div>

                        </div>


                        <div class="md:col-span-2">

                            <label class="block text-sm font-bold text-slate-700 mb-2">
                                Remarks
                            </label>

                            <textarea
                                name="remarks"
                                rows="4"
                                placeholder="Enter invoice number or other details..."
                                class="input resize-none"
                            ><?= htmlspecialchars($_POST["remarks"] ?? "") ?></textarea>

                        </div>

                    </div>


                    <div class="mt-8 pt-6 border-t border-slate-100 flex flex-col sm:flex-row justify-end gap-3">

                        <a
                            href="view.php"
                            class="px-6 py-3 rounded-xl bg-slate-100 text-slate-700 font-bold text-center hover:bg-slate-200"
                        >
                            Cancel
                        </a>

                        <button
                            type="submit"
                            class="btn bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/20 px-7"
                        >

                            <i
                                data-lucide="plus"
                                class="w-4 h-4"
                            ></i>

                            Add Stock

                        </button>

                    </div>

                </div>

            </div>


            <div>

                <div class="card p-6 sticky top-24">

                    <div class="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">

                        <i
                            data-lucide="calculator"
                            class="w-7 h-7"
                        ></i>

                    </div>

                    <h3 class="text-xl font-black mt-5">
                        Stock Summary
                    </h3>


                    <div class="mt-6 space-y-5">


                        <div>

                            <div class="text-xs text-slate-400">
                                Supplier
                            </div>

                            <div
                                id="summarySupplier"
                                class="font-bold mt-1"
                            >
                                —
                            </div>

                        </div>


                        <div>

                            <div class="text-xs text-slate-400">
                                Product
                            </div>

                            <div
                                id="summaryProduct"
                                class="font-bold mt-1"
                            >
                                —
                            </div>

                        </div>


                        <div class="flex justify-between">

                            <span class="text-slate-500">
                                Current Stock
                            </span>

                            <span
                                id="summaryStock"
                                class="font-bold text-blue-600"
                            >
                                0
                            </span>

                        </div>


                        <div class="flex justify-between">

                            <span class="text-slate-500">
                                Quantity In
                            </span>

                            <span
                                id="summaryQuantity"
                                class="font-bold"
                            >
                                0
                            </span>

                        </div>


                        <div class="flex justify-between">

                            <span class="text-slate-500">
                                Purchase Price
                            </span>

                            <span
                                id="summaryPurchase"
                                class="font-bold"
                            >
                                ₹0.00
                            </span>

                        </div>


                        <div class="flex justify-between">

                            <span class="text-slate-500">
                                Selling Price
                            </span>

                            <span
                                id="summarySelling"
                                class="font-bold text-emerald-600"
                            >
                                ₹0.00
                            </span>

                        </div>


                        <div class="border-t border-slate-100 pt-4">

                            <div class="flex justify-between">

                                <span class="font-bold">
                                    Total Purchase
                                </span>

                                <span
                                    id="summaryTotal"
                                    class="text-xl font-black text-blue-600"
                                >
                                    ₹0.00
                                </span>

                            </div>

                        </div>


                        <div class="flex justify-between">

                            <span class="font-bold text-slate-600">
                                Expected Sale Value
                            </span>

                            <span
                                id="summarySale"
                                class="font-bold text-emerald-600"
                            >
                                ₹0.00
                            </span>

                        </div>

                    </div>


                    <div
                        class="mt-6 p-4 rounded-2xl bg-blue-50 text-blue-600 text-xs font-semibold"
                    >

                        Selling price will be saved to the selected product.

                    </div>

                </div>

            </div>

        </div>

    </form>

</div>


<script>

const supplierSelect =
    document.querySelector(
        'select[name="supplier_id"]'
    );

const productSelect =
    document.getElementById(
        "product_id"
    );

const purchaseInput =
    document.getElementById(
        "purchase_price"
    );

const sellingInput =
    document.getElementById(
        "selling_price"
    );

const quantityInput =
    document.getElementById(
        "quantity"
    );

const stockMessage =
    document.getElementById(
        "stockMessage"
    );

const summarySupplier =
    document.getElementById(
        "summarySupplier"
    );

const summaryProduct =
    document.getElementById(
        "summaryProduct"
    );

const summaryStock =
    document.getElementById(
        "summaryStock"
    );

const summaryQuantity =
    document.getElementById(
        "summaryQuantity"
    );

const summaryPurchase =
    document.getElementById(
        "summaryPurchase"
    );

const summarySelling =
    document.getElementById(
        "summarySelling"
    );

const summaryTotal =
    document.getElementById(
        "summaryTotal"
    );

const summarySale =
    document.getElementById(
        "summarySale"
    );

const totalPurchase =
    document.getElementById(
        "totalPurchase"
    );

const totalSale =
    document.getElementById(
        "totalSale"
    );


function updateSummary() {

    const supplierOption =
        supplierSelect.options[
            supplierSelect.selectedIndex
        ];

    const productOption =
        productSelect.options[
            productSelect.selectedIndex
        ];

    const quantity =
        parseInt(
            quantityInput.value || 0
        );

    const purchasePrice =
        parseFloat(
            purchaseInput.value || 0
        );

    const sellingPrice =
        parseFloat(
            sellingInput.value || 0
        );

    const totalPurchaseAmount =
        quantity * purchasePrice;

    const totalSaleAmount =
        quantity * sellingPrice;


    if (
        supplierOption &&
        supplierOption.value
    ) {

        summarySupplier.textContent =
            supplierOption.textContent.trim();

    } else {

        summarySupplier.textContent =
            "—";
    }


    if (
        productOption &&
        productOption.value
    ) {

        summaryProduct.textContent =
            productOption.textContent
                .split("—")[0]
                .trim();

        summaryStock.textContent =
            productOption.dataset.stock || 0;

    } else {

        summaryProduct.textContent =
            "—";

        summaryStock.textContent =
            "0";
    }


    summaryQuantity.textContent =
        quantity;

    summaryPurchase.textContent =
        "₹" + purchasePrice.toFixed(2);

    summarySelling.textContent =
        "₹" + sellingPrice.toFixed(2);

    summaryTotal.textContent =
        "₹" + totalPurchaseAmount.toFixed(2);

    summarySale.textContent =
        "₹" + totalSaleAmount.toFixed(2);

    totalPurchase.textContent =
        "₹" + totalPurchaseAmount.toFixed(2);

    totalSale.textContent =
        "₹" + totalSaleAmount.toFixed(2);
}


productSelect.addEventListener(
    "change",
    function () {

        const option =
            productSelect.options[
                productSelect.selectedIndex
            ];

        if (
            option &&
            option.value
        ) {

            purchaseInput.value =
                option.dataset.purchase || "";

            sellingInput.value =
                option.dataset.price || "";

            stockMessage.textContent =
                "Current stock: " +
                option.dataset.stock;

            stockMessage.className =
                "text-xs mt-2 text-blue-600 font-semibold";

        } else {

            purchaseInput.value = "";
            sellingInput.value = "";

            stockMessage.textContent =
                "Select a product to see current stock.";

            stockMessage.className =
                "text-xs mt-2 text-slate-400";
        }

        updateSummary();
    }
);


supplierSelect.addEventListener(
    "change",
    updateSummary
);

purchaseInput.addEventListener(
    "input",
    updateSummary
);

sellingInput.addEventListener(
    "input",
    updateSummary
);

quantityInput.addEventListener(
    "input",
    updateSummary
);


document.addEventListener(
    "DOMContentLoaded",
    function () {

        if (window.lucide) {
            lucide.createIcons();
        }

        updateSummary();
    }
);

</script>


<?php require "../includes/footer.php"; ?>