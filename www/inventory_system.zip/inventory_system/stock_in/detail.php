<?php

require "../includes/auth.php";
require "../includes/connection.php";

$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    header("Location:view.php");
    exit;
}

$s = $conn->prepare("
    SELECT
        si.*,
        p.product_name,
        p.price,
        s.supplier_name,
        s.contact_person,
        s.mobile,
        s.email,
        s.address
    FROM stock_in si
    JOIN products p ON p.id = si.product_id
    LEFT JOIN supplier s ON s.id = si.supplier_id
    WHERE si.id = ?
");

$s->bind_param("i", $id);
$s->execute();

$entry = $s->get_result()->fetch_assoc();

if (!$entry) {
    header("Location:view.php");
    exit;
}

$supplier_id = (int)$entry['supplier_id'];

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['make_payment'])
) {

    $amount = (float)($_POST['payment_amount'] ?? 0);
    $payment_date = $_POST['payment_date'] ?? date('Y-m-d');
    $payment_remarks = trim($_POST['payment_remarks'] ?? '');

    $check = $conn->prepare("
        SELECT COALESCE(SUM(quantity * purchase_price),0) AS total
        FROM stock_in
        WHERE supplier_id = ?
    ");

    $check->bind_param("i", $supplier_id);
    $check->execute();

    $total_purchase_for_payment =
        (float)$check->get_result()->fetch_assoc()['total'];

    $check = $conn->prepare("
        SELECT COALESCE(SUM(amount),0) AS paid
        FROM supplier_payments
        WHERE supplier_id = ?
    ");

    $check->bind_param("i", $supplier_id);
    $check->execute();

    $total_paid_for_payment =
        (float)$check->get_result()->fetch_assoc()['paid'];

    $due_for_payment =
        max(
            0,
            $total_purchase_for_payment -
            $total_paid_for_payment
        );

    if ($amount <= 0) {

        $error = "Please enter a valid payment amount.";

    } elseif ($amount > $due_for_payment) {

        $error = "Payment cannot be greater than due amount.";

    } else {

        $pay = $conn->prepare("
            INSERT INTO supplier_payments
            (
                supplier_id,
                amount,
                date,
                remarks
            )
            VALUES (?, ?, ?, ?)
        ");

        $pay->bind_param(
            "idss",
            $supplier_id,
            $amount,
            $payment_date,
            $payment_remarks
        );

        if ($pay->execute()) {

            header("Location:detail.php?id=" . $id);
            exit;

        } else {

            $error = "Payment could not be saved.";
        }
    }
}


$allStock = $conn->prepare("
    SELECT
        si.*,
        p.product_name
    FROM stock_in si
    JOIN products p ON p.id = si.product_id
    WHERE si.supplier_id = ?
    ORDER BY si.id DESC
");

$allStock->bind_param("i", $supplier_id);
$allStock->execute();

$stockRows = $allStock->get_result();


$totalPurchase = $conn->prepare("
    SELECT
        COALESCE(SUM(quantity * purchase_price),0) AS total
    FROM stock_in
    WHERE supplier_id = ?
");

$totalPurchase->bind_param("i", $supplier_id);
$totalPurchase->execute();

$totalPurchaseAmount =
    (float)$totalPurchase->get_result()->fetch_assoc()['total'];


$totalPaid = $conn->prepare("
    SELECT
        COALESCE(SUM(amount),0) AS total
    FROM supplier_payments
    WHERE supplier_id = ?
");

$totalPaid->bind_param("i", $supplier_id);
$totalPaid->execute();

$totalPaidAmount =
    (float)$totalPaid->get_result()->fetch_assoc()['total'];


$totalDue =
    max(
        0,
        $totalPurchaseAmount -
        $totalPaidAmount
    );


$payments = $conn->prepare("
    SELECT *
    FROM supplier_payments
    WHERE supplier_id = ?
    ORDER BY id DESC
");

$payments->bind_param("i", $supplier_id);
$payments->execute();

$paymentRows = $payments->get_result();


$currentTotal =
    (float)$entry['quantity'] *
    (float)$entry['purchase_price'];


$page_title = "Stock In Details";

require "../includes/header.php";
require "../includes/sidebar.php";

?>

<div class="w-full max-w-6xl mx-auto">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">

        <div>

            <h2 class="text-2xl md:text-3xl font-black text-slate-800">
                Stock In Details
            </h2>

            <p class="text-sm text-slate-500 mt-1">
                Stock Entry #<?= $entry['id'] ?>
            </p>

        </div>

        <a
            href="view.php"
            class="btn bg-slate-100 text-slate-700"
        >
            <i data-lucide="arrow-left" class="w-4 h-4"></i>
            Back
        </a>

    </div>


    <?php if (!empty($error)): ?>

        <div class="mb-6 p-4 rounded-2xl bg-red-50 border border-red-100 text-red-600">

            <div class="flex items-center gap-3">

                <i
                    data-lucide="circle-alert"
                    class="w-5 h-5"
                ></i>

                <span>
                    <?= htmlspecialchars($error) ?>
                </span>

            </div>

        </div>

    <?php endif; ?>


    <div class="card overflow-hidden mb-6">

        <div class="bg-gradient-to-r from-blue-700 to-indigo-700 text-white p-6">

            <div class="flex items-center gap-4">

                <div class="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center">

                    <i
                        data-lucide="truck"
                        class="w-7 h-7"
                    ></i>

                </div>

                <div>

                    <div class="text-blue-200 text-sm">
                        Supplier
                    </div>

                    <h1 class="text-2xl font-black">

                        <?= htmlspecialchars(
                            $entry['supplier_name'] ?? 'No Supplier'
                        ) ?>

                    </h1>

                </div>

            </div>

        </div>


        <div class="p-6">

            <div class="grid md:grid-cols-4 gap-4">


                <div class="p-5 rounded-2xl bg-blue-50">

                    <div class="text-xs text-blue-500 font-bold">
                        TOTAL PURCHASE
                    </div>

                    <div class="text-2xl font-black text-blue-700 mt-2">

                        ₹<?= number_format(
                            $totalPurchaseAmount,
                            2
                        ) ?>

                    </div>

                </div>


                <div class="p-5 rounded-2xl bg-emerald-50">

                    <div class="text-xs text-emerald-600 font-bold">
                        TOTAL PAID
                    </div>

                    <div class="text-2xl font-black text-emerald-600 mt-2">

                        ₹<?= number_format(
                            $totalPaidAmount,
                            2
                        ) ?>

                    </div>

                </div>


                <div class="p-5 rounded-2xl bg-red-50">

                    <div class="text-xs text-red-500 font-bold">
                        TOTAL DUE
                    </div>

                    <div class="text-2xl font-black text-red-600 mt-2">

                        ₹<?= number_format(
                            $totalDue,
                            2
                        ) ?>

                    </div>

                </div>


                <div class="p-5 rounded-2xl bg-slate-50">

                    <div class="text-xs text-slate-500 font-bold">
                        STOCK ENTRIES
                    </div>

                    <div class="text-2xl font-black text-slate-800 mt-2">

                        <?= $stockRows->num_rows ?>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div class="grid lg:grid-cols-3 gap-6">


        <div class="lg:col-span-2">


            <div class="card overflow-hidden">

                <div class="p-5 border-b border-slate-100">

                    <h3 class="font-black text-lg">
                        Products Purchased
                    </h3>

                    <p class="text-sm text-slate-500 mt-1">
                        All stock received from this supplier
                    </p>

                </div>


                <div class="table-wrap">

                    <table class="table">

                        <thead>

                            <tr>

                                <th>
                                    Product
                                </th>

                                <th>
                                    Quantity
                                </th>

                                <th>
                                    Purchase Price
                                </th>

                                <th>
                                    Total
                                </th>

                                <th>
                                    Date
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                        <?php while ($r = $stockRows->fetch_assoc()): ?>

                            <?php

                            $rowTotal =
                                $r['quantity'] *
                                $r['purchase_price'];

                            ?>

                            <tr>

                                <td class="font-semibold">

                                    <?= htmlspecialchars(
                                        $r['product_name']
                                    ) ?>

                                </td>

                                <td>

                                    <span class="badge bg-blue-50 text-blue-700">

                                        <?= number_format(
                                            $r['quantity']
                                        ) ?>

                                    </span>

                                </td>

                                <td>

                                    ₹<?= number_format(
                                        $r['purchase_price'],
                                        2
                                    ) ?>

                                </td>

                                <td class="font-bold">

                                    ₹<?= number_format(
                                        $rowTotal,
                                        2
                                    ) ?>

                                </td>

                                <td class="text-slate-500">

                                    <?= date(
                                        'd M Y',
                                        strtotime($r['date'])
                                    ) ?>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                        </tbody>

                    </table>

                </div>

            </div>


            <div class="card overflow-hidden mt-6">

                <div class="p-5 border-b border-slate-100">

                    <h3 class="font-black text-lg">
                        Payment History
                    </h3>

                </div>


                <div class="table-wrap">

                    <table class="table">

                        <thead>

                            <tr>

                                <th>
                                    Amount
                                </th>

                                <th>
                                    Date
                                </th>

                                <th>
                                    Remarks
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                        <?php if ($paymentRows->num_rows > 0): ?>

                            <?php while ($pay = $paymentRows->fetch_assoc()): ?>

                                <tr>

                                    <td class="font-bold text-emerald-600">

                                        ₹<?= number_format(
                                            $pay['amount'],
                                            2
                                        ) ?>

                                    </td>

                                    <td>

                                        <?= date(
                                            'd M Y',
                                            strtotime($pay['date'])
                                        ) ?>

                                    </td>

                                    <td class="text-slate-500">

                                        <?= htmlspecialchars(
                                            $pay['remarks'] ?? ''
                                        ) ?>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>

                                <td
                                    colspan="3"
                                    class="text-center py-8 text-slate-400"
                                >
                                    No payment found.
                                </td>

                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>


        </div>


        <div>


            <div class="card p-6">

                <h3 class="font-black text-lg mb-5">
                    Supplier Details
                </h3>


                <div class="space-y-4">

                    <div>

                        <div class="text-xs text-slate-400">
                            Supplier Name
                        </div>

                        <div class="font-bold mt-1">

                            <?= htmlspecialchars(
                                $entry['supplier_name'] ?? '-'
                            ) ?>

                        </div>

                    </div>


                    <div>

                        <div class="text-xs text-slate-400">
                            Contact Person
                        </div>

                        <div class="font-bold mt-1">

                            <?= htmlspecialchars(
                                $entry['contact_person'] ?? '-'
                            ) ?>

                        </div>

                    </div>


                    <div>

                        <div class="text-xs text-slate-400">
                            Mobile
                        </div>

                        <div class="font-bold mt-1">

                            <?= htmlspecialchars(
                                $entry['mobile'] ?? '-'
                            ) ?>

                        </div>

                    </div>


                    <div>

                        <div class="text-xs text-slate-400">
                            Email
                        </div>

                        <div class="font-bold mt-1 break-all">

                            <?= htmlspecialchars(
                                $entry['email'] ?? '-'
                            ) ?>

                        </div>

                    </div>


                    <div>

                        <div class="text-xs text-slate-400">
                            Address
                        </div>

                        <div class="font-bold mt-1">

                            <?= nl2br(
                                htmlspecialchars(
                                    $entry['address'] ?? '-'
                                )
                            ) ?>

                        </div>

                    </div>

                </div>

            </div>


            <div class="card p-6 mt-6">

                <h3 class="font-black text-lg mb-5">
                    Payment Summary
                </h3>


                <div class="space-y-4">


                    <div class="flex justify-between">

                        <span class="text-slate-500">
                            Total Purchase
                        </span>

                        <span class="font-bold">

                            ₹<?= number_format(
                                $totalPurchaseAmount,
                                2
                            ) ?>

                        </span>

                    </div>


                    <div class="flex justify-between">

                        <span class="text-emerald-600 font-semibold">
                            Paid
                        </span>

                        <span class="font-bold text-emerald-600">

                            ₹<?= number_format(
                                $totalPaidAmount,
                                2
                            ) ?>

                        </span>

                    </div>


                    <div class="flex justify-between">

                        <span class="text-red-600 font-bold">
                            Due
                        </span>

                        <span class="text-xl font-black text-red-600">

                            ₹<?= number_format(
                                $totalDue,
                                2
                            ) ?>

                        </span>

                    </div>


                    <?php if ($totalDue > 0): ?>

                        <button
                            type="button"
                            onclick="document.getElementById('paymentBox').classList.toggle('hidden')"
                            class="w-full mt-3 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2"
                        >

                            <i
                                data-lucide="indian-rupee"
                                class="w-4 h-4"
                            ></i>

                            Pay Due

                        </button>


                        <div
                            id="paymentBox"
                            class="hidden mt-5 p-5 rounded-2xl bg-slate-50 border border-slate-200"
                        >

                            <h4 class="font-black text-lg mb-4">
                                Make Payment
                            </h4>


                            <form method="post">

                                <input
                                    type="hidden"
                                    name="make_payment"
                                    value="1"
                                >


                                <div class="mb-4">

                                    <label class="block text-sm font-bold mb-2">
                                        Payment Amount
                                    </label>

                                    <div class="relative">

                                        <span class="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-500">
                                            ₹
                                        </span>

                                        <input
                                            type="number"
                                            name="payment_amount"
                                            min="0.01"
                                            max="<?= $totalDue ?>"
                                            step="0.01"
                                            value="<?= $totalDue ?>"
                                            required
                                            class="input pl-9"
                                        >

                                    </div>

                                </div>


                                <div class="mb-4">

                                    <label class="block text-sm font-bold mb-2">
                                        Payment Date
                                    </label>

                                    <input
                                        type="date"
                                        name="payment_date"
                                        value="<?= date('Y-m-d') ?>"
                                        required
                                        class="input"
                                    >

                                </div>


                                <div class="mb-4">

                                    <label class="block text-sm font-bold mb-2">
                                        Remarks
                                    </label>

                                    <textarea
                                        name="payment_remarks"
                                        rows="2"
                                        class="input resize-none"
                                        placeholder="Payment remarks..."
                                    ></textarea>

                                </div>


                                <button
                                    type="submit"
                                    class="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2"
                                >

                                    <i
                                        data-lucide="check"
                                        class="w-4 h-4"
                                    ></i>

                                    Save Payment

                                </button>

                            </form>

                        </div>


                    <?php else: ?>

                        <div class="mt-4 p-4 rounded-2xl bg-emerald-50 text-emerald-600 text-center font-bold">

                            <i
                                data-lucide="circle-check"
                                class="w-5 h-5 inline-block align-middle"
                            ></i>

                            Fully Paid

                        </div>

                    <?php endif; ?>


                </div>

            </div>


            <div class="card p-6 mt-6">

                <div class="text-xs text-slate-400 font-bold mb-2">
                    CURRENT STOCK ENTRY
                </div>

                <div class="text-xl font-black text-slate-800">

                    <?= htmlspecialchars(
                        $entry['product_name']
                    ) ?>

                </div>

                <div class="grid grid-cols-2 gap-3 mt-5">

                    <div class="p-4 rounded-xl bg-slate-50">

                        <div class="text-xs text-slate-400">
                            Quantity
                        </div>

                        <div class="text-lg font-black mt-1">

                            <?= number_format(
                                $entry['quantity']
                            ) ?>

                        </div>

                    </div>


                    <div class="p-4 rounded-xl bg-slate-50">

                        <div class="text-xs text-slate-400">
                            Purchase
                        </div>

                        <div class="text-lg font-black mt-1">

                            ₹<?= number_format(
                                $entry['purchase_price'],
                                2
                            ) ?>

                        </div>

                    </div>


                    <div class="col-span-2 p-4 rounded-xl bg-blue-50">

                        <div class="text-xs text-blue-500">
                            This Entry Total
                        </div>

                        <div class="text-2xl font-black text-blue-600 mt-1">

                            ₹<?= number_format(
                                $currentTotal,
                                2
                            ) ?>

                        </div>

                    </div>

                </div>

            </div>


        </div>

    </div>

</div>

<?php require "../includes/footer.php"; ?>