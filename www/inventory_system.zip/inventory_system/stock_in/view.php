<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Stock In";

$rows = $conn->query("
    SELECT
        si.*,
        p.product_name,
        s.supplier_name
    FROM stock_in si
    JOIN products p
        ON p.id = si.product_id
    LEFT JOIN supplier s
        ON s.id = si.supplier_id
    ORDER BY si.id DESC
");

$totalEntries = $conn->query("
    SELECT COUNT(*) AS total
    FROM stock_in
")->fetch_assoc()['total'];

$totalQuantity = $conn->query("
    SELECT COALESCE(SUM(quantity), 0) AS total
    FROM stock_in
")->fetch_assoc()['total'];

$totalValue = $conn->query("
    SELECT COALESCE(SUM(quantity * purchase_price), 0) AS total
    FROM stock_in
")->fetch_assoc()['total'];

require "../includes/header.php";
require "../includes/sidebar.php";

?>

<div class="w-full">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">

        <div>

            <div class="flex items-center gap-3">

                <div class="w-11 h-11 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">

                    <i data-lucide="arrow-down-to-line" class="w-5 h-5"></i>

                </div>

                <div>

                    <h2 class="text-2xl font-bold text-slate-800">
                        Stock In
                    </h2>

                    <p class="text-sm text-slate-500 mt-1">
                        Track products received from suppliers
                    </p>

                </div>

            </div>

        </div>


        <a
            href="add.php"
            class="btn bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-600/20"
        >

            <i data-lucide="plus" class="w-4 h-4"></i>

            Stock In

        </a>

    </div>


    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">


        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">

                    <i data-lucide="package-plus" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Total Entries
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">
                        <?= number_format($totalEntries) ?>
                    </h3>

                </div>

            </div>

        </div>


        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div class="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">

                    <i data-lucide="boxes" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Total Quantity
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">
                        <?= number_format($totalQuantity) ?>
                    </h3>

                </div>

            </div>

        </div>


        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div class="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">

                    <i data-lucide="indian-rupee" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Purchase Value
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">
                        ₹<?= number_format($totalValue, 2) ?>
                    </h3>

                </div>

            </div>

        </div>

    </div>


    <div class="card overflow-hidden">

        <div class="p-5 md:p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">

            <div>

                <h3 class="font-bold text-lg text-slate-800">
                    Stock In History
                </h3>

                <p class="text-sm text-slate-500 mt-1">
                    Products received from suppliers
                </p>

            </div>


            <div class="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-blue-50 text-blue-700 text-xs font-bold">

                <span class="w-2 h-2 rounded-full bg-blue-500"></span>

                Inventory Updated

            </div>

        </div>


        <div class="table-wrap">

            <table class="table">

                <thead>

                    <tr>

                        <th>
                            Product
                        </th>

                        <th>
                            Supplier
                        </th>

                        <th>
                            Quantity
                        </th>

                        <th>
                            Purchase Price
                        </th>

                        <th>
                            Total
                        </th>

                        <th>
                            Date
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody>

                <?php if ($rows->num_rows > 0): ?>

                    <?php while ($r = $rows->fetch_assoc()): ?>

                        <?php

                        $total = $r['quantity'] * $r['purchase_price'];

                        ?>

                        <tr>

                            <td>

                                <div class="flex items-center gap-3">

                                    <div class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">

                                        <i
                                            data-lucide="package"
                                            class="w-5"
                                        ></i>

                                    </div>


                                    <div>

                                        <div class="font-semibold text-slate-800">

                                            <?= htmlspecialchars(
                                                $r['product_name']
                                            ) ?>

                                        </div>

                                        <div class="text-xs text-slate-400">

                                            Stock Entry #<?= $r['id'] ?>

                                        </div>

                                    </div>

                                </div>

                            </td>


                            <td>

                                <?php if (!empty($r['supplier_name'])): ?>

                                    <div class="flex items-center gap-2">

                                        <div class="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">

                                            <i
                                                data-lucide="truck"
                                                class="w-4"
                                            ></i>

                                        </div>

                                        <span class="font-semibold text-slate-700">

                                            <?= htmlspecialchars(
                                                $r['supplier_name']
                                            ) ?>

                                        </span>

                                    </div>

                                <?php else: ?>

                                    <span class="text-slate-400">
                                        No Supplier
                                    </span>

                                <?php endif; ?>

                            </td>


                            <td>

                                <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 text-blue-700 font-bold text-xs">

                                    <i
                                        data-lucide="plus"
                                        class="w-3 h-3"
                                    ></i>

                                    <?= number_format(
                                        $r['quantity']
                                    ) ?>

                                </span>

                            </td>


                            <td>

                                ₹<?= number_format(
                                    $r['purchase_price'],
                                    2
                                ) ?>

                            </td>


                            <td>

                                <span class="font-bold text-emerald-600">

                                    ₹<?= number_format(
                                        $total,
                                        2
                                    ) ?>

                                </span>

                            </td>


                            <td>

                                <div class="flex items-center gap-2 text-slate-600">

                                    <i
                                        data-lucide="calendar-days"
                                        class="w-4 text-slate-400"
                                    ></i>

                                    <?= date(
                                        'd M Y',
                                        strtotime($r['date'])
                                    ) ?>

                                </div>

                            </td>


                            <td>

                                <span class="badge bg-emerald-50 text-emerald-700">

                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5"></span>

                                    Received

                                </span>

                            </td>


                            <td>

                                <a
                                    href="detail.php?id=<?= $r['id'] ?>"
                                    class="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 inline-flex items-center justify-center hover:bg-blue-100"
                                    title="View Details"
                                >

                                    <i
                                        data-lucide="eye"
                                        class="w-4 h-4"
                                    ></i>

                                </a>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="8"
                            class="text-center py-12"
                        >

                            <div class="flex flex-col items-center">

                                <div class="w-14 h-14 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mb-3">

                                    <i
                                        data-lucide="package-x"
                                        class="w-7"
                                    ></i>

                                </div>

                                <h3 class="font-semibold text-slate-700">
                                    No stock entries found
                                </h3>

                                <p class="text-sm text-slate-400 mt-1">
                                    Add stock to see the history here.
                                </p>

                            </div>

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php require "../includes/footer.php"; ?>