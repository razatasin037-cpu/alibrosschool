<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Edit Product";

$id = (int)($_GET['id'] ?? 0);

if ($id < 1) {
    header("Location: view.php");
    exit;
}

$s = $conn->prepare("
    SELECT *
    FROM products
    WHERE id = ?
");

$s->bind_param("i", $id);
$s->execute();

$r = $s->get_result()->fetch_assoc();

if (!$r) {
    header("Location: view.php");
    exit;
}

$cats = $conn->query("
    SELECT id, category_name
    FROM category
    ORDER BY category_name
");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $n = trim($_POST['product_name'] ?? '');
    $cat = (int)($_POST['category_id'] ?? 0);
    $buy = (float)($_POST['purchase_price'] ?? 0);
    $price = (float)($_POST['price'] ?? 0);
    $d = trim($_POST['description'] ?? '');

    if ($n === '') {

        $error = "Product name is required.";

    } elseif ($cat < 1) {

        $error = "Please select a category.";

    } elseif ($buy < 0 || $price < 0) {

        $error = "Price cannot be negative.";

    } else {

        $s = $conn->prepare("
            UPDATE products
            SET
                product_name = ?,
                category_id = ?,
                price = ?,
                purchase_price = ?,
                description = ?
            WHERE id = ?
        ");

        $s->bind_param(
            "siddsi",
            $n,
            $cat,
            $price,
            $buy,
            $d,
            $id
        );

        $s->execute();

        header("Location: view.php");
        exit;
    }
}

require "../includes/header.php";
require "../includes/sidebar.php";

?>

<div class="w-full">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">

        <div>

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-11 h-11
                        rounded-2xl
                        bg-blue-50
                        text-blue-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i data-lucide="package-pen" class="w-5 h-5"></i>

                </div>

                <div>

                    <h2 class="text-2xl font-bold text-slate-800">
                        Edit Product
                    </h2>

                    <p class="text-sm text-slate-500 mt-1">
                        Update product information and pricing
                    </p>

                </div>

            </div>

        </div>


        <a
            href="view.php"
            class="
                btn
                bg-slate-100
                hover:bg-slate-200
                text-slate-700
            "
        >

            <i data-lucide="arrow-left" class="w-4 h-4"></i>

            Back to Products

        </a>

    </div>


    <?php if (!empty($error)): ?>

        <div
            class="
                mb-6
                p-4
                rounded-2xl
                bg-red-50
                border
                border-red-100
                text-red-600
                flex
                items-center
                gap-3
            "
        >

            <i
                data-lucide="circle-alert"
                class="w-5 h-5"
            ></i>

            <?= htmlspecialchars($error) ?>

        </div>

    <?php endif; ?>


    <div class="card w-full p-6 md:p-8">

        <form
            method="post"
            class="
                grid
                grid-cols-1
                md:grid-cols-2
                gap-6
            "
        >

            <div class="md:col-span-2">

                <label
                    class="
                        block
                        text-sm
                        font-semibold
                        text-slate-700
                        mb-2
                    "
                >

                    Product Name

                    <span class="text-red-500">*</span>

                </label>


                <div class="relative">

                    <i
                        data-lucide="package"
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            w-5
                            h-5
                            text-slate-400
                        "
                    ></i>


                    <input
                        type="text"
                        name="product_name"
                        required
                        value="<?= htmlspecialchars($r['product_name']) ?>"
                        placeholder="Enter product name"
                        class="input pl-12"
                    >

                </div>

            </div>


            <div>

                <label
                    class="
                        block
                        text-sm
                        font-semibold
                        text-slate-700
                        mb-2
                    "
                >

                    Category

                    <span class="text-red-500">*</span>

                </label>


                <div class="relative">

                    <i
                        data-lucide="folder-kanban"
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            w-5
                            h-5
                            text-slate-400
                            pointer-events-none
                        "
                    ></i>


                    <select
                        name="category_id"
                        required
                        class="
                            input
                            pl-12
                            appearance-none
                        "
                    >

                        <option value="">
                            Select category
                        </option>

                        <?php while ($c = $cats->fetch_assoc()): ?>

                            <option
                                value="<?= $c['id'] ?>"
                                <?= $r['category_id'] == $c['id']
                                    ? 'selected'
                                    : '' ?>
                            >

                                <?= htmlspecialchars(
                                    $c['category_name']
                                ) ?>

                            </option>

                        <?php endwhile; ?>

                    </select>

                </div>

            </div>


            <div>

                <label
                    class="
                        block
                        text-sm
                        font-semibold
                        text-slate-700
                        mb-2
                    "
                >

                    Current Stock

                </label>


                <div class="relative">

                    <i
                        data-lucide="boxes"
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            w-5
                            text-slate-400
                        "
                    ></i>


                    <input
                        type="text"
                        value="<?= number_format($r['stock']) ?> units"
                        readonly
                        class="
                            input
                            pl-12
                            bg-slate-50
                            text-slate-500
                            cursor-not-allowed
                        "
                    >

                </div>


                <p class="text-xs text-slate-400 mt-2">

                    Stock is managed through Stock In and Sales.

                </p>

            </div>


            <div>

                <label
                    class="
                        block
                        text-sm
                        font-semibold
                        text-slate-700
                        mb-2
                    "
                >

                    Purchase Price

                </label>


                <div class="relative">

                    <span
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            text-slate-400
                            font-semibold
                        "
                    >

                        ₹

                    </span>


                    <input
                        type="number"
                        name="purchase_price"
                        step="0.01"
                        min="0"
                        value="<?= htmlspecialchars($r['purchase_price']) ?>"
                        placeholder="0.00"
                        class="input pl-10"
                    >

                </div>

            </div>


            <div>

                <label
                    class="
                        block
                        text-sm
                        font-semibold
                        text-slate-700
                        mb-2
                    "
                >

                    Selling Price

                </label>


                <div class="relative">

                    <span
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            text-slate-400
                            font-semibold
                        "
                    >

                        ₹

                    </span>


                    <input
                        type="number"
                        name="price"
                        step="0.01"
                        min="0"
                        value="<?= htmlspecialchars($r['price']) ?>"
                        placeholder="0.00"
                        class="input pl-10"
                    >

                </div>

            </div>


            <div class="md:col-span-2">

                <label
                    class="
                        block
                        text-sm
                        font-semibold
                        text-slate-700
                        mb-2
                    "
                >

                    Description

                </label>


                <div class="relative">

                    <i
                        data-lucide="file-text"
                        class="
                            absolute
                            left-4
                            top-4
                            w-5
                            h-5
                            text-slate-400
                        "
                    ></i>


                    <textarea
                        name="description"
                        rows="6"
                        placeholder="Enter product description..."
                        class="
                            input
                            pl-12
                            resize-none
                        "
                    ><?= htmlspecialchars($r['description'] ?? '') ?></textarea>

                </div>

            </div>


            <div
                class="
                    md:col-span-2
                    flex
                    flex-col
                    sm:flex-row
                    justify-between
                    items-center
                    gap-4
                    pt-5
                    border-t
                    border-slate-100
                "
            >

                <div
                    class="
                        flex
                        items-center
                        gap-2
                        text-xs
                        text-slate-400
                    "
                >

                    <i
                        data-lucide="shield-check"
                        class="w-4 h-4"
                    ></i>

                    Product information will be updated securely.

                </div>


                <div class="flex gap-3 w-full sm:w-auto">

                    <a
                        href="view.php"
                        class="
                            flex-1
                            sm:flex-none
                            px-6
                            py-3
                            rounded-xl
                            bg-slate-100
                            hover:bg-slate-200
                            text-slate-700
                            font-semibold
                            text-center
                            transition
                        "
                    >

                        Cancel

                    </a>


                    <button
                        type="submit"
                        class="
                            btn
                            flex-1
                            sm:flex-none
                            bg-blue-600
                            hover:bg-blue-700
                            text-white
                            shadow-lg
                            shadow-blue-600/20
                        "
                    >

                        <i
                            data-lucide="save"
                            class="w-4 h-4"
                        ></i>

                        Update Product

                    </button>

                </div>

            </div>

        </form>

    </div>

</div>


<?php

require "../includes/footer.php";

?>