<?php

require "../includes/auth.php";
require "../includes/connection.php";

$id = (int)($_GET['id'] ?? 0);

if ($id < 1) {
    header("Location: view.php");
    exit;
}

$s = $conn->prepare("
    SELECT product_name
    FROM products
    WHERE id = ?
");

$s->bind_param("i", $id);
$s->execute();

$product = $s->get_result()->fetch_assoc();

if (!$product) {
    header("Location: view.php");
    exit;
}

$s = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM stock_in
    WHERE product_id = ?
");

$s->bind_param("i", $id);
$s->execute();

$stockIn = $s->get_result()->fetch_assoc()['total'];

$s = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM stock_out
    WHERE product_id = ?
");

$s->bind_param("i", $id);
$s->execute();

$stockOut = $s->get_result()->fetch_assoc()['total'];

if ($stockIn > 0 || $stockOut > 0) {

    echo "<script>
        alert('This product cannot be deleted because it has stock or sales history.');
        window.location.href='view.php';
    </script>";

    exit;
}

$s = $conn->prepare("
    DELETE FROM products
    WHERE id = ?
");

$s->bind_param("i", $id);
$s->execute();

header("Location: view.php");
exit;

?>