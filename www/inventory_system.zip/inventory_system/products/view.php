<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Products";

require "../includes/header.php";
require "../includes/sidebar.php";

$q = trim($_GET['q'] ?? '');
$like = "%$q%";

$s = $conn->prepare("
    SELECT
        p.*,
        c.category_name
    FROM products p
    LEFT JOIN category c
        ON c.id = p.category_id
    WHERE p.product_name LIKE ?
    ORDER BY p.id DESC
");

$s->bind_param("s", $like);
$s->execute();

$rows = $s->get_result();

?>

<div class="w-full">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">

        <div>

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-11 h-11
                        rounded-2xl
                        bg-blue-50
                        text-blue-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i data-lucide="package" class="w-5 h-5"></i>

                </div>

                <div>

                    <h2 class="text-2xl font-bold text-slate-800">
                        Products
                    </h2>

                    <p class="text-sm text-slate-500 mt-1">
                        Manage products, pricing and stock
                    </p>

                </div>

            </div>

        </div>


        <a
            href="add.php"
            class="
                btn
                bg-blue-600
                hover:bg-blue-700
                text-white
                shadow-lg
                shadow-blue-600/20
            "
        >

            <i data-lucide="plus" class="w-4 h-4"></i>

            Add Product

        </a>

    </div>


    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">

        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-blue-50
                        text-blue-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i data-lucide="package" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Total Products
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">
                        <?= $rows->num_rows ?>
                    </h3>

                </div>

            </div>

        </div>


        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-emerald-50
                        text-emerald-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i data-lucide="boxes" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Total Stock
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">

                        <?php

                        $totalStock = $conn->query("
                            SELECT COALESCE(SUM(stock), 0) AS total
                            FROM products
                        ")->fetch_assoc()['total'];

                        echo number_format($totalStock);

                        ?>

                    </h3>

                </div>

            </div>

        </div>


        <div class="card p-5">

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-red-50
                        text-red-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i data-lucide="triangle-alert" class="w-5"></i>

                </div>

                <div>

                    <p class="text-xs text-slate-500">
                        Low Stock
                    </p>

                    <h3 class="text-2xl font-bold text-slate-800">

                        <?php

                        $lowStock = $conn->query("
                            SELECT COUNT(*) AS total
                            FROM products
                            WHERE stock <= 10
                        ")->fetch_assoc()['total'];

                        echo $lowStock;

                        ?>

                    </h3>

                </div>

            </div>

        </div>

    </div>


    <div class="card overflow-hidden">

        <div
            class="
                p-5
                md:p-6
                border-b
                border-slate-100
                flex
                flex-col
                lg:flex-row
                lg:items-center
                justify-between
                gap-4
            "
        >

            <div>

                <h3 class="font-bold text-lg text-slate-800">
                    Product Inventory
                </h3>

                <p class="text-sm text-slate-500 mt-1">
                    View and manage all products
                </p>

            </div>


            <form
                method="get"
                class="
                    flex
                    w-full
                    lg:w-auto
                    gap-2
                "
            >

                <div class="relative flex-1 lg:w-80">

                    <i
                        data-lucide="search"
                        class="
                            absolute
                            left-4
                            top-1/2
                            -translate-y-1/2
                            w-4
                            text-slate-400
                        "
                    ></i>

                    <input
                        type="text"
                        name="q"
                        value="<?= htmlspecialchars($q) ?>"
                        placeholder="Search product..."
                        class="
                            input
                            pl-11
                        "
                    >

                </div>


                <button
                    type="submit"
                    class="
                        btn
                        bg-slate-900
                        hover:bg-slate-800
                        text-white
                        px-5
                    "
                >

                    Search

                </button>


                <?php if ($q): ?>

                    <a
                        href="view.php"
                        class="
                            btn
                            bg-slate-100
                            hover:bg-slate-200
                            text-slate-700
                        "
                    >

                        Clear

                    </a>

                <?php endif; ?>

            </form>

        </div>


        <div class="table-wrap">

            <table class="table">

                <thead>

                    <tr>

                        <th>
                            Product
                        </th>

                        <th>
                            Category
                        </th>

                        <th>
                            Purchase
                        </th>

                        <th>
                            Sale Price
                        </th>

                        <th>
                            Stock
                        </th>

                        <th>
                            Stock Value
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody>

                    <?php if ($rows->num_rows > 0): ?>

                        <?php while ($r = $rows->fetch_assoc()): ?>

                            <?php

                            $stockValue =
                                $r['stock']
                                * $r['purchase_price'];

                            ?>

                            <tr>

                                <td>

                                    <div class="flex items-center gap-3">

                                        <div
                                            class="
                                                w-10 h-10
                                                rounded-xl
                                                bg-blue-50
                                                text-blue-600
                                                flex
                                                items-center
                                                justify-center
                                            "
                                        >

                                            <i
                                                data-lucide="package"
                                                class="w-5"
                                            ></i>

                                        </div>


                                        <div>

                                            <div class="font-semibold text-slate-800">

                                                <?= htmlspecialchars(
                                                    $r['product_name']
                                                ) ?>

                                            </div>

                                            <div class="text-xs text-slate-400">

                                                Product #<?= $r['id'] ?>

                                            </div>

                                        </div>

                                    </div>

                                </td>


                                <td>

                                    <?php if (!empty($r['category_name'])): ?>

                                        <span
                                            class="
                                                badge
                                                bg-slate-100
                                                text-slate-600
                                            "
                                        >

                                            <?= htmlspecialchars(
                                                $r['category_name']
                                            ) ?>

                                        </span>

                                    <?php else: ?>

                                        <span class="text-slate-400">
                                            -
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    ₹<?= number_format(
                                        $r['purchase_price'],
                                        2
                                    ) ?>

                                </td>


                                <td>

                                    <span class="font-semibold text-slate-800">

                                        ₹<?= number_format(
                                            $r['price'],
                                            2
                                        ) ?>

                                    </span>

                                </td>


                                <td>

                                    <span
                                        class="
                                            badge
                                            bg-blue-50
                                            text-blue-700
                                        "
                                    >

                                        <?= number_format(
                                            $r['stock']
                                        ) ?>

                                    </span>

                                </td>


                                <td>

                                    ₹<?= number_format(
                                        $stockValue,
                                        2
                                    ) ?>

                                </td>


                                <td>

                                    <?php if ($r['stock'] <= 0): ?>

                                        <span
                                            class="
                                                badge
                                                bg-red-50
                                                text-red-600
                                            "
                                        >

                                            Out of Stock

                                        </span>

                                    <?php elseif ($r['stock'] <= 10): ?>

                                        <span
                                            class="
                                                badge
                                                bg-amber-50
                                                text-amber-700
                                            "
                                        >

                                            Low Stock

                                        </span>

                                    <?php else: ?>

                                        <span
                                            class="
                                                badge
                                                bg-emerald-50
                                                text-emerald-700
                                            "
                                        >

                                            In Stock

                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <div class="flex items-center gap-2">

                                        <a
                                            href="edit.php?id=<?= $r['id'] ?>"
                                            class="
                                                inline-flex
                                                items-center
                                                gap-1.5
                                                px-3
                                                py-2
                                                rounded-xl
                                                bg-blue-50
                                                text-blue-600
                                                hover:bg-blue-100
                                                text-xs
                                                font-semibold
                                                transition
                                            "
                                        >

                                            <i
                                                data-lucide="pencil"
                                                class="w-4"
                                            ></i>

                                            Edit

                                        </a>


                                        <a
                                            href="delete.php?id=<?= $r['id'] ?>"
                                            onclick="return confirm('Are you sure you want to delete this product?')"
                                            class="
                                                inline-flex
                                                items-center
                                                gap-1.5
                                                px-3
                                                py-2
                                                rounded-xl
                                                bg-red-50
                                                text-red-600
                                                hover:bg-red-100
                                                text-xs
                                                font-semibold
                                                transition
                                            "
                                        >

                                            <i
                                                data-lucide="trash-2"
                                                class="w-4"
                                            ></i>

                                            Delete

                                        </a>

                                    </div>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>

                            <td
                                colspan="8"
                                class="text-center py-12"
                            >

                                <div class="flex flex-col items-center">

                                    <div
                                        class="
                                            w-14 h-14
                                            rounded-2xl
                                            bg-slate-100
                                            text-slate-400
                                            flex
                                            items-center
                                            justify-center
                                            mb-3
                                        "
                                    >

                                        <i
                                            data-lucide="package-x"
                                            class="w-7"
                                        ></i>

                                    </div>

                                    <h3 class="font-semibold text-slate-700">

                                        No products found

                                    </h3>

                                    <p class="text-sm text-slate-400 mt-1">

                                        <?php if ($q): ?>

                                            No product matches
                                            "<?= htmlspecialchars($q) ?>".

                                        <?php else: ?>

                                            Add your first product to get started.

                                        <?php endif; ?>

                                    </p>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<?php

require "../includes/footer.php";

?>