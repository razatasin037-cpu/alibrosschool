<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Add Product";

/* Category list */
$cats = $conn->query(
    "SELECT id, category_name 
     FROM category 
     ORDER BY category_name"
);


/* Form submit */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $n = trim($_POST['product_name']);

    $cat = (int) $_POST['category_id'];

    $buy = (float) $_POST['purchase_price'];

    $price = (float) $_POST['price'];

    $d = trim($_POST['description']);


    /* Insert Product */

    $s = $conn->prepare(
        "INSERT INTO products
        (product_name, category_id, price, purchase_price, description)
        VALUES (?, ?, ?, ?, ?)"
    );

    $s->bind_param(
        "sidds",
        $n,
        $cat,
        $price,
        $buy,
        $d
    );

    $s->execute();

    header("Location:view.php");

    exit;
}


require "../includes/header.php";
require "../includes/sidebar.php";

?>


<div class="w-full">

    <!-- Page Header -->

    <div class="mb-6">

        <div class="flex items-center gap-3">

            <div
                class="w-11 h-11 rounded-2xl
                bg-blue-50 text-blue-600
                flex items-center justify-center"
            >

                <i
                    data-lucide="package-plus"
                    class="w-5 h-5"
                ></i>

            </div>


            <div>

                <h2 class="text-2xl font-bold text-slate-800">

                    Add New Product

                </h2>

                <p class="text-sm text-slate-500 mt-1">

                    Add product information to your inventory

                </p>

            </div>

        </div>

    </div>



    <!-- Product Form -->

    <div class="card w-full p-6 md:p-8">

        <form
            method="post"
            class="grid grid-cols-1 md:grid-cols-2 gap-6"
        >


            <!-- Product Name -->

            <div class="md:col-span-2">

                <label
                    class="block text-sm font-semibold text-slate-700 mb-2"
                >

                    Product Name

                    <span class="text-red-500">*</span>

                </label>


                <div class="relative">

                    <i
                        data-lucide="package"
                        class="absolute left-4 top-1/2
                        -translate-y-1/2
                        w-5 h-5 text-slate-400"
                    ></i>


                    <input
                        type="text"
                        name="product_name"
                        required
                        placeholder="Enter product name"
                        class="input pl-12"
                    >

                </div>

            </div>



            <!-- Category -->

            <div>

                <label
                    class="block text-sm font-semibold
                    text-slate-700 mb-2"
                >

                    Category

                    <span class="text-red-500">*</span>

                </label>


                <div class="relative">

                    <i
                        data-lucide="folder"
                        class="absolute left-4 top-1/2
                        -translate-y-1/2
                        w-5 h-5 text-slate-400
                        pointer-events-none"
                    ></i>


                    <select
                        name="category_id"
                        required
                        class="input pl-12 appearance-none"
                    >

                        <option value="">
                            Select Category
                        </option>


                        <?php while ($c = $cats->fetch_assoc()) { ?>

                            <option value="<?= $c['id'] ?>">

                                <?= htmlspecialchars(
                                    $c['category_name']
                                ) ?>

                            </option>

                        <?php } ?>

                    </select>

                </div>

            </div>



            <!-- Purchase Price -->

            <div>

                <label
                    class="block text-sm font-semibold
                    text-slate-700 mb-2"
                >

                    Purchase Price

                </label>


                <div class="relative">

                    <span
                        class="absolute left-4 top-1/2
                        -translate-y-1/2
                        text-slate-400 font-bold"
                    >

                        ₹

                    </span>


                    <input
                        type="number"
                        name="purchase_price"
                        step="0.01"
                        min="0"
                        placeholder="0.00"
                        class="input pl-10"
                    >

                </div>

            </div>



            <!-- Selling Price -->

            <div>

                <label
                    class="block text-sm font-semibold
                    text-slate-700 mb-2"
                >

                    Selling Price

                </label>


                <div class="relative">

                    <span
                        class="absolute left-4 top-1/2
                        -translate-y-1/2
                        text-slate-400 font-bold"
                    >

                        ₹

                    </span>


                    <input
                        type="number"
                        name="price"
                        step="0.01"
                        min="0"
                        placeholder="0.00"
                        class="input pl-10"
                    >

                </div>

            </div>



            <!-- Description -->

            <div class="md:col-span-2">

                <label
                    class="block text-sm font-semibold
                    text-slate-700 mb-2"
                >

                    Product Description

                </label>


                <div class="relative">

                    <i
                        data-lucide="file-text"
                        class="absolute left-4 top-4
                        w-5 h-5 text-slate-400"
                    ></i>


                    <textarea
                        name="description"
                        rows="6"
                        placeholder="Enter product description..."
                        class="input pl-12 resize-none"
                    ></textarea>

                </div>

            </div>



            <!-- Information -->

            <div
                class="md:col-span-2
                bg-blue-50 border border-blue-100
                rounded-2xl p-4
                flex gap-3"
            >

                <div
                    class="w-10 h-10 rounded-xl
                    bg-blue-100 text-blue-600
                    flex items-center justify-center
                    shrink-0"
                >

                    <i
                        data-lucide="info"
                        class="w-5 h-5"
                    ></i>

                </div>


                <div>

                    <h4
                        class="font-semibold text-blue-800"
                    >

                        Product Information

                    </h4>


                    <p
                        class="text-sm text-blue-600 mt-1"
                    >

                        Purchase price is your buying cost
                        and selling price is the price
                        charged to customers.

                    </p>

                </div>

            </div>



            <!-- Buttons -->

            <div
                class="md:col-span-2
                flex flex-col sm:flex-row
                justify-between items-center
                gap-4 pt-5
                border-t border-slate-100"
            >


                <div
                    class="flex items-center gap-2
                    text-xs text-slate-400"
                >

                    <i
                        data-lucide="shield-check"
                        class="w-4 h-4"
                    ></i>

                    Product data will be stored securely.

                </div>



                <div
                    class="flex gap-3
                    w-full sm:w-auto"
                >

                    <a
                        href="view.php"
                        class="
                        flex-1 sm:flex-none
                        px-6 py-3
                        rounded-xl
                        bg-slate-100
                        hover:bg-slate-200
                        text-slate-700
                        font-semibold
                        text-center
                        transition
                        "
                    >

                        Cancel

                    </a>


                    <button
                        type="submit"
                        class="
                        btn btn-primary
                        px-7
                        flex-1 sm:flex-none
                        "
                    >

                        <i
                            data-lucide="plus"
                            class="w-4 h-4"
                        ></i>

                        Save Product

                    </button>

                </div>

            </div>


        </form>

    </div>

</div>



<?php

require "../includes/footer.php";

?>