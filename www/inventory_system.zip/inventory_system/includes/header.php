<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$page_title = $page_title ?? "Inventory";

?>

<!doctype html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        <?= htmlspecialchars($page_title) ?> | Inventory Pro
    </title>


    <!-- Tailwind CSS -->

    <script src="https://cdn.tailwindcss.com"></script>


    <!-- Tailwind Configuration -->

    <script>

        tailwind.config = {

            theme: {

                extend: {

                    fontFamily: {

                        sans: [
                            'Inter',
                            'ui-sans-serif',
                            'system-ui'
                        ]

                    },

                    boxShadow: {

                        soft:
                            '0 10px 40px rgba(15,23,42,.08)',

                        glow:
                            '0 0 0 1px rgba(255,255,255,.12), 0 20px 50px rgba(15,23,42,.18)'

                    },

                    borderRadius: {

                        '4xl': '2rem'

                    }

                }

            }

        };

    </script>


    <!-- Lucide Icons -->

    <script src="https://unpkg.com/lucide@latest"></script>


    <!-- Custom CSS -->

    <style>

        * {
            box-sizing: border-box;
        }


        body {

            font-family:
                Inter,
                ui-sans-serif,
                system-ui,
                sans-serif;

            background: #f5f7fb;

            color: #0f172a;

        }


        /* Card */

        .card {

            background: rgba(255, 255, 255, 0.96);

            border: 1px solid #e8edf5;

            border-radius: 22px;

            box-shadow:
                0 10px 40px rgba(15, 23, 42, 0.06);

        }


        /* Input */

        .input {

            width: 100%;

            border: 1px solid #e2e8f0;

            border-radius: 14px;

            padding: 0.78rem 1rem;

            outline: none;

            background: #ffffff;

            transition: 0.2s;

        }


        .input:focus {

            border-color: #3b82f6;

            box-shadow:
                0 0 0 4px rgba(59, 130, 246, 0.10);

        }


        /* Button */

        .btn {

            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 0.5rem;

            border-radius: 13px;

            padding: 0.72rem 1rem;

            font-weight: 700;

            transition: 0.2s;

        }


        /* Primary Button */

        .btn-primary {

            background: #2563eb;

            color: #ffffff;

            box-shadow:
                0 8px 20px rgba(37, 99, 235, 0.22);

        }


        .btn-primary:hover {

            background: #1d4ed8;

            transform: translateY(-1px);

        }


        /* Dark Button */

        .btn-dark {

            background: #0f172a;

            color: #ffffff;

        }


        /* Soft Button */

        .btn-soft {

            background: #eff6ff;

            color: #2563eb;

        }


        /* Table */

        .table-wrap {

            overflow: auto;

        }


        .table {

            width: 100%;

            font-size: 0.875rem;

        }


        .table th {

            padding: 1rem;

            text-align: left;

            color: #64748b;

            font-weight: 700;

            background: #f8fafc;

            white-space: nowrap;

        }


        .table td {

            padding: 1rem;

            border-top: 1px solid #eef2f7;

            white-space: nowrap;

        }


        /* Badge */

        .badge {

            display: inline-flex;

            align-items: center;

            padding: 0.32rem 0.65rem;

            border-radius: 999px;

            font-size: 0.72rem;

            font-weight: 800;

        }


        /* Scrollbar */

        ::-webkit-scrollbar {

            width: 8px;

            height: 8px;

        }


        ::-webkit-scrollbar-thumb {

            background: #cbd5e1;

            border-radius: 20px;

        }


        /* Sidebar */

        .sidebar-link {

            display: flex;

            align-items: center;

            gap: 0.75rem;

            padding: 0.78rem 0.9rem;

            border-radius: 14px;

            color: #94a3b8;

            font-weight: 600;

            transition: 0.2s;

        }


        .sidebar-link:hover,

        .sidebar-link.active {

            background: rgba(255, 255, 255, 0.08);

            color: #ffffff;

        }


        /* Mobile Backdrop */

        .mobile-backdrop {

            display: none;

        }


        .mobile-backdrop.show {

            display: block;

        }

    </style>

</head>


<body>

    <div class="min-h-screen flex">