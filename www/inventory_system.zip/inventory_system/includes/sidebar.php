<?php

$current_page = basename($_SERVER['PHP_SELF']);

?>

<aside
    id="sidebar"
    class="
        fixed md:sticky
        top-0
        h-screen
        z-50
        w-[270px]
        bg-[#07111f]
        text-white
        -translate-x-full
        md:translate-x-0
        transition-transform
        duration-300
        shadow-glow
        flex flex-col
    "
>

    <!-- Logo -->
    <div class="px-5 pt-6 pb-5 border-b border-white/10">

        <div class="flex items-center gap-3">

            <div
                class="
                    w-11 h-11
                    rounded-2xl
                    bg-gradient-to-br
                    from-blue-500
                    to-indigo-600
                    flex items-center justify-center
                    shadow-lg
                "
            >

                <i
                    data-lucide="boxes"
                    class="w-6 h-6"
                ></i>

            </div>

            <div>

                <div class="font-extrabold tracking-tight text-lg">

                    Inventory<span class="text-blue-400">Pro</span>

                </div>

                <div class="text-[11px] text-slate-500">

                    CONTROL CENTER

                </div>

            </div>

        </div>

    </div>


    <!-- Navigation -->

    <div class="px-4 pt-5">

        <div
            class="
                text-[10px]
                uppercase
                tracking-[.18em]
                text-slate-600
                font-bold
                px-2
                mb-2
            "
        >

            Workspace

        </div>


        <nav class="space-y-1">


            <!-- Dashboard -->

            <a
                href="../admin/dashboard.php"
                class="sidebar-link <?= $current_page === 'dashboard.php' ? 'active' : '' ?>"
            >

                <i
                    data-lucide="layout-dashboard"
                    class="w-4 h-4"
                ></i>

                Dashboard

            </a>



            <!-- Categories -->

            <a
                href="../category/view.php"
                class="sidebar-link <?= $current_page === 'view.php' && str_contains($_SERVER['REQUEST_URI'], '/category/') ? 'active' : '' ?>"
            >

                <i
                    data-lucide="folder-kanban"
                    class="w-4 h-4"
                ></i>

                Categories

            </a>



            <!-- Suppliers -->

            <a
                href="../supplier/view.php"
                class="sidebar-link <?= str_contains($_SERVER['REQUEST_URI'], '/supplier/') ? 'active' : '' ?>"
            >

                <i
                    data-lucide="truck"
                    class="w-4 h-4"
                ></i>

                Suppliers

            </a>



            <!-- Products -->

            <a
                href="../products/view.php"
                class="sidebar-link <?= str_contains($_SERVER['REQUEST_URI'], '/products/') ? 'active' : '' ?>"
            >

                <i
                    data-lucide="package"
                    class="w-4 h-4"
                ></i>

                Products

            </a>



            <!-- Stock In -->

            <a
                href="../stock_in/view.php"
                class="sidebar-link <?= str_contains($_SERVER['REQUEST_URI'], '/stock_in/') ? 'active' : '' ?>"
            >

                <i
                    data-lucide="arrow-down-to-line"
                    class="w-4 h-4"
                ></i>

                Stock In

            </a>



            <!-- Sales / Stock Out -->

            <a
                href="../stock_out/view.php"
                class="sidebar-link <?= str_contains($_SERVER['REQUEST_URI'], '/stock_out/') ? 'active' : '' ?>"
            >

                <i
                    data-lucide="shopping-cart"
                    class="w-4 h-4"
                ></i>

                Sales / Stock Out

            </a>



            <!-- Insights -->

            <div
                class="
                    text-[10px]
                    uppercase
                    tracking-[.18em]
                    text-slate-600
                    font-bold
                    px-2
                    pt-5
                    mb-2
                "
            >

                Insights

            </div>



            <!-- Reports -->

            <a
                href="../reports/report.php"
                class="sidebar-link <?= str_contains($_SERVER['REQUEST_URI'], '/reports/') ? 'active' : '' ?>"
            >

                <i
                    data-lucide="chart-no-axes-combined"
                    class="w-4 h-4"
                ></i>

                Reports

            </a>



            <!-- Users -->

            <a
                href="../users/view.php"
                class="sidebar-link <?= str_contains($_SERVER['REQUEST_URI'], '/users/') ? 'active' : '' ?>"
            >

                <i
                    data-lucide="users"
                    class="w-4 h-4"
                ></i>

                Users

            </a>

        </nav>

    </div>



    <!-- Bottom -->

    <div class="mt-auto p-4">

        <div
            class="
                rounded-2xl
                bg-gradient-to-br
                from-blue-600/20
                to-indigo-600/10
                border
                border-blue-500/10
                p-4
                mb-3
            "
        >

            <div class="text-xs text-blue-300 font-semibold">

                Inventory Pro

            </div>

            <div class="text-[11px] text-slate-500 mt-1">

                Smart stock management

            </div>

        </div>


        <!-- Logout -->

        <a
            href="../logout.php"
            class="
                sidebar-link
                bg-red-500/10
                hover:bg-red-500/15
                text-red-300
            "
        >

            <i
                data-lucide="log-out"
                class="w-4 h-4"
            ></i>

            Sign out

        </a>

    </div>

</aside>



<!-- Mobile Backdrop -->

<div
    id="backdrop"
    onclick="toggleSide()"
    class="
        mobile-backdrop
        fixed
        inset-0
        bg-slate-950/50
        z-40
        md:hidden
    "
></div>



<!-- Main -->

<div class="flex-1 min-w-0">


    <!-- Header -->

    <header
        class="
            sticky
            top-0
            z-30
            bg-white/85
            backdrop-blur-xl
            border-b
            border-slate-200/80
        "
    >

        <div
            class="
                px-4
                md:px-8
                py-4
                flex
                items-center
                justify-between
                gap-4
            "
        >

            <!-- Left -->

            <div class="flex items-center gap-3">


                <!-- Mobile Menu -->

                <button
                    class="
                        md:hidden
                        w-10 h-10
                        rounded-xl
                        bg-slate-100
                        flex
                        items-center
                        justify-center
                    "
                    onclick="toggleSide()"
                >

                    <i
                        data-lucide="menu"
                        class="w-5"
                    ></i>

                </button>


                <div>

                    <div
                        class="
                            font-extrabold
                            text-lg
                            tracking-tight
                        "
                    >

                        <?= htmlspecialchars($page_title) ?>

                    </div>

                    <div
                        class="
                            text-xs
                            text-slate-400
                        "
                    >

                        Inventory Pro / Control center

                    </div>

                </div>

            </div>



            <!-- Right -->

            <div class="flex items-center gap-3">


                <!-- Date -->

                <div
                    class="
                        hidden
                        sm:flex
                        items-center
                        gap-2
                        px-3
                        py-2
                        rounded-xl
                        bg-slate-50
                        border
                        border-slate-100
                        text-xs
                        text-slate-500
                    "
                >

                    <i
                        data-lucide="calendar-days"
                        class="w-4"
                    ></i>

                    <?= date('d M Y') ?>

                </div>


                <!-- User -->

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-gradient-to-br
                        from-blue-600
                        to-indigo-600
                        text-white
                        flex
                        items-center
                        justify-center
                        font-bold
                        shadow-lg
                    "
                >

                    <?= strtoupper(
                        substr(
                            $_SESSION['user_name'] ?? 'A',
                            0,
                            1
                        )
                    ) ?>

                </div>

            </div>

        </div>

    </header>



    <!-- Main Content -->

    <main
        class="
            p-4
            md:p-8
            max-w-[1600px]
            mx-auto
        "
    >


<script>

function toggleSide() {

    document
        .getElementById('sidebar')
        .classList
        .toggle('-translate-x-full');

    document
        .getElementById('backdrop')
        .classList
        .toggle('show');

}


document.addEventListener(
    'DOMContentLoaded',
    () => {

        if (window.lucide) {

            lucide.createIcons();

        }

    }
);

</script>