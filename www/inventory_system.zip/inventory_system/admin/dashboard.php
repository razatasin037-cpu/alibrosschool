<?php

require "../includes/auth.php";
require "../includes/connection.php";

$page_title = "Dashboard";

$products = $conn->query("
    SELECT COUNT(*) AS n
    FROM products
")->fetch_assoc()['n'];

$categories = $conn->query("
    SELECT COUNT(*) AS n
    FROM category
")->fetch_assoc()['n'];

$suppliers = $conn->query("
    SELECT COUNT(*) AS n
    FROM supplier
")->fetch_assoc()['n'];

$stock = $conn->query("
    SELECT COALESCE(SUM(stock), 0) AS n
    FROM products
")->fetch_assoc()['n'];

$low = $conn->query("
    SELECT COUNT(*) AS n
    FROM products
    WHERE stock <= 5
")->fetch_assoc()['n'];

$sales = $conn->query("
    SELECT COALESCE(
        SUM(so.quantity * p.price), 0
    ) AS n
    FROM stock_out so
    JOIN products p
        ON p.id = so.product_id
")->fetch_assoc()['n'];

$recent = $conn->query("
    SELECT
        so.*,
        p.product_name,
        p.price,
        (so.quantity * p.price) AS total
    FROM stock_out so
    JOIN products p
        ON p.id = so.product_id
    ORDER BY so.id DESC
    LIMIT 6
");

require "../includes/header.php";
require "../includes/sidebar.php";

?>

<div class="w-full">

    <div
        class="
            relative
            overflow-hidden
            rounded-[28px]
            bg-gradient-to-br
            from-slate-950
            via-blue-950
            to-indigo-900
            text-white
            p-6
            md:p-8
            mb-6
            shadow-xl
        "
    >

        <div
            class="
                absolute
                -right-16
                -top-20
                w-72
                h-72
                rounded-full
                bg-blue-500/20
                blur-3xl
            "
        ></div>

        <div
            class="
                absolute
                right-20
                -bottom-24
                w-64
                h-64
                rounded-full
                bg-indigo-400/20
                blur-3xl
            "
        ></div>


        <div
            class="
                relative
                flex
                flex-col
                lg:flex-row
                lg:items-center
                justify-between
                gap-7
            "
        >

            <div>

                <div
                    class="
                        inline-flex
                        items-center
                        gap-2
                        px-3
                        py-1.5
                        rounded-full
                        bg-white/10
                        border
                        border-white/10
                        text-blue-200
                        text-xs
                        font-bold
                        mb-4
                    "
                >

                    <span
                        class="
                            w-2
                            h-2
                            rounded-full
                            bg-emerald-400
                            shadow-[0_0_10px_rgba(52,211,153,.8)]
                        "
                    ></span>

                    SYSTEM ONLINE

                </div>


                <h1
                    class="
                        text-2xl
                        md:text-4xl
                        font-black
                        tracking-tight
                    "
                >

                    Good to see you,
                    <?= htmlspecialchars(
                        $_SESSION['user_name'] ?? 'Admin'
                    ) ?>.

                </h1>


                <p
                    class="
                        text-slate-300
                        mt-3
                        max-w-2xl
                        leading-relaxed
                    "
                >

                    Manage your inventory, products, suppliers,
                    stock and sales from one powerful workspace.

                </p>


                <div class="flex flex-wrap gap-3 mt-6">

                    <a
                        href="../products/add.php"
                        class="
                            btn
                            bg-white
                            text-slate-900
                            hover:bg-slate-100
                        "
                    >

                        <i
                            data-lucide="plus"
                            class="w-4"
                        ></i>

                        Add Product

                    </a>


                    <a
                        href="../stock_out/add.php"
                        class="
                            btn
                            bg-blue-500
                            hover:bg-blue-400
                            text-white
                        "
                    >

                        <i
                            data-lucide="shopping-cart"
                            class="w-4"
                        ></i>

                        New Sale

                    </a>

                </div>

            </div>


            <div class="hidden xl:block">

                <div
                    class="
                        w-44
                        h-44
                        rounded-[35px]
                        bg-white/5
                        border
                        border-white/10
                        backdrop-blur-xl
                        flex
                        items-center
                        justify-center
                        rotate-6
                    "
                >

                    <div
                        class="
                            w-28
                            h-28
                            rounded-[28px]
                            bg-gradient-to-br
                            from-blue-500
                            to-indigo-600
                            flex
                            items-center
                            justify-center
                            -rotate-6
                            shadow-2xl
                        "
                    >

                        <i
                            data-lucide="boxes"
                            class="w-14 h-14"
                        ></i>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div
        class="
            grid
            grid-cols-1
            sm:grid-cols-2
            xl:grid-cols-5
            gap-4
        "
    >

        <div class="card p-5 group hover:-translate-y-1 transition">

            <div class="flex items-center justify-between">

                <div
                    class="
                        w-11 h-11
                        rounded-2xl
                        bg-blue-50
                        text-blue-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i
                        data-lucide="package"
                        class="w-5"
                    ></i>

                </div>

                <span
                    class="
                        text-[11px]
                        font-bold
                        text-blue-500
                        bg-blue-50
                        px-2
                        py-1
                        rounded-lg
                    "
                >

                    PRODUCTS

                </span>

            </div>

            <div class="mt-5 text-sm text-slate-500 font-semibold">
                Total Products
            </div>

            <div class="text-3xl font-black mt-1">
                <?= number_format($products) ?>
            </div>

        </div>


        <div class="card p-5 group hover:-translate-y-1 transition">

            <div class="flex items-center justify-between">

                <div
                    class="
                        w-11 h-11
                        rounded-2xl
                        bg-violet-50
                        text-violet-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i
                        data-lucide="folder-kanban"
                        class="w-5"
                    ></i>

                </div>

                <span
                    class="
                        text-[11px]
                        font-bold
                        text-violet-500
                        bg-violet-50
                        px-2
                        py-1
                        rounded-lg
                    "
                >

                    CATEGORIES

                </span>

            </div>

            <div class="mt-5 text-sm text-slate-500 font-semibold">
                Categories
            </div>

            <div class="text-3xl font-black mt-1">
                <?= number_format($categories) ?>
            </div>

        </div>


        <div class="card p-5 group hover:-translate-y-1 transition">

            <div class="flex items-center justify-between">

                <div
                    class="
                        w-11 h-11
                        rounded-2xl
                        bg-emerald-50
                        text-emerald-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i
                        data-lucide="truck"
                        class="w-5"
                    ></i>

                </div>

                <span
                    class="
                        text-[11px]
                        font-bold
                        text-emerald-500
                        bg-emerald-50
                        px-2
                        py-1
                        rounded-lg
                    "
                >

                    SUPPLIERS

                </span>

            </div>

            <div class="mt-5 text-sm text-slate-500 font-semibold">
                Total Suppliers
            </div>

            <div class="text-3xl font-black mt-1">
                <?= number_format($suppliers) ?>
            </div>

        </div>


        <div class="card p-5 group hover:-translate-y-1 transition">

            <div class="flex items-center justify-between">

                <div
                    class="
                        w-11 h-11
                        rounded-2xl
                        bg-amber-50
                        text-amber-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i
                        data-lucide="boxes"
                        class="w-5"
                    ></i>

                </div>

                <span
                    class="
                        text-[11px]
                        font-bold
                        text-amber-600
                        bg-amber-50
                        px-2
                        py-1
                        rounded-lg
                    "
                >

                    STOCK

                </span>

            </div>

            <div class="mt-5 text-sm text-slate-500 font-semibold">
                Total Stock
            </div>

            <div class="text-3xl font-black mt-1">
                <?= number_format($stock) ?>
            </div>

        </div>


        <div class="card p-5 group hover:-translate-y-1 transition">

            <div class="flex items-center justify-between">

                <div
                    class="
                        w-11 h-11
                        rounded-2xl
                        bg-red-50
                        text-red-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i
                        data-lucide="triangle-alert"
                        class="w-5"
                    ></i>

                </div>

                <span
                    class="
                        text-[11px]
                        font-bold
                        text-red-500
                        bg-red-50
                        px-2
                        py-1
                        rounded-lg
                    "
                >

                    ALERT

                </span>

            </div>

            <div class="mt-5 text-sm text-slate-500 font-semibold">
                Low Stock
            </div>

            <div class="text-3xl font-black mt-1">
                <?= number_format($low) ?>
            </div>

        </div>

    </div>


    <div class="grid lg:grid-cols-3 gap-6 mt-6">

        <div class="card overflow-hidden lg:col-span-2">

            <div
                class="
                    p-6
                    border-b
                    border-slate-100
                    flex
                    items-center
                    justify-between
                "
            >

                <div>

                    <h2 class="font-extrabold text-lg">
                        Recent Sales
                    </h2>

                    <p class="text-xs text-slate-400 mt-1">
                        Latest stock-out transactions
                    </p>

                </div>


                <a
                    href="../stock_out/view.php"
                    class="
                        text-sm
                        text-blue-600
                        font-bold
                        hover:text-blue-700
                    "
                >

                    View all

                </a>

            </div>


            <div class="table-wrap">

                <table class="table">

                    <thead>

                        <tr>

                            <th>
                                Product
                            </th>

                            <th>
                                Qty
                            </th>

                            <th>
                                Amount
                            </th>

                            <th>
                                Date
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                        <?php if ($recent->num_rows > 0): ?>

                            <?php while (
                                $r = $recent->fetch_assoc()
                            ): ?>

                                <tr>

                                    <td>

                                        <div
                                            class="
                                                flex
                                                items-center
                                                gap-3
                                            "
                                        >

                                            <div
                                                class="
                                                    w-9 h-9
                                                    rounded-xl
                                                    bg-blue-50
                                                    text-blue-600
                                                    flex
                                                    items-center
                                                    justify-center
                                                "
                                            >

                                                <i
                                                    data-lucide="package"
                                                    class="w-4"
                                                ></i>

                                            </div>


                                            <span
                                                class="
                                                    font-semibold
                                                    text-slate-700
                                                "
                                            >

                                                <?= htmlspecialchars(
                                                    $r['product_name']
                                                ) ?>

                                            </span>

                                        </div>

                                    </td>


                                    <td>

                                        <span
                                            class="
                                                badge
                                                bg-orange-50
                                                text-orange-700
                                            "
                                        >

                                            <?= $r['quantity'] ?>

                                        </span>

                                    </td>


                                    <td>

                                        <span
                                            class="
                                                font-bold
                                                text-slate-800
                                            "
                                        >

                                            ₹<?= number_format(
                                                $r['total'],
                                                2
                                            ) ?>

                                        </span>

                                    </td>


                                    <td>

                                        <span class="text-slate-500">

                                            <?= date(
                                                'd M Y',
                                                strtotime($r['date'])
                                            ) ?>

                                        </span>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>

                                <td
                                    colspan="4"
                                    class="
                                        text-center
                                        py-10
                                        text-slate-400
                                    "
                                >

                                    No sales found.

                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>


        <div class="card p-6">

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-11 h-11
                        rounded-2xl
                        bg-emerald-50
                        text-emerald-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i
                        data-lucide="indian-rupee"
                        class="w-5"
                    ></i>

                </div>


                <div>

                    <div class="text-sm text-slate-500">
                        Total Sales Value
                    </div>

                    <div class="text-2xl font-black">
                        ₹<?= number_format(
                            $sales,
                            2
                        ) ?>
                    </div>

                </div>

            </div>


            <div
                class="
                    mt-7
                    p-5
                    rounded-2xl
                    bg-slate-50
                    border
                    border-slate-100
                "
            >

                <div
                    class="
                        flex
                        justify-between
                        text-xs
                        text-slate-500
                        mb-3
                    "
                >

                    <span>
                        Inventory health
                    </span>

                    <span
                        class="
                            font-bold
                            <?= $low == 0
                                ? 'text-emerald-600'
                                : 'text-amber-600' ?>
                        "
                    >

                        <?= $low == 0
                            ? 'Excellent'
                            : 'Needs attention' ?>

                    </span>

                </div>


                <div
                    class="
                        h-2
                        rounded-full
                        bg-slate-200
                        overflow-hidden
                    "
                >

                    <div
                        class="
                            h-full
                            rounded-full
                            <?= $low == 0
                                ? 'bg-emerald-500'
                                : 'bg-amber-500' ?>
                        "
                        style="
                            width:<?= max(
                                25,
                                100 - min(
                                    75,
                                    $low * 12
                                )
                            ) ?>%;
                        "
                    ></div>

                </div>

            </div>


            <div class="grid grid-cols-2 gap-3 mt-4">

                <a
                    href="../stock_in/add.php"
                    class="
                        btn
                        btn-soft
                    "
                >

                    <i
                        data-lucide="arrow-down-to-line"
                        class="w-4"
                    ></i>

                    Stock In

                </a>


                <a
                    href="../reports/report.php"
                    class="
                        btn
                        bg-slate-100
                        text-slate-700
                        hover:bg-slate-200
                    "
                >

                    <i
                        data-lucide="bar-chart-3"
                        class="w-4"
                    ></i>

                    Reports

                </a>

            </div>


            <div
                class="
                    mt-4
                    p-4
                    rounded-2xl
                    bg-blue-50
                    border
                    border-blue-100
                "
            >

                <div class="flex items-center gap-3">

                    <div
                        class="
                            w-9 h-9
                            rounded-xl
                            bg-blue-600
                            text-white
                            flex
                            items-center
                            justify-center
                        "
                    >

                        <i
                            data-lucide="zap"
                            class="w-4"
                        ></i>

                    </div>


                    <div>

                        <p
                            class="
                                text-sm
                                font-bold
                                text-blue-900
                            "
                        >

                            Quick Management

                        </p>

                        <p
                            class="
                                text-xs
                                text-blue-600
                                mt-0.5
                            "
                        >

                            Keep your inventory updated.

                        </p>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <div
        class="
            grid
            grid-cols-1
            sm:grid-cols-3
            gap-4
            mt-6
        "
    >

        <a
            href="../products/view.php"
            class="
                card
                p-5
                flex
                items-center
                justify-between
                group
                hover:border-blue-200
                transition
            "
        >

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-blue-50
                        text-blue-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i data-lucide="package" class="w-5"></i>

                </div>

                <div>

                    <p class="font-bold text-slate-800">
                        Products
                    </p>

                    <p class="text-xs text-slate-400">
                        Manage inventory
                    </p>

                </div>

            </div>


            <i
                data-lucide="arrow-up-right"
                class="
                    w-5
                    text-slate-300
                    group-hover:text-blue-600
                "
            ></i>

        </a>


        <a
            href="../supplier/view.php"
            class="
                card
                p-5
                flex
                items-center
                justify-between
                group
                hover:border-emerald-200
                transition
            "
        >

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-emerald-50
                        text-emerald-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i data-lucide="truck" class="w-5"></i>

                </div>

                <div>

                    <p class="font-bold text-slate-800">
                        Suppliers
                    </p>

                    <p class="text-xs text-slate-400">
                        Manage suppliers
                    </p>

                </div>

            </div>


            <i
                data-lucide="arrow-up-right"
                class="
                    w-5
                    text-slate-300
                    group-hover:text-emerald-600
                "
            ></i>

        </a>


        <a
            href="../stock_out/view.php"
            class="
                card
                p-5
                flex
                items-center
                justify-between
                group
                hover:border-orange-200
                transition
            "
        >

            <div class="flex items-center gap-3">

                <div
                    class="
                        w-10 h-10
                        rounded-xl
                        bg-orange-50
                        text-orange-600
                        flex
                        items-center
                        justify-center
                    "
                >

                    <i
                        data-lucide="receipt"
                        class="w-5"
                    ></i>

                </div>

                <div>

                    <p class="font-bold text-slate-800">
                        Sales
                    </p>

                    <p class="text-xs text-slate-400">
                        View transactions
                    </p>

                </div>

            </div>


            <i
                data-lucide="arrow-up-right"
                class="
                    w-5
                    text-slate-300
                    group-hover:text-orange-600
                "
            ></i>

        </a>

    </div>

</div>


<?php

require "../includes/footer.php";

?>