<?php

date_default_timezone_set('Asia/Kolkata');

require_once 'includes/auth.php';
require_once 'config/db.php';

$page_title = 'Add Customer';

$error = '';


/* =====================================================
   FORM SUBMIT
===================================================== */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');

    $phone = trim($_POST['phone'] ?? '');

    $aadhaar = trim($_POST['aadhaar_no'] ?? '');

    $opening_date = trim(
        $_POST['opening_date'] ?? ''
    );

    $plan = trim(
        $_POST['plan'] ?? ''
    );

    $amount = (float)(
        $_POST['amount'] ?? 0
    );


    /* =================================================
       VALIDATION
    ================================================= */

    if ($name === '') {

        $error = 'Customer name is required.';

    } elseif ($phone === '') {

        $error = 'Mobile number is required.';

    } elseif ($opening_date === '') {

        $error = 'Opening date is required.';

    } elseif (
        $plan !== 'Monthly' &&
        $plan !== 'Weekly'
    ) {

        $error = 'Please select a valid payment plan.';

    } elseif ($amount <= 0) {

        $error = 'Amount must be greater than 0.';

    } else {


        /* =============================================
           DATE
        ============================================= */

        $openingObj =
            DateTime::createFromFormat(
                '!Y-m-d',
                $opening_date,
                new DateTimeZone('Asia/Kolkata')
            );


        if (!$openingObj) {

            $error = 'Invalid opening date.';

        } else {


            $today =
                new DateTime(
                    'today',
                    new DateTimeZone('Asia/Kolkata')
                );


            if ($openingObj > $today) {

                $error =
                    'Opening date cannot be in the future.';

            } else {


                /* =====================================
                   PLAN
                ===================================== */

                if ($plan === 'Monthly') {

                    $totalInstallments = 12;

                    $day =
                        (int)$openingObj->format('d');


                    if ($day <= 10) {

                        $nextDue =
                            new DateTime(
                                $openingObj->format('Y-m-10'),
                                new DateTimeZone(
                                    'Asia/Kolkata'
                                )
                            );

                    } else {

                        $nextDue =
                            new DateTime(
                                $openingObj->format('Y-m-01'),
                                new DateTimeZone(
                                    'Asia/Kolkata'
                                )
                            );

                        $nextDue->modify('+1 month');

                        $nextDue->setDate(
                            (int)$nextDue->format('Y'),
                            (int)$nextDue->format('m'),
                            10
                        );
                    }

                } else {

                    $totalInstallments = 52;

                    $nextDue =
                        clone $openingObj;

                    $nextDue->modify('+7 days');
                }


                $nextDueDate =
                    $nextDue->format('Y-m-d');


                /* =====================================
                   INSERT
                ===================================== */

                $stmt = $conn->prepare("
                    INSERT INTO customers
                    (
                        name,
                        phone,
                        aadhaar_no,
                        opening_date,
                        plan,
                        amount,
                        total_installments,
                        paid_installments,
                        next_due_date,
                        status
                    )
                    VALUES
                    (
                        ?, ?, ?, ?, ?, ?,
                        ?, 0, ?, 'Active'
                    )
                ");


                $stmt->bind_param(
                    "sssssdis",
                    $name,
                    $phone,
                    $aadhaar,
                    $opening_date,
                    $plan,
                    $amount,
                    $totalInstallments,
                    $nextDueDate
                );


                if ($stmt->execute()) {

                    $newCustomerId =
                        $conn->insert_id;


                    header(
                        'Location: payment.php?id='
                        . $newCustomerId
                        . '&new=1'
                    );

                    exit;

                } else {

                    $error =
                        'Customer could not be added.';
                }

            }
        }
    }
}


include 'includes/header.php';

?>


<!-- =====================================================
     PAGE
===================================================== -->

<div class="add-customer-page">


    <!-- =================================================
         TOP HEADER
    ================================================== -->

    <div class="add-page-header">

        <div>

            <div class="page-kicker">

                <i class="bi bi-people-fill"></i>

                CUSTOMER MANAGEMENT

            </div>


            <h2>

                Add New Customer

            </h2>


            <p>

                Create a customer profile and assign
                a payment plan.

            </p>

        </div>


        <a
            href="customers.php"
            class="back-btn"
        >

            <i class="bi bi-arrow-left"></i>

            Back to Customers

        </a>

    </div>


    <!-- =================================================
         ERROR
    ================================================== -->

    <?php if ($error !== ''): ?>

    <div class="custom-alert">

        <div class="alert-icon">

            <i
                class="bi
                bi-exclamation-triangle-fill"
            ></i>

        </div>


        <div>

            <strong>
                Unable to add customer
            </strong>

            <div>
                <?= htmlspecialchars($error) ?>
            </div>

        </div>

    </div>

    <?php endif; ?>


    <!-- =================================================
         MAIN GRID
    ================================================== -->

    <div class="add-grid">


        <!-- =============================================
             FORM CARD
        ============================================== -->

        <div class="form-card">


            <!-- CARD HEADER -->

            <div class="form-card-header">

                <div class="header-icon">

                    <i class="bi bi-person-vcard-fill"></i>

                </div>


                <div>

                    <h5>
                        Customer Information
                    </h5>

                    <p>
                        Enter the customer's basic details.
                    </p>

                </div>

            </div>


            <form
                method="POST"
                id="customerForm"
            >


                <!-- =====================================
                     PERSONAL INFORMATION
                ====================================== -->

                <div class="section-title">

                    <span>01</span>

                    Personal Details

                </div>


                <!-- NAME -->

                <div class="field-group">

                    <label>

                        Customer Name

                        <b>*</b>

                    </label>


                    <div class="input-wrap">

                        <i class="bi bi-person"></i>


                        <input
                            type="text"
                            name="name"
                            placeholder="Enter full name"
                            value="<?= htmlspecialchars(
                                $_POST['name'] ?? ''
                            ) ?>"
                            required
                        >

                    </div>

                </div>


                <!-- MOBILE + AADHAAR -->

                <div class="two-column">


                    <div class="field-group">

                        <label>

                            Mobile Number

                            <b>*</b>

                        </label>


                        <div class="input-wrap">

                            <i class="bi bi-phone"></i>


                            <input
                                type="tel"
                                name="phone"
                                placeholder="10 digit mobile number"
                                maxlength="20"
                                value="<?= htmlspecialchars(
                                    $_POST['phone'] ?? ''
                                ) ?>"
                                required
                            >

                        </div>

                    </div>


                    <div class="field-group">

                        <label>

                            Aadhaar Number

                        </label>


                        <div class="input-wrap">

                            <i class="bi bi-person-vcard"></i>


                            <input
                                type="text"
                                name="aadhaar_no"
                                placeholder="Enter Aadhaar number"
                                maxlength="20"
                                value="<?= htmlspecialchars(
                                    $_POST['aadhaar_no'] ?? ''
                                ) ?>"
                            >

                        </div>

                    </div>


                </div>


                <!-- =====================================
                     ACCOUNT DETAILS
                ====================================== -->

                <div class="section-title mt-section">

                    <span>02</span>

                    Account Details

                </div>


                <!-- OPENING DATE -->

                <div class="field-group">

                    <label>

                        Opening Date

                        <b>*</b>

                    </label>


                    <div class="input-wrap">

                        <i class="bi bi-calendar3"></i>


                        <input
                            type="date"
                            name="opening_date"
                            value="<?= htmlspecialchars(
                                $_POST['opening_date']
                                ?? date('Y-m-d')
                            ) ?>"
                            max="<?= date('Y-m-d') ?>"
                            required
                        >

                    </div>


                    <small>

                        The date when the customer's
                        plan starts.

                    </small>

                </div>


                <!-- =====================================
                     PAYMENT PLAN
                ====================================== -->

                <div class="section-title mt-section">

                    <span>03</span>

                    Payment Plan

                </div>


                <div class="plan-grid">


                    <!-- MONTHLY -->

                    <label class="plan-label">

                        <input
                            type="radio"
                            name="plan"
                            value="Monthly"
                            class="plan-radio"
                            <?= (
                                ($_POST['plan']
                                ?? 'Monthly')
                                === 'Monthly'
                            )
                            ? 'checked'
                            : ''
                            ?>
                        >


                        <div class="plan-card">

                            <div class="plan-top">

                                <div class="plan-icon monthly">

                                    <i
                                        class="bi
                                        bi-calendar-month"
                                    ></i>

                                </div>


                                <div
                                    class="check-circle"
                                >

                                    <i
                                        class="bi
                                        bi-check"
                                    ></i>

                                </div>

                            </div>


                            <h6>

                                Monthly

                            </h6>


                            <p>

                                Pay once every month

                            </p>


                            <div class="plan-bottom">

                                <span>

                                    Duration

                                </span>

                                <strong>

                                    12 Months

                                </strong>

                            </div>

                        </div>

                    </label>


                    <!-- WEEKLY -->

                    <label class="plan-label">

                        <input
                            type="radio"
                            name="plan"
                            value="Weekly"
                            class="plan-radio"
                            <?= (
                                ($_POST['plan']
                                ?? '')
                                === 'Weekly'
                            )
                            ? 'checked'
                            : ''
                            ?>
                        >


                        <div class="plan-card">

                            <div class="plan-top">

                                <div class="plan-icon weekly">

                                    <i
                                        class="bi
                                        bi-calendar-week"
                                    ></i>

                                </div>


                                <div
                                    class="check-circle"
                                >

                                    <i
                                        class="bi
                                        bi-check"
                                    ></i>

                                </div>

                            </div>


                            <h6>

                                Weekly

                            </h6>


                            <p>

                                Pay once every week

                            </p>


                            <div class="plan-bottom">

                                <span>

                                    Duration

                                </span>

                                <strong>

                                    52 Weeks

                                </strong>

                            </div>

                        </div>

                    </label>


                </div>


                <!-- =====================================
                     AMOUNT
                ====================================== -->

                <div class="amount-section">


                    <div class="field-group">

                        <label id="amountLabel">

                            Monthly Amount

                            <b>*</b>

                        </label>


                        <div class="amount-input">

                            <span>₹</span>


                            <input
                                type="number"
                                name="amount"
                                id="amount"
                                placeholder="0.00"
                                min="1"
                                step="0.01"
                                value="<?= htmlspecialchars(
                                    $_POST['amount'] ?? ''
                                ) ?>"
                                required
                            >

                        </div>


                        <small
                            id="amountHelp"
                        >

                            Customer will pay this
                            amount every month.

                        </small>

                    </div>


                </div>


                <!-- =====================================
                     BUTTONS
                ====================================== -->

                <div class="form-actions">


                    <a
                        href="customers.php"
                        class="cancel-btn"
                    >

                        Cancel

                    </a>


                    <button
                        type="submit"
                        class="save-btn"
                    >

                        <i
                            class="bi
                            bi-person-plus-fill"
                        ></i>

                        Add Customer

                    </button>

                </div>


            </form>

        </div>


        <!-- =============================================
             RIGHT SUMMARY
        ============================================== -->

        <div class="summary-column">


            <!-- PLAN SUMMARY -->

            <div class="summary-card">


                <div class="summary-header">

                    <div>

                        <span>
                            PLAN PREVIEW
                        </span>

                        <h5>
                            Your Plan
                        </h5>

                    </div>


                    <div class="summary-bank-icon">

                        <i class="bi bi-bank2"></i>

                    </div>

                </div>


                <div class="selected-plan-box">


                    <div class="selected-icon">

                        <i
                            class="bi
                            bi-calendar-month"
                            id="summaryIcon"
                        ></i>

                    </div>


                    <div>

                        <small>
                            Selected Plan
                        </small>

                        <h4
                            id="previewPlan"
                        >
                            Monthly
                        </h4>

                    </div>

                </div>


                <!-- DURATION -->

                <div class="summary-row">

                    <div>

                        <i
                            class="bi
                            bi-hourglass-split"
                        ></i>

                        Duration

                    </div>


                    <strong
                        id="previewDuration"
                    >

                        12 Months

                    </strong>

                </div>


                <!-- AMOUNT -->

                <div class="summary-row">

                    <div>

                        <i
                            class="bi
                            bi-cash-stack"
                        ></i>

                        Payment

                    </div>


                    <strong
                        id="previewAmount"
                    >

                        ₹0.00

                    </strong>

                </div>


                <div class="summary-divider"></div>


                <!-- INFO -->

                <div class="summary-info">

                    <i class="bi bi-info-circle"></i>


                    <span id="summaryText">

                        Customer will make
                        12 monthly payments.

                    </span>

                </div>

            </div>


            <!-- SECURITY CARD -->

            <div class="security-card">

                <div class="security-icon">

                    <i
                        class="bi
                        bi-shield-check"
                    ></i>

                </div>


                <div>

                    <h6>
                        Secure Customer Data
                    </h6>

                    <p>

                        Customer information is
                        stored securely in the
                        banking system.

                    </p>

                </div>

            </div>


            <!-- QUICK INFO -->

            <div class="quick-card">

                <div class="quick-title">

                    <i
                        class="bi
                        bi-lightning-charge-fill"
                    ></i>

                    Quick Info

                </div>


                <div class="quick-item">

                    <span>
                        Monthly Plan
                    </span>

                    <strong>
                        12 Payments
                    </strong>

                </div>


                <div class="quick-item">

                    <span>
                        Weekly Plan
                    </span>

                    <strong>
                        52 Payments
                    </strong>

                </div>


                <div class="quick-item">

                    <span>
                        Status
                    </span>

                    <strong class="active-text">

                        Active

                    </strong>

                </div>

            </div>


        </div>


    </div>

</div>


<style>

/* =====================================================
   ADD CUSTOMER PAGE
===================================================== */

.add-customer-page{

    width:100%;

}


/* =====================================================
   HEADER
===================================================== */

.add-page-header{

    display:flex;

    justify-content:space-between;

    align-items:center;

    gap:20px;

    margin-bottom:26px;

}


.page-kicker{

    color:#15803d;

    font-size:11px;

    font-weight:800;

    letter-spacing:1.4px;

    margin-bottom:6px;

}


.page-kicker i{

    margin-right:5px;

}


.add-page-header h2{

    margin:0;

    font-size:28px;

    font-weight:800;

    color:#0b120e;

}


.add-page-header p{

    margin:5px 0 0;

    color:#6b756e;

    font-size:14px;

}


.back-btn{

    display:inline-flex;

    align-items:center;

    gap:8px;

    padding:11px 16px;

    border-radius:11px;

    border:1px solid #dfe6e1;

    background:#fff;

    color:#34423a;

    text-decoration:none;

    font-size:13px;

    font-weight:600;

    transition:.2s;

}


.back-btn:hover{

    border-color:#86efac;

    color:#15803d;

    background:#f0fdf4;

}


/* =====================================================
   ALERT
===================================================== */

.custom-alert{

    display:flex;

    align-items:center;

    gap:14px;

    background:#fff1f2;

    border:1px solid #fecdd3;

    color:#991b1b;

    padding:14px 16px;

    border-radius:14px;

    margin-bottom:22px;

}


.alert-icon{

    width:40px;

    height:40px;

    border-radius:11px;

    display:flex;

    align-items:center;

    justify-content:center;

    background:#fee2e2;

}


/* =====================================================
   MAIN GRID
===================================================== */

.add-grid{

    display:grid;

    grid-template-columns:
        minmax(0, 1fr)
        340px;

    gap:22px;

    align-items:start;

}


/* =====================================================
   FORM CARD
===================================================== */

.form-card{

    background:#fff;

    border:1px solid #e5ebe7;

    border-radius:22px;

    box-shadow:
        0 12px 35px
        rgba(9,18,12,.055);

    padding:28px;

}


.form-card-header{

    display:flex;

    align-items:center;

    gap:14px;

    padding-bottom:22px;

    margin-bottom:24px;

    border-bottom:1px solid #edf1ee;

}


.header-icon{

    width:48px;

    height:48px;

    border-radius:14px;

    display:flex;

    align-items:center;

    justify-content:center;

    background:#eaf8ef;

    color:#16a34a;

    font-size:21px;

}


.form-card-header h5{

    margin:0;

    font-size:17px;

    font-weight:800;

}


.form-card-header p{

    margin:4px 0 0;

    color:#7a857e;

    font-size:12px;

}


/* =====================================================
   SECTION TITLE
===================================================== */

.section-title{

    display:flex;

    align-items:center;

    gap:9px;

    color:#111b15;

    font-size:13px;

    font-weight:800;

    margin-bottom:16px;

}


.section-title span{

    width:27px;

    height:27px;

    border-radius:8px;

    display:flex;

    align-items:center;

    justify-content:center;

    background:#020b07;

    color:#fff;

    font-size:10px;

}


.mt-section{

    margin-top:28px;

}


/* =====================================================
   FIELD
===================================================== */

.field-group{

    margin-bottom:18px;

}


.field-group label{

    display:block;

    margin-bottom:8px;

    color:#26332b;

    font-size:12px;

    font-weight:700;

}


.field-group label b{

    color:#dc2626;

}


.field-group small{

    display:block;

    margin-top:7px;

    color:#7a857e;

    font-size:11px;

}


.input-wrap{

    height:48px;

    display:flex;

    align-items:center;

    border:1px solid #dfe6e1;

    border-radius:12px;

    background:#fff;

    transition:.2s;

}


.input-wrap:focus-within{

    border-color:#4ade80;

    box-shadow:
        0 0 0 4px
        rgba(
            34,
            197,
            94,
            .09
        );

}


.input-wrap i{

    width:45px;

    text-align:center;

    color:#7a857e;

    font-size:16px;

}


.input-wrap input{

    width:100%;

    height:100%;

    border:0;

    outline:0;

    padding:0 12px 0 0;

    background:transparent;

    color:#101713;

    font-size:13px;

}


.input-wrap input::placeholder{

    color:#a4ada7;

}


/* =====================================================
   TWO COLUMN
===================================================== */

.two-column{

    display:grid;

    grid-template-columns:
        1fr 1fr;

    gap:16px;

}


/* =====================================================
   PLAN GRID
===================================================== */

.plan-grid{

    display:grid;

    grid-template-columns:
        1fr 1fr;

    gap:14px;

}


.plan-label{

    display:block;

    cursor:pointer;

    margin:0;

}


.plan-radio{

    position:absolute;

    opacity:0;

}


.plan-card{

    border:1px solid #dfe6e1;

    border-radius:16px;

    padding:18px;

    transition:.2s;

    background:#fff;

}


.plan-card:hover{

    border-color:#86efac;

    transform:translateY(-2px);

    box-shadow:
        0 8px 20px
        rgba(
            22,
            163,
            74,
            .08
        );

}


.plan-radio:checked + .plan-card{

    border-color:#16a34a;

    background:#f0fdf4;

    box-shadow:
        0 0 0 3px
        rgba(
            34,
            197,
            94,
            .10
        );

}


.plan-top{

    display:flex;

    align-items:center;

    justify-content:space-between;

}


.plan-icon{

    width:42px;

    height:42px;

    border-radius:12px;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:18px;

}


.plan-icon.monthly{

    background:#dcfce7;

    color:#15803d;

}


.plan-icon.weekly{

    background:#ecfdf5;

    color:#047857;

}


.check-circle{

    width:22px;

    height:22px;

    border-radius:50%;

    border:1px solid #d1d9d4;

    display:flex;

    align-items:center;

    justify-content:center;

    color:transparent;

    font-size:12px;

}


.plan-radio:checked + .plan-card
.check-circle{

    background:#16a34a;

    border-color:#16a34a;

    color:#fff;

}


.plan-card h6{

    margin:15px 0 4px;

    font-size:15px;

    font-weight:800;

}


.plan-card p{

    margin:0;

    color:#7a857e;

    font-size:11px;

}


.plan-bottom{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-top:16px;

    padding-top:12px;

    border-top:1px solid #edf1ee;

}


.plan-bottom span{

    color:#7a857e;

    font-size:11px;

}


.plan-bottom strong{

    color:#15803d;

    font-size:12px;

}


/* =====================================================
   AMOUNT
===================================================== */

.amount-section{

    margin-top:22px;

    padding:18px;

    border-radius:16px;

    background:#f8faf9;

    border:1px solid #e7ede9;

}


.amount-input{

    height:58px;

    display:flex;

    align-items:center;

    background:#fff;

    border:1px solid #dfe6e1;

    border-radius:13px;

    overflow:hidden;

    transition:.2s;

}


.amount-input:focus-within{

    border-color:#4ade80;

    box-shadow:
        0 0 0 4px
        rgba(
            34,
            197,
            94,
            .09
        );

}


.amount-input span{

    width:55px;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:21px;

    font-weight:800;

    color:#15803d;

    border-right:1px solid #edf1ee;

}


.amount-input input{

    width:100%;

    height:100%;

    border:0;

    outline:0;

    padding:0 16px;

    font-size:20px;

    font-weight:700;

    color:#111b15;

}


.amount-input input::placeholder{

    color:#b3bbb6;

}


/* =====================================================
   ACTIONS
===================================================== */

.form-actions{

    display:flex;

    justify-content:flex-end;

    gap:10px;

    margin-top:26px;

    padding-top:20px;

    border-top:1px solid #edf1ee;

}


.cancel-btn{

    display:inline-flex;

    align-items:center;

    justify-content:center;

    padding:11px 20px;

    border-radius:11px;

    border:1px solid #dfe6e1;

    background:#fff;

    color:#46534b;

    text-decoration:none;

    font-size:13px;

    font-weight:700;

}


.save-btn{

    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:8px;

    padding:11px 22px;

    border:0;

    border-radius:11px;

    background:
        linear-gradient(
            135deg,
            #15803d,
            #22c55e
        );

    color:#fff;

    font-size:13px;

    font-weight:700;

    box-shadow:
        0 8px 18px
        rgba(
            22,
            163,
            74,
            .18
        );

    cursor:pointer;

}


.save-btn:hover{

    background:
        linear-gradient(
            135deg,
            #166534,
            #16a34a
        );

}


/* =====================================================
   SUMMARY
===================================================== */

.summary-column{

    display:flex;

    flex-direction:column;

    gap:16px;

}


.summary-card{

    background:
        linear-gradient(
            145deg,
            #050806,
            #0d1b12
        );

    color:#fff;

    border-radius:22px;

    padding:22px;

    box-shadow:
        0 15px 35px
        rgba(
            5,
            8,
            6,
            .18
        );

    position:relative;

    overflow:hidden;

}


.summary-card::after{

    content:"";

    position:absolute;

    width:190px;

    height:190px;

    right:-100px;

    top:-90px;

    border-radius:50%;

    background:
        rgba(
            34,
            197,
            94,
            .10
        );

}


.summary-header{

    display:flex;

    align-items:center;

    justify-content:space-between;

    position:relative;

    z-index:1;

}


.summary-header span{

    color:#86efac;

    font-size:9px;

    font-weight:800;

    letter-spacing:1.4px;

}


.summary-header h5{

    margin:4px 0 0;

    font-size:17px;

    font-weight:800;

}


.summary-bank-icon{

    width:40px;

    height:40px;

    border-radius:12px;

    display:flex;

    align-items:center;

    justify-content:center;

    background:
        rgba(
            34,
            197,
            94,
            .14
        );

    color:#4ade80;

}


/* =====================================================
   SELECTED PLAN
===================================================== */

.selected-plan-box{

    display:flex;

    align-items:center;

    gap:12px;

    padding:15px;

    margin-top:22px;

    border-radius:15px;

    background:
        rgba(
            255,
            255,
            255,
            .055
        );

    border:
        1px solid
        rgba(
            255,
            255,
            255,
            .07
        );

    position:relative;

    z-index:1;

}


.selected-icon{

    width:43px;

    height:43px;

    border-radius:12px;

    display:flex;

    align-items:center;

    justify-content:center;

    background:#16a34a;

    color:#fff;

}


.selected-plan-box small{

    color:#94a3b8;

    font-size:10px;

}


.selected-plan-box h4{

    margin:2px 0 0;

    font-size:17px;

    font-weight:800;

}


/* =====================================================
   SUMMARY ROW
===================================================== */

.summary-row{

    display:flex;

    justify-content:space-between;

    align-items:center;

    padding:15px 0;

    border-bottom:
        1px solid
        rgba(
            255,
            255,
            255,
            .07
        );

    position:relative;

    z-index:1;

}


.summary-row div{

    color:#94a3b8;

    font-size:12px;

}


.summary-row i{

    margin-right:7px;

    color:#4ade80;

}


.summary-row strong{

    color:#fff;

    font-size:13px;

}


.summary-divider{

    height:1px;

    background:
        rgba(
            255,
            255,
            255,
            .07
        );

}


/* =====================================================
   SUMMARY INFO
===================================================== */

.summary-info{

    display:flex;

    gap:9px;

    margin-top:16px;

    color:#a7b4ab;

    font-size:11px;

    line-height:1.6;

    position:relative;

    z-index:1;

}


.summary-info i{

    color:#4ade80;

    margin-top:2px;

}


/* =====================================================
   SECURITY
===================================================== */

.security-card{

    display:flex;

    gap:12px;

    padding:17px;

    border-radius:17px;

    background:#fff;

    border:1px solid #e5ebe7;

}


.security-icon{

    width:40px;

    height:40px;

    border-radius:11px;

    display:flex;

    align-items:center;

    justify-content:center;

    background:#dcfce7;

    color:#15803d;

    flex-shrink:0;

}


.security-card h6{

    margin:0 0 4px;

    font-size:13px;

    font-weight:800;

}


.security-card p{

    margin:0;

    color:#7a857e;

    font-size:10px;

    line-height:1.5;

}


/* =====================================================
   QUICK CARD
===================================================== */

.quick-card{

    padding:18px;

    border-radius:17px;

    background:#fff;

    border:1px solid #e5ebe7;

}


.quick-title{

    display:flex;

    align-items:center;

    gap:7px;

    font-size:13px;

    font-weight:800;

    margin-bottom:13px;

}


.quick-title i{

    color:#16a34a;

}


.quick-item{

    display:flex;

    justify-content:space-between;

    align-items:center;

    padding:10px 0;

    border-bottom:1px solid #edf1ee;

}


.quick-item:last-child{

    border-bottom:0;

}


.quick-item span{

    color:#7a857e;

    font-size:11px;

}


.quick-item strong{

    color:#26332b;

    font-size:11px;

}


.active-text{

    color:#15803d !important;

}


/* =====================================================
   RESPONSIVE
===================================================== */

@media(max-width:1100px){

    .add-grid{

        grid-template-columns:
            minmax(0, 1fr)
            300px;

    }

}


@media(max-width:991px){

    .add-grid{

        grid-template-columns:1fr;

    }


    .summary-column{

        display:grid;

        grid-template-columns:
            1fr 1fr;

        align-items:start;

    }


    .summary-card{

        grid-column:
            span 2;

    }

}


@media(max-width:700px){

    .add-page-header{

        align-items:flex-start;

        flex-direction:column;

    }


    .two-column{

        grid-template-columns:1fr;

        gap:0;

    }


    .plan-grid{

        grid-template-columns:1fr;

    }


    .summary-column{

        display:flex;

    }


    .form-card{

        padding:20px;

        border-radius:18px;

    }


    .add-page-header h2{

        font-size:23px;

    }

}


@media(max-width:480px){

    .form-actions{

        flex-direction:column-reverse;

    }


    .cancel-btn,
    .save-btn{

        width:100%;

    }

}

</style>


<script>

/* =====================================================
   PLAN + AMOUNT
===================================================== */

document.addEventListener(
    'DOMContentLoaded',
    function(){

        const radios =
            document.querySelectorAll(
                '.plan-radio'
            );


        const amount =
            document.getElementById(
                'amount'
            );


        const amountLabel =
            document.getElementById(
                'amountLabel'
            );


        const amountHelp =
            document.getElementById(
                'amountHelp'
            );


        const previewPlan =
            document.getElementById(
                'previewPlan'
            );


        const previewDuration =
            document.getElementById(
                'previewDuration'
            );


        const previewAmount =
            document.getElementById(
                'previewAmount'
            );


        const summaryIcon =
            document.getElementById(
                'summaryIcon'
            );


        const summaryText =
            document.getElementById(
                'summaryText'
            );


        function updateAmount(){

            const value =
                parseFloat(
                    amount.value
                ) || 0;


            previewAmount.textContent =
                '₹' +
                value.toLocaleString(
                    'en-IN',
                    {
                        minimumFractionDigits:2,
                        maximumFractionDigits:2
                    }
                );

        }


        function updatePlan(){

            const selected =
                document.querySelector(
                    '.plan-radio:checked'
                );


            if(!selected){

                return;

            }


            if(
                selected.value
                ===
                'Weekly'
            ){

                amountLabel.innerHTML =
                    'Weekly Amount ' +
                    '<b>*</b>';


                amountHelp.textContent =
                    'Customer will pay this amount every week.';


                previewPlan.textContent =
                    'Weekly';


                previewDuration.textContent =
                    '52 Weeks';


                summaryIcon.className =
                    'bi bi-calendar-week';


                summaryText.textContent =
                    'Customer will make 52 weekly payments.';

            }
            else{

                amountLabel.innerHTML =
                    'Monthly Amount ' +
                    '<b>*</b>';


                amountHelp.textContent =
                    'Customer will pay this amount every month.';


                previewPlan.textContent =
                    'Monthly';


                previewDuration.textContent =
                    '12 Months';


                summaryIcon.className =
                    'bi bi-calendar-month';


                summaryText.textContent =
                    'Customer will make 12 monthly payments.';

            }


            updateAmount();

        }


        radios.forEach(
            function(radio){

                radio.addEventListener(
                    'change',
                    updatePlan
                );

            }
        );


        amount.addEventListener(
            'input',
            updateAmount
        );


        updatePlan();

        updateAmount();

    }
);

</script>


<?php

include 'includes/footer.php';

?>