<?php

date_default_timezone_set('Asia/Kolkata');

require_once 'includes/auth.php';
require_once 'config/db.php';

$page_title = 'Customers';


/* =====================================================
   SEARCH + PLAN FILTER
===================================================== */

$search = trim($_GET['search'] ?? '');

$plan = $_GET['plan'] ?? 'All';

if (
    $plan !== 'All' &&
    $plan !== 'Monthly' &&
    $plan !== 'Weekly'
) {
    $plan = 'All';
}


/* =====================================================
   CUSTOMER QUERY
===================================================== */

$where = [];
$params = [];
$types = '';


/* PLAN FILTER */

if ($plan !== 'All') {

    $where[] = "c.plan = ?";

    $params[] = $plan;

    $types .= 's';
}


/* SEARCH FILTER */

if ($search !== '') {

    $where[] = "
        (
            c.name LIKE ?
            OR c.phone LIKE ?
            OR c.aadhaar_no LIKE ?
        )
    ";

    $searchLike = '%' . $search . '%';

    $params[] = $searchLike;
    $params[] = $searchLike;
    $params[] = $searchLike;

    $types .= 'sss';
}


/* WHERE */

$whereSQL = '';

if (!empty($where)) {

    $whereSQL =
        'WHERE ' .
        implode(
            ' AND ',
            $where
        );
}


/* =====================================================
   MAIN QUERY
===================================================== */

$sql = "
    SELECT
        c.*,

        COALESCE(
            (
                SELECT SUM(ip.amount)
                FROM installment_payments ip
                WHERE ip.customer_id = c.id
            ),
            0
        ) AS total_paid

    FROM customers c

    $whereSQL

    ORDER BY c.id DESC
";


$stmt = $conn->prepare($sql);


if (!empty($params)) {

    $stmt->bind_param(
        $types,
        ...$params
    );
}


$stmt->execute();

$customers =
    $stmt->get_result();


/* =====================================================
   SUMMARY
===================================================== */

$totalCustomers = (int)$conn->query("
    SELECT COUNT(*) AS total
    FROM customers
")->fetch_assoc()['total'];


$activeCustomers = (int)$conn->query("
    SELECT COUNT(*) AS total
    FROM customers
    WHERE status = 'Active'
")->fetch_assoc()['total'];


$completedCustomers = (int)$conn->query("
    SELECT COUNT(*) AS total
    FROM customers
    WHERE status = 'Completed'
")->fetch_assoc()['total'];


$monthlyCustomers = (int)$conn->query("
    SELECT COUNT(*) AS total
    FROM customers
    WHERE plan = 'Monthly'
")->fetch_assoc()['total'];


$weeklyCustomers = (int)$conn->query("
    SELECT COUNT(*) AS total
    FROM customers
    WHERE plan = 'Weekly'
")->fetch_assoc()['total'];


include 'includes/header.php';

?>


<!-- =====================================================
     SUCCESS MESSAGE
===================================================== -->

<?php if (isset($_GET['deleted'])): ?>

<div
    class="alert
    alert-success
    alert-dismissible
    fade show"
>

    <i
        class="bi
        bi-check-circle-fill
        me-2"
    ></i>

    Customer aur uski saari collection
    successfully delete ho gayi.

    <button
        type="button"
        class="btn-close"
        data-bs-dismiss="alert"
    ></button>

</div>

<?php endif; ?>


<!-- =====================================================
     ERROR MESSAGE
===================================================== -->

<?php if (isset($_GET['error'])): ?>

<div
    class="alert
    alert-danger
    alert-dismissible
    fade show"
>

    <i
        class="bi
        bi-exclamation-triangle-fill
        me-2"
    ></i>

    <?php

    if (
        $_GET['error']
        ===
        'not_found'
    ) {

        echo 'Customer nahi mila.';

    } elseif (
        $_GET['error']
        ===
        'invalid_id'
    ) {

        echo 'Invalid customer ID.';

    } else {

        echo 'Customer delete nahi ho saka.';

    }

    ?>

    <button
        type="button"
        class="btn-close"
        data-bs-dismiss="alert"
    ></button>

</div>

<?php endif; ?>


<!-- =====================================================
     PAGE HEADER
===================================================== -->

<div
    class="d-flex
    flex-wrap
    justify-content-between
    align-items-center
    mb-4"
>

    <div>

        <div class="muted small">

            Customer Management

        </div>


        <h3
            class="fw-bold mb-1"
        >

            Customers

        </h3>


        <p
            class="muted mb-0"
        >

            Manage all customers and
            payment plans.

        </p>

    </div>


    <a
        href="add_customer.php"
        class="btn btn-success
        mt-3 mt-md-0"
    >

        <i
            class="bi
            bi-person-plus-fill
            me-2"
        ></i>

        Add Customer

    </a>

</div>


<!-- =====================================================
     SUMMARY CARDS
===================================================== -->

<div
    class="row
    g-4
    mb-4"
>


    <!-- TOTAL -->

    <div
        class="col-md-6
        col-xl-3"
    >

        <div
            class="cardx
            p-4
            h-100"
        >

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div
                        class="muted small"
                    >

                        Total Customers

                    </div>


                    <h3
                        class="fw-bold
                        mt-2
                        mb-0"
                    >

                        <?= $totalCustomers ?>

                    </h3>

                </div>


                <div
                    class="iconbox"
                >

                    <i
                        class="bi
                        bi-people-fill"
                    ></i>

                </div>

            </div>

        </div>

    </div>


    <!-- ACTIVE -->

    <div
        class="col-md-6
        col-xl-3"
    >

        <div
            class="cardx
            p-4
            h-100"
        >

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div
                        class="muted small"
                    >

                        Active

                    </div>


                    <h3
                        class="fw-bold
                        mt-2
                        mb-0"
                    >

                        <?= $activeCustomers ?>

                    </h3>

                </div>


                <div
                    class="iconbox
                    text-success"
                >

                    <i
                        class="bi
                        bi-person-check-fill"
                    ></i>

                </div>

            </div>

        </div>

    </div>


    <!-- MONTHLY -->

    <div
        class="col-md-6
        col-xl-3"
    >

        <div
            class="cardx
            p-4
            h-100"
        >

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div
                        class="muted small"
                    >

                        Monthly

                    </div>


                    <h3
                        class="fw-bold
                        mt-2
                        mb-0"
                    >

                        <?= $monthlyCustomers ?>

                    </h3>

                </div>


                <div
                    class="iconbox"
                >

                    <i
                        class="bi
                        bi-calendar-month"
                    ></i>

                </div>

            </div>

        </div>

    </div>


    <!-- WEEKLY -->

    <div
        class="col-md-6
        col-xl-3"
    >

        <div
            class="cardx
            p-4
            h-100"
        >

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div
                        class="muted small"
                    >

                        Weekly

                    </div>


                    <h3
                        class="fw-bold
                        mt-2
                        mb-0"
                    >

                        <?= $weeklyCustomers ?>

                    </h3>

                </div>


                <div
                    class="iconbox"
                >

                    <i
                        class="bi
                        bi-calendar-week"
                    ></i>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =====================================================
     SEARCH + PLAN FILTER
===================================================== -->

<div
    class="cardx
    p-3
    mb-4"
>

    <form
        method="GET"
        class="row
        g-2"
    >


        <!-- SEARCH -->

        <div
            class="col-md-5"
        >

            <div
                class="input-group"
            >

                <span
                    class="input-group-text
                    bg-white"
                >

                    <i
                        class="bi
                        bi-search"
                    ></i>

                </span>


                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Search name, mobile or Aadhaar..."
                    value="<?= htmlspecialchars(
                        $search
                    ) ?>"
                >

            </div>

        </div>


        <!-- PLAN DROPDOWN -->

        <div
            class="col-md-4"
        >

            <select
                name="plan"
                class="form-select"
            >

                <option
                    value="All"
                    <?= $plan === 'All'
                        ? 'selected'
                        : '' ?>
                >

                    All Customers

                </option>


                <option
                    value="Monthly"
                    <?= $plan === 'Monthly'
                        ? 'selected'
                        : '' ?>
                >

                    Monthly

                </option>


                <option
                    value="Weekly"
                    <?= $plan === 'Weekly'
                        ? 'selected'
                        : '' ?>
                >

                    Weekly

                </option>

            </select>

        </div>


        <!-- SEARCH BUTTON -->

        <div
            class="col-md-2"
        >

            <button
                type="submit"
                class="btn
                btn-success
                w-100"
            >

                <i
                    class="bi
                    bi-funnel-fill
                    me-1"
                ></i>

                Filter

            </button>

        </div>


        <!-- CLEAR -->

        <div
            class="col-md-1"
        >

            <a
                href="customers.php"
                class="btn
                btn-light
                w-100"
                title="Clear"
            >

                <i
                    class="bi
                    bi-x-lg"
                ></i>

            </a>

        </div>


    </form>

</div>


<!-- =====================================================
     ACTIVE FILTER
===================================================== -->

<?php if ($plan !== 'All'): ?>

<div
    class="mb-3"
>

    <span
        class="badge
        rounded-pill
        text-bg-success
        px-3
        py-2"
    >

        <?php if ($plan === 'Monthly'): ?>

            <i
                class="bi
                bi-calendar-month
                me-1"
            ></i>

        <?php else: ?>

            <i
                class="bi
                bi-calendar-week
                me-1"
            ></i>

        <?php endif; ?>


        Showing
        <?= htmlspecialchars($plan) ?>
        Customers

    </span>

</div>

<?php endif; ?>


<!-- =====================================================
     CUSTOMER TABLE
===================================================== -->

<div
    class="cardx
    p-4"
>


    <div
        class="d-flex
        justify-content-between
        align-items-center
        mb-4"
    >

        <div>

            <h5
                class="fw-bold
                mb-1"
            >

                Customer List

            </h5>


            <small
                class="muted"
            >

                <?= $customers->num_rows ?>

                customer(s) found

            </small>

        </div>


        <span
            class="badge
            text-bg-success"
        >

            <?= $activeCustomers ?>

            Active

        </span>

    </div>


    <?php if (
        $customers->num_rows === 0
    ): ?>


        <!-- =================================================
             NO CUSTOMER
        ================================================== -->

        <div
            class="text-center
            py-5"
        >

            <i
                class="bi
                bi-people"
                style="font-size:50px;"
            ></i>


            <h5
                class="fw-bold
                mt-3"
            >

                No Customers Found

            </h5>


            <p
                class="muted"
            >

                <?php if (
                    $search !== ''
                    ||
                    $plan !== 'All'
                ): ?>

                    Is filter ke according
                    koi customer nahi mila.

                <?php else: ?>

                    Abhi tak koi customer
                    add nahi hua.

                <?php endif; ?>

            </p>


            <a
                href="add_customer.php"
                class="btn
                btn-success"
            >

                <i
                    class="bi
                    bi-person-plus
                    me-2"
                ></i>

                Add Customer

            </a>

        </div>


    <?php else: ?>


        <!-- =================================================
             TABLE
        ================================================== -->

        <div
            class="table-responsive"
        >

            <table
                class="table
                align-middle
                mb-0"
            >

                <thead>

                    <tr>

                        <th>
                            Customer
                        </th>

                        <th>
                            Mobile
                        </th>

                        <th>
                            Aadhaar
                        </th>

                        <th>
                            Plan
                        </th>

                        <th>
                            Amount
                        </th>

                        <th>
                            Progress
                        </th>

                        <th>
                            Status
                        </th>

                        <th
                            class="text-end"
                        >
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php while (
                    $row =
                    $customers->fetch_assoc()
                ): ?>


                    <?php

                    /* =====================================
                       INSTALLMENT TOTAL
                    ===================================== */

                    $totalInstallments =
                        (int)(
                            $row[
                                'total_installments'
                            ]
                            ??
                            (
                                $row['plan']
                                ===
                                'Weekly'
                                ? 52
                                : 12
                            )
                        );


                    /* =====================================
                       PAID
                    ===================================== */

                    $paidInstallments =
                        (int)(
                            $row[
                                'paid_installments'
                            ]
                            ??
                            0
                        );


                    /* =====================================
                       REMAINING
                    ===================================== */

                    $remaining =
                        max(
                            0,
                            $totalInstallments
                            -
                            $paidInstallments
                        );


                    /* =====================================
                       PROGRESS
                    ===================================== */

                    $progress = 0;

                    if (
                        $totalInstallments > 0
                    ) {

                        $progress =
                            (
                                $paidInstallments
                                /
                                $totalInstallments
                            )
                            *
                            100;
                    }


                    $progress =
                        min(
                            100,
                            max(
                                0,
                                $progress
                            )
                        );


                    /* =====================================
                       PLAN
                    ===================================== */

                    if (
                        $row['plan']
                        ===
                        'Monthly'
                    ) {

                        $planClass =
                            'text-bg-success';

                        $planIcon =
                            'bi-calendar-month';

                    } else {

                        $planClass =
                            'text-bg-dark';

                        $planIcon =
                            'bi-calendar-week';

                    }


                    /* =====================================
                       STATUS
                    ===================================== */

                    if (
                        $row['status']
                        ===
                        'Completed'
                    ) {

                        $statusClass =
                            'text-bg-success';

                    } else {

                        $statusClass =
                            'text-bg-warning';

                    }

                    ?>


                    <tr>


                        <!-- CUSTOMER -->

                        <td>

                            <div
                                class="d-flex
                                align-items-center"
                            >

                                <span
                                    class="avatar
                                    me-2"
                                >

                                    <?= strtoupper(
                                        substr(
                                            $row['name'],
                                            0,
                                            1
                                        )
                                    ) ?>

                                </span>


                                <div>

                                    <div
                                        class="fw-bold"
                                    >

                                        <?= htmlspecialchars(
                                            $row['name']
                                        ) ?>

                                    </div>


                                    <small
                                        class="muted"
                                    >

                                        Opened:

                                        <?php if (
                                            !empty(
                                                $row[
                                                    'opening_date'
                                                ]
                                            )
                                        ): ?>

                                            <?= date(
                                                'd M Y',
                                                strtotime(
                                                    $row[
                                                        'opening_date'
                                                    ]
                                                )
                                            ) ?>

                                        <?php else: ?>

                                            —

                                        <?php endif; ?>

                                    </small>

                                </div>

                            </div>

                        </td>


                        <!-- MOBILE -->

                        <td>

                            <?= htmlspecialchars(
                                $row['phone']
                            ) ?>

                        </td>


                        <!-- AADHAAR -->

                        <td>

                            <?php if (
                                !empty(
                                    $row['aadhaar_no']
                                )
                            ): ?>

                                <?= htmlspecialchars(
                                    $row[
                                        'aadhaar_no'
                                    ]
                                ) ?>

                            <?php else: ?>

                                <span
                                    class="muted"
                                >

                                    —

                                </span>

                            <?php endif; ?>

                        </td>


                        <!-- PLAN -->

                        <td>

                            <span
                                class="badge
                                <?= $planClass ?>"
                            >

                                <i
                                    class="bi
                                    <?= $planIcon ?>
                                    me-1"
                                ></i>

                                <?= htmlspecialchars(
                                    $row['plan']
                                ) ?>

                            </span>

                        </td>


                        <!-- AMOUNT -->

                        <td>

                            <strong>

                                ₹<?= number_format(
                                    (float)
                                    $row['amount'],
                                    2
                                ) ?>

                            </strong>


                            <div>

                                <small
                                    class="muted"
                                >

                                    Per
                                    <?= $row['plan']
                                        ===
                                        'Weekly'
                                        ? 'week'
                                        : 'month'
                                    ?>

                                </small>

                            </div>

                        </td>


                        <!-- PROGRESS -->

                        <td
                            style="min-width:160px"
                        >

                            <div
                                class="d-flex
                                justify-content-between
                                mb-1"
                            >

                                <small>

                                    <?= $paidInstallments ?>

                                    /

                                    <?= $totalInstallments ?>

                                </small>


                                <small
                                    class="muted"
                                >

                                    <?= round(
                                        $progress
                                    ) ?>%

                                </small>

                            </div>


                            <div
                                class="progress"
                                style="height:7px"
                            >

                                <div
                                    class="progress-bar
                                    bg-success"
                                    role="progressbar"
                                    style="
                                        width:
                                        <?= $progress ?>%;
                                    "
                                ></div>

                            </div>


                            <small
                                class="muted"
                            >

                                <?= $remaining ?>

                                remaining

                            </small>

                        </td>


                        <!-- STATUS -->

                        <td>

                            <span
                                class="badge
                                <?= $statusClass ?>"
                            >

                                <?= htmlspecialchars(
                                    $row['status']
                                ) ?>

                            </span>

                        </td>


                        <!-- ACTION -->

                        <td>

                            <div
                                class="d-flex
                                justify-content-end
                                gap-1"
                            >


                                <!-- PAYMENT -->

                                <a
                                    href="payment.php?id=<?= (int)$row['id'] ?>"
                                    class="btn
                                    btn-sm
                                    btn-success"
                                    title="Payment"
                                >

                                    <i
                                        class="bi
                                        bi-cash-stack"
                                    ></i>

                                </a>


                                <!-- EDIT -->

                                <a
                                    href="edit_customer.php?id=<?= (int)$row['id'] ?>"
                                    class="btn
                                    btn-sm
                                    btn-outline-primary"
                                    title="Edit"
                                >

                                    <i
                                        class="bi
                                        bi-pencil"
                                    ></i>

                                </a>


                                <!-- DELETE -->

                                <a
                                    href="delete_customer.php?id=<?= (int)$row['id'] ?>"
                                    class="btn
                                    btn-sm
                                    btn-outline-danger"
                                    title="Delete"
                                    onclick="return confirm(
                                        'WARNING!\\n\\n' +
                                        '<?= htmlspecialchars(
                                            addslashes(
                                                $row['name']
                                            )
                                        ) ?> ko delete karne par:\\n\\n' +
                                        '• Customer delete hoga\\n' +
                                        '• Saari payment/collection delete hogi\\n' +
                                        '• Customer ka account delete hoga\\n\\n' +
                                        'Kya aap sure hain?'
                                    );"
                                >

                                    <i
                                        class="bi
                                        bi-trash3"
                                    ></i>

                                </a>


                            </div>

                        </td>


                    </tr>


                <?php endwhile; ?>


                </tbody>

            </table>

        </div>


    <?php endif; ?>


</div>


<?php

include 'includes/footer.php';

?>