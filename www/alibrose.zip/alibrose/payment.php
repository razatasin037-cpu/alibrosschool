<?php

/* =====================================================
   INDIA TIMEZONE
===================================================== */

date_default_timezone_set('Asia/Kolkata');


/* =====================================================
   FILES
===================================================== */

require_once 'includes/auth.php';
require_once 'config/db.php';


$page_title = 'Customer Payment';

$error = '';
$success = '';


/* =====================================================
   CUSTOMER ID
===================================================== */

$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    die('Invalid customer ID.');
}


/* =====================================================
   GET CUSTOMER
===================================================== */

$stmt = $conn->prepare("
    SELECT *
    FROM customers
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

$customer = $result->fetch_assoc();


if (!$customer) {
    die('Customer not found.');
}


/* =====================================================
   CUSTOMER DATA
===================================================== */

$plan = $customer['plan'];

$opening_date = $customer['opening_date'];

$amount = (float)$customer['amount'];


/*
|--------------------------------------------------------------------------
| PLAN TOTAL
|--------------------------------------------------------------------------
*/

$total_installments =
    ($plan === 'Monthly') ? 12 : 52;


/* =====================================================
   FUNCTION
   GET INSTALLMENT DUE DATE
===================================================== */

function getInstallmentDueDate(
    string $openingDate,
    string $plan,
    int $installmentNo
): string {

    $opening = new DateTime(
        $openingDate,
        new DateTimeZone('Asia/Kolkata')
    );


    /* =================================================
       MONTHLY
    ================================================= */

    if ($plan === 'Monthly') {

        $day =
            (int)$opening->format('d');


        /*
        |--------------------------------------------------------------------------
        | Opening 1-10
        |--------------------------------------------------------------------------
        */

        if ($day <= 10) {

            $firstDue =
                new DateTime(
                    $opening->format('Y-m-10'),
                    new DateTimeZone('Asia/Kolkata')
                );


        /*
        |--------------------------------------------------------------------------
        | Opening 11+
        |--------------------------------------------------------------------------
        */

        } else {

            $firstDue =
                new DateTime(
                    $opening->format('Y-m-01'),
                    new DateTimeZone('Asia/Kolkata')
                );

            $firstDue->modify('+1 month');

            $firstDue->setDate(
                (int)$firstDue->format('Y'),
                (int)$firstDue->format('m'),
                10
            );
        }


        /*
        |--------------------------------------------------------------------------
        | NEXT MONTHS
        |--------------------------------------------------------------------------
        */

        if ($installmentNo > 1) {

            $months =
                $installmentNo - 1;

            $firstDue->modify(
                "+{$months} months"
            );
        }


        return $firstDue->format('Y-m-d');
    }


    /* =================================================
       WEEKLY
    ================================================= */

    $opening->modify('+7 days');


    if ($installmentNo > 1) {

        $days =
            ($installmentNo - 1) * 7;

        $opening->modify(
            "+{$days} days"
        );
    }


    return $opening->format('Y-m-d');
}


/* =====================================================
   GET PAYMENT HISTORY
===================================================== */

$historyStmt = $conn->prepare("
    SELECT
        installment_no,
        amount,
        payment_date,
        due_date,
        created_at
    FROM installment_payments
    WHERE customer_id = ?
    ORDER BY installment_no ASC
");

$historyStmt->bind_param(
    "i",
    $id
);

$historyStmt->execute();

$historyResult =
    $historyStmt->get_result();


/* =====================================================
   PAID INSTALLMENTS
===================================================== */

$paidInstallments = [];


while (
    $row =
    $historyResult->fetch_assoc()
) {

    $paidInstallments[
        (int)$row['installment_no']
    ] = $row;
}


/* =====================================================
   MAKE PAYMENT
===================================================== */

if (isset($_POST['make_payment'])) {


    /*
    |--------------------------------------------------------------------------
    | SELECTED INSTALLMENTS
    |--------------------------------------------------------------------------
    */

    $selectedInstallments =
        $_POST['installment_no'] ?? [];


    if (!is_array($selectedInstallments)) {

        $selectedInstallments = [
            $selectedInstallments
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | CLEAN
    |--------------------------------------------------------------------------
    */

    $selectedInstallments =
        array_map(
            'intval',
            $selectedInstallments
        );


    $selectedInstallments =
        array_unique(
            $selectedInstallments
        );


    sort($selectedInstallments);


    /*
    |--------------------------------------------------------------------------
    | PAYMENT DATE
    |--------------------------------------------------------------------------
    */

    $paymentDate =
        trim(
            $_POST['payment_date'] ?? ''
        );


    /* =================================================
       VALIDATION
    ================================================= */

    if (
        empty($selectedInstallments)
    ) {

        $error =
            'Please select at least one installment.';

    } elseif (
        empty($paymentDate)
    ) {

        $error =
            'Please select payment date.';

    } else {


        /*
        |--------------------------------------------------------------------------
        | DATE VALIDATION
        |--------------------------------------------------------------------------
        */

        $paymentDateObj =
            DateTime::createFromFormat(
                '!Y-m-d',
                $paymentDate,
                new DateTimeZone('Asia/Kolkata')
            );


        /*
        |--------------------------------------------------------------------------
        | CHECK DATE FORMAT
        |--------------------------------------------------------------------------
        */

        $dateErrors =
            DateTime::getLastErrors();


        /*
        |--------------------------------------------------------------------------
        | PHP VERSION SAFETY
        |--------------------------------------------------------------------------
        */

        if (
            $dateErrors !== false
            &&
            (
                $dateErrors['warning_count'] > 0
                ||
                $dateErrors['error_count'] > 0
            )
        ) {

            $paymentDateObj = false;
        }


        if (!$paymentDateObj) {

            $error =
                'Invalid payment date.';

        } else {


            /*
            |--------------------------------------------------------------------------
            | TODAY INDIA DATE
            |--------------------------------------------------------------------------
            */

            $today =
                new DateTime(
                    'today',
                    new DateTimeZone('Asia/Kolkata')
                );


            /*
            |--------------------------------------------------------------------------
            | OPENING DATE
            |--------------------------------------------------------------------------
            */

            $openingObj =
                new DateTime(
                    $opening_date,
                    new DateTimeZone('Asia/Kolkata')
                );


            /*
            |--------------------------------------------------------------------------
            | PAYMENT BEFORE OPENING
            |--------------------------------------------------------------------------
            */

            if (
                $paymentDateObj < $openingObj
            ) {

                $error =
                    'Payment date cannot be before opening date.';


            /*
            |--------------------------------------------------------------------------
            | FUTURE DATE
            |--------------------------------------------------------------------------
            */

            } elseif (
                $paymentDateObj->format('Y-m-d')
                >
                $today->format('Y-m-d')
            ) {

                $error =
                    'Payment date cannot be in the future.';

            } else {


                /*
                |--------------------------------------------------------------------------
                | VALID INSTALLMENTS
                |--------------------------------------------------------------------------
                */

                $validInstallments = [];


                foreach (
                    $selectedInstallments
                    as $installmentNo
                ) {


                    /*
                    |--------------------------------------------------------------------------
                    | RANGE
                    |--------------------------------------------------------------------------
                    */

                    if (
                        $installmentNo < 1
                        ||
                        $installmentNo >
                        $total_installments
                    ) {

                        continue;
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | ALREADY PAID
                    |--------------------------------------------------------------------------
                    */

                    if (
                        isset(
                            $paidInstallments[
                                $installmentNo
                            ]
                        )
                    ) {

                        continue;
                    }


                    $validInstallments[] =
                        $installmentNo;
                }


                /*
                |--------------------------------------------------------------------------
                | NOTHING VALID
                |--------------------------------------------------------------------------
                */

                if (
                    empty($validInstallments)
                ) {

                    $error =
                        'All selected installments are already paid.';

                } else {


                    /*
                    |--------------------------------------------------------------------------
                    | DATABASE TRANSACTION
                    |--------------------------------------------------------------------------
                    */

                    $conn->begin_transaction();


                    try {


                        /*
                        |--------------------------------------------------------------------------
                        | INSERT PAYMENT
                        |--------------------------------------------------------------------------
                        */

                        $insert =
                            $conn->prepare("
                                INSERT INTO installment_payments
                                (
                                    customer_id,
                                    installment_no,
                                    amount,
                                    payment_date,
                                    due_date
                                )
                                VALUES (?, ?, ?, ?, ?)
                            ");


                        foreach (
                            $validInstallments
                            as $installmentNo
                        ) {


                            /*
                            |--------------------------------------------------------------------------
                            | DUE DATE
                            |--------------------------------------------------------------------------
                            */

                            $dueDate =
                                getInstallmentDueDate(
                                    $opening_date,
                                    $plan,
                                    $installmentNo
                                );


                            /*
                            |--------------------------------------------------------------------------
                            | INSERT
                            |--------------------------------------------------------------------------
                            */

                            $insert->bind_param(
                                "iidss",
                                $id,
                                $installmentNo,
                                $amount,
                                $paymentDate,
                                $dueDate
                            );


                            if (
                                !$insert->execute()
                            ) {

                                throw new Exception(
                                    'Payment could not be saved.'
                                );
                            }
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | COUNT PAID
                        |--------------------------------------------------------------------------
                        */

                        $countStmt =
                            $conn->prepare("
                                SELECT
                                    COUNT(DISTINCT installment_no)
                                    AS paid
                                FROM installment_payments
                                WHERE customer_id = ?
                            ");


                        $countStmt->bind_param(
                            "i",
                            $id
                        );


                        $countStmt->execute();


                        $countResult =
                            $countStmt->get_result();


                        $countRow =
                            $countResult->fetch_assoc();


                        $paidCount =
                            (int)$countRow['paid'];


                        /*
                        |--------------------------------------------------------------------------
                        | REMAINING
                        |--------------------------------------------------------------------------
                        */

                        $remaining =
                            $total_installments
                            -
                            $paidCount;


                        /*
                        |--------------------------------------------------------------------------
                        | FIND NEXT UNPAID
                        |--------------------------------------------------------------------------
                        */

                        $nextDueDate = null;


                        for (
                            $x = 1;
                            $x <= $total_installments;
                            $x++
                        ) {


                            $checkNext =
                                $conn->prepare("
                                    SELECT id
                                    FROM installment_payments
                                    WHERE customer_id = ?
                                    AND installment_no = ?
                                    LIMIT 1
                                ");


                            $checkNext->bind_param(
                                "ii",
                                $id,
                                $x
                            );


                            $checkNext->execute();


                            $nextResult =
                                $checkNext->get_result();


                            if (
                                $nextResult->num_rows === 0
                            ) {

                                $nextDueDate =
                                    getInstallmentDueDate(
                                        $opening_date,
                                        $plan,
                                        $x
                                    );

                                break;
                            }
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | COMPLETED
                        |--------------------------------------------------------------------------
                        */

                        if (
                            $remaining <= 0
                        ) {


                            $update =
                                $conn->prepare("
                                    UPDATE customers
                                    SET
                                        total_installments = ?,
                                        paid_installments = ?,
                                        next_due_date = NULL,
                                        status = 'Completed'
                                    WHERE id = ?
                                ");


                            $update->bind_param(
                                "iii",
                                $total_installments,
                                $paidCount,
                                $id
                            );


                            if (
                                !$update->execute()
                            ) {

                                throw new Exception(
                                    'Customer could not be completed.'
                                );
                            }


                        } else {


                            /*
                            |--------------------------------------------------------------------------
                            | ACTIVE
                            |--------------------------------------------------------------------------
                            */

                            $update =
                                $conn->prepare("
                                    UPDATE customers
                                    SET
                                        total_installments = ?,
                                        paid_installments = ?,
                                        next_due_date = ?,
                                        status = 'Active'
                                    WHERE id = ?
                                ");


                            $update->bind_param(
                                "iisi",
                                $total_installments,
                                $paidCount,
                                $nextDueDate,
                                $id
                            );


                            if (
                                !$update->execute()
                            ) {

                                throw new Exception(
                                    'Customer progress could not be updated.'
                                );
                            }
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | COMMIT
                        |--------------------------------------------------------------------------
                        */

                        $conn->commit();


                        header(
                            'Location: payment.php?id='
                            . $id
                            . '&success=1'
                        );

                        exit;


                    } catch (
                        Exception $e
                    ) {


                        $conn->rollback();


                        $error =
                            'Payment failed: '
                            .
                            $e->getMessage();
                    }
                }
            }
        }
    }
}


/* =====================================================
   SUCCESS
===================================================== */

if (
    isset($_GET['success'])
) {

    $success =
        'Payment successfully recorded.';
}


/* =====================================================
   REFRESH HISTORY
===================================================== */

$historyStmt = $conn->prepare("
    SELECT
        installment_no,
        amount,
        payment_date,
        due_date,
        created_at
    FROM installment_payments
    WHERE customer_id = ?
    ORDER BY installment_no ASC
");

$historyStmt->bind_param(
    "i",
    $id
);

$historyStmt->execute();

$historyResult =
    $historyStmt->get_result();


$paidInstallments = [];


while (
    $row =
    $historyResult->fetch_assoc()
) {

    $paidInstallments[
        (int)$row['installment_no']
    ] = $row;
}


/* =====================================================
   COUNTS
===================================================== */

$paidCount =
    count($paidInstallments);


$remainingCount =
    max(
        $total_installments
        -
        $paidCount,
        0
    );


$progress =
    $total_installments > 0
    ? (
        $paidCount
        /
        $total_installments
    ) * 100
    : 0;


include 'includes/header.php';

?>


<!-- =====================================================
     PAGE HEADER
===================================================== -->

<div class="d-flex justify-content-between align-items-center mb-4">

    <div>

        <h3 class="fw-bold mb-1">
            Customer Payment
        </h3>

        <p class="muted mb-0">
            Manage installments and payment history
        </p>

    </div>


    <a
        href="customers.php"
        class="btn btn-light"
    >

        <i class="bi bi-arrow-left me-2"></i>

        Back

    </a>

</div>


<!-- =====================================================
     SUCCESS
===================================================== -->

<?php if ($success): ?>

<div class="alert alert-success">

    <i class="bi bi-check-circle-fill me-2"></i>

    <?= htmlspecialchars($success) ?>

</div>

<?php endif; ?>


<!-- =====================================================
     ERROR
===================================================== -->

<?php if ($error): ?>

<div class="alert alert-danger">

    <i
        class="bi bi-exclamation-triangle-fill me-2"
    ></i>

    <?= htmlspecialchars($error) ?>

</div>

<?php endif; ?>


<form
    method="POST"
    id="paymentForm"
>


<div class="row g-4">


<!-- =====================================================
     LEFT SIDE
===================================================== -->

<div class="col-xl-5">


    <!-- CUSTOMER -->

    <div class="cardx p-4 mb-4">


        <div class="d-flex align-items-center mb-4">

            <span class="avatar me-3">

                <?= strtoupper(
                    substr(
                        $customer['name'],
                        0,
                        1
                    )
                ) ?>

            </span>


            <div>

                <h5 class="fw-bold mb-1">

                    <?= htmlspecialchars(
                        $customer['name']
                    ) ?>

                </h5>


                <small class="muted">

                    <?= htmlspecialchars(
                        $customer['phone']
                    ) ?>

                </small>

            </div>

        </div>


        <!-- DETAILS -->

        <div class="row g-3">


            <div class="col-6">

                <div
                    class="p-3 rounded-4"
                    style="background:#f8faf9"
                >

                    <small class="muted">
                        Plan
                    </small>

                    <h5 class="fw-bold mt-1 mb-0">

                        <?= htmlspecialchars(
                            $plan
                        ) ?>

                    </h5>

                </div>

            </div>


            <div class="col-6">

                <div
                    class="p-3 rounded-4"
                    style="background:#f8faf9"
                >

                    <small class="muted">
                        Amount
                    </small>

                    <h5 class="fw-bold mt-1 mb-0">

                        ₹<?= number_format(
                            $amount,
                            2
                        ) ?>

                    </h5>

                </div>

            </div>


            <div class="col-6">

                <div
                    class="p-3 rounded-4"
                    style="background:#f8faf9"
                >

                    <small class="muted">
                        Started
                    </small>

                    <h5 class="fw-bold mt-1 mb-0">

                        <?php if (
                            !empty($opening_date)
                        ): ?>

                            <?= date(
                                'd M Y',
                                strtotime(
                                    $opening_date
                                )
                            ) ?>

                        <?php else: ?>

                            Not Set

                        <?php endif; ?>

                    </h5>

                </div>

            </div>


            <div class="col-6">

                <div
                    class="p-3 rounded-4"
                    style="background:#f8faf9"
                >

                    <small class="muted">
                        Total
                    </small>

                    <h5 class="fw-bold mt-1 mb-0">

                        <?= $total_installments ?>

                        <?= $plan === 'Monthly'
                            ? 'Months'
                            : 'Weeks'
                        ?>

                    </h5>

                </div>

            </div>

        </div>


        <!-- PROGRESS -->

        <div class="mt-4">


            <div class="d-flex justify-content-between">

                <span class="muted">
                    Payment Progress
                </span>


                <strong>

                    <?= $paidCount ?>

                    /

                    <?= $total_installments ?>

                </strong>

            </div>


            <div
                class="progress mt-2"
                style="height:9px"
            >

                <div
                    class="progress-bar bg-success"
                    style="width:<?= $progress ?>%"
                ></div>

            </div>


            <div
                class="d-flex justify-content-between mt-2"
            >

                <small class="text-success">

                    <?= round($progress) ?>% Paid

                </small>


                <small class="muted">

                    <?= $remainingCount ?>

                    <?= $plan === 'Monthly'
                        ? 'Months'
                        : 'Weeks'
                    ?>

                    Remaining

                </small>

            </div>

        </div>

    </div>


    <!-- =================================================
         PAYMENT SUMMARY
    ================================================== -->

    <div
        class="cardx p-4"
        style="position:sticky;top:90px;"
    >


        <h5 class="fw-bold mb-1">

            Payment Summary

        </h5>


        <small class="muted">

            Click + to select installments

        </small>


        <div class="mt-4">


            <div
                class="d-flex justify-content-between mb-2"
            >

                <span class="muted">

                    Selected

                </span>


                <strong id="selectedCount">

                    0

                </strong>

            </div>


            <div
                class="d-flex justify-content-between mb-3"
            >

                <span class="muted">

                    Total Payment

                </span>


                <h4
                    class="fw-bold mb-0"
                    id="totalPayment"
                >

                    ₹0.00

                </h4>

            </div>


            <!-- PAYMENT DATE -->

            <div class="mb-3">

                <label
                    class="form-label fw-semibold"
                >

                    Actual Payment Date

                </label>


                <input
                    type="date"
                    name="payment_date"
                    class="form-control"
                    value="<?= date('Y-m-d') ?>"
                    min="<?= htmlspecialchars(
                        $opening_date
                    ) ?>"
                    max="<?= date('Y-m-d') ?>"
                    required
                >


                <small class="muted">

                    Customer ne jis din actual payment
                    kiya hai wo date select karein.

                </small>

            </div>


            <!-- PAY -->

            <button
                type="submit"
                name="make_payment"
                id="payButton"
                class="btn btn-success w-100 py-3"
                disabled
            >

                <i
                    class="bi bi-check-circle-fill me-2"
                ></i>

                Pay Selected

            </button>


            <!-- CLEAR -->

            <button
                type="button"
                id="clearSelection"
                class="btn btn-light w-100 mt-2"
            >

                Clear Selection

            </button>

        </div>

    </div>

</div>


<!-- =====================================================
     RIGHT SIDE
===================================================== -->

<div class="col-xl-7">


    <div class="cardx p-4">


        <div
            class="d-flex justify-content-between
            align-items-center mb-4"
        >

            <div>

                <h5 class="fw-bold mb-1">

                    Installments

                </h5>


                <small class="muted">

                    Paid, overdue and upcoming

                </small>

            </div>


            <?php if (
                $customer['status']
                ===
                'Completed'
            ): ?>

                <span
                    class="badge text-bg-success"
                >

                    <i
                        class="bi bi-check-circle me-1"
                    ></i>

                    Completed

                </span>

            <?php endif; ?>

        </div>


        <!-- TABLE -->

        <div class="table-responsive">

            <table class="table align-middle">

                <thead>

                    <tr>

                        <th>
                            #
                        </th>

                        <th>
                            Due Date
                        </th>

                        <th>
                            Amount
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Pay
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php for (
                    $i = 1;
                    $i <= $total_installments;
                    $i++
                ): ?>


                    <?php

                    $dueDate =
                        getInstallmentDueDate(
                            $opening_date,
                            $plan,
                            $i
                        );


                    $isPaid =
                        isset(
                            $paidInstallments[$i]
                        );


                    $dueObj =
                        new DateTime(
                            $dueDate,
                            new DateTimeZone(
                                'Asia/Kolkata'
                            )
                        );


                    $todayObj =
                        new DateTime(
                            'today',
                            new DateTimeZone(
                                'Asia/Kolkata'
                            )
                        );

                    ?>


                    <tr>


                        <!-- NUMBER -->

                        <td>

                            <strong>

                                #<?= $i ?>

                            </strong>

                        </td>


                        <!-- DUE DATE -->

                        <td>

                            <?= date(
                                'd M Y',
                                strtotime(
                                    $dueDate
                                )
                            ) ?>

                        </td>


                        <!-- AMOUNT -->

                        <td>

                            <strong>

                                ₹<?= number_format(
                                    $amount,
                                    2
                                ) ?>

                            </strong>

                        </td>


                        <!-- STATUS -->

                        <td>


                            <?php if (
                                $isPaid
                            ): ?>

                                <span
                                    class="badge text-bg-success"
                                >

                                    <i
                                        class="bi bi-check-lg me-1"
                                    ></i>

                                    Paid

                                </span>


                            <?php elseif (
                                $todayObj > $dueObj
                            ): ?>

                                <span
                                    class="badge text-bg-danger"
                                >

                                    Overdue

                                </span>


                            <?php elseif (
                                $todayObj->format('Y-m-d')
                                ===
                                $dueObj->format('Y-m-d')
                            ): ?>

                                <span
                                    class="badge text-bg-warning"
                                >

                                    Due Today

                                </span>


                            <?php else: ?>

                                <span
                                    class="badge text-bg-secondary"
                                >

                                    Upcoming

                                </span>

                            <?php endif; ?>

                        </td>


                        <!-- PLUS -->

                        <td>


                            <?php if (
                                !$isPaid
                            ): ?>


                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-success add-payment"
                                    data-id="<?= $i ?>"
                                    data-amount="<?= $amount ?>"
                                >

                                    <i
                                        class="bi bi-plus-lg"
                                    ></i>

                                </button>


                                <input
                                    type="checkbox"
                                    name="installment_no[]"
                                    value="<?= $i ?>"
                                    class="d-none installment-checkbox"
                                    data-id="<?= $i ?>"
                                    data-amount="<?= $amount ?>"
                                >


                            <?php else: ?>


                                <span
                                    class="text-success"
                                >

                                    <i
                                        class="bi bi-check-circle-fill"
                                    ></i>

                                </span>


                            <?php endif; ?>


                        </td>

                    </tr>


                    <!-- PAID DETAIL -->

                    <?php if (
                        $isPaid
                    ): ?>

                    <tr>

                        <td></td>

                        <td
                            colspan="4"
                        >

                            <small class="muted">

                                Paid on

                                <strong>

                                    <?= date(
                                        'd M Y',
                                        strtotime(
                                            $paidInstallments[
                                                $i
                                            ]['payment_date']
                                        )
                                    ) ?>

                                </strong>

                            </small>

                        </td>

                    </tr>

                    <?php endif; ?>


                <?php endfor; ?>


                </tbody>

            </table>

        </div>

    </div>


    <!-- =================================================
         PAYMENT HISTORY
    ================================================== -->

    <?php if (
        $paidCount > 0
    ): ?>


    <div
        class="cardx p-4 mt-4"
    >


        <h5 class="fw-bold mb-3">

            Payment History

        </h5>


        <div class="table-responsive">

            <table class="table align-middle">

                <thead>

                    <tr>

                        <th>
                            Installment
                        </th>

                        <th>
                            Due Date
                        </th>

                        <th>
                            Paid On
                        </th>

                        <th>
                            Amount
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php foreach (
                    $paidInstallments
                    as $payment
                ): ?>


                    <tr>


                        <td>

                            <span
                                class="badge text-bg-success"
                            >

                                #<?= (int)
                                $payment[
                                    'installment_no'
                                ] ?>

                            </span>

                        </td>


                        <td>

                            <?= date(
                                'd M Y',
                                strtotime(
                                    $payment['due_date']
                                )
                            ) ?>

                        </td>


                        <td>

                            <?= date(
                                'd M Y',
                                strtotime(
                                    $payment['payment_date']
                                )
                            ) ?>

                        </td>


                        <td
                            class="fw-semibold"
                        >

                            ₹<?= number_format(
                                (float)
                                $payment['amount'],
                                2
                            ) ?>

                        </td>


                    </tr>


                <?php endforeach; ?>


                </tbody>

            </table>

        </div>

    </div>


    <?php endif; ?>


</div>

</div>

</form>


<!-- =====================================================
     JAVASCRIPT
===================================================== -->

<script>

document.addEventListener(
    'DOMContentLoaded',
    function () {


        const buttons =
            document.querySelectorAll(
                '.add-payment'
            );


        const checkboxes =
            document.querySelectorAll(
                '.installment-checkbox'
            );


        const selectedCount =
            document.getElementById(
                'selectedCount'
            );


        const totalPayment =
            document.getElementById(
                'totalPayment'
            );


        const payButton =
            document.getElementById(
                'payButton'
            );


        const clearButton =
            document.getElementById(
                'clearSelection'
            );


        /*
        |--------------------------------------------------------------------------
        | UPDATE SUMMARY
        |--------------------------------------------------------------------------
        */

        function updateSummary() {


            let count = 0;

            let total = 0;


            checkboxes.forEach(
                function (checkbox) {

                    if (
                        checkbox.checked
                    ) {

                        count++;

                        total +=
                            parseFloat(
                                checkbox.dataset.amount
                            );

                    }

                }
            );


            selectedCount.textContent =
                count;


            totalPayment.textContent =
                '₹' +
                total.toLocaleString(
                    'en-IN',
                    {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }
                );


            payButton.disabled =
                count === 0;


            if (
                count > 0
            ) {

                payButton.innerHTML =
                    '<i class="bi bi-check-circle-fill me-2"></i>' +
                    'Pay ₹' +
                    total.toLocaleString(
                        'en-IN',
                        {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        }
                    );

            } else {

                payButton.innerHTML =
                    '<i class="bi bi-check-circle-fill me-2"></i>' +
                    'Pay Selected';

            }

        }


        /*
        |--------------------------------------------------------------------------
        | PLUS BUTTON
        |--------------------------------------------------------------------------
        */

        buttons.forEach(
            function (button) {

                button.addEventListener(
                    'click',
                    function () {


                        const id =
                            this.dataset.id;


                        const checkbox =
                            document.querySelector(
                                '.installment-checkbox[data-id="' +
                                id +
                                '"]'
                            );


                        if (!checkbox) {
                            return;
                        }


                        checkbox.checked =
                            !checkbox.checked;


                        if (
                            checkbox.checked
                        ) {


                            this.classList.remove(
                                'btn-outline-success'
                            );


                            this.classList.add(
                                'btn-success'
                            );


                            this.innerHTML =
                                '<i class="bi bi-check-lg"></i>';


                        } else {


                            this.classList.remove(
                                'btn-success'
                            );


                            this.classList.add(
                                'btn-outline-success'
                            );


                            this.innerHTML =
                                '<i class="bi bi-plus-lg"></i>';

                        }


                        updateSummary();

                    }
                );

            }
        );


        /*
        |--------------------------------------------------------------------------
        | CLEAR SELECTION
        |--------------------------------------------------------------------------
        */

        clearButton.addEventListener(
            'click',
            function () {


                checkboxes.forEach(
                    function (checkbox) {

                        checkbox.checked =
                            false;

                    }
                );


                buttons.forEach(
                    function (button) {

                        button.classList.remove(
                            'btn-success'
                        );


                        button.classList.add(
                            'btn-outline-success'
                        );


                        button.innerHTML =
                            '<i class="bi bi-plus-lg"></i>';

                    }
                );


                updateSummary();

            }
        );


        /*
        |--------------------------------------------------------------------------
        | FORM CONFIRM
        |--------------------------------------------------------------------------
        */

        document
            .getElementById('paymentForm')
            .addEventListener(
                'submit',
                function (event) {


                    const selected =
                        document.querySelectorAll(
                            '.installment-checkbox:checked'
                        );


                    if (
                        selected.length === 0
                    ) {

                        event.preventDefault();

                        alert(
                            'Please select at least one installment.'
                        );

                        return;

                    }


                    let amount = 0;


                    selected.forEach(
                        function (item) {

                            amount +=
                                parseFloat(
                                    item.dataset.amount
                                );

                        }
                    );


                    const confirmed =
                        confirm(
                            'Confirm payment of ₹' +
                            amount.toLocaleString(
                                'en-IN',
                                {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                }
                            ) +
                            ' for ' +
                            selected.length +
                            ' installment(s)?'
                        );


                    if (!confirmed) {

                        event.preventDefault();

                    }

                }
            );


    }
);

</script>


<?php

include 'includes/footer.php';

?>