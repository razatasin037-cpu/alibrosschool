<?php

date_default_timezone_set('Asia/Kolkata');

require_once 'includes/auth.php';
require_once 'config/db.php';

$page_title = 'Collection Details';


/* =====================================================
   PLAN
===================================================== */

$plan = $_GET['plan'] ?? 'Monthly';

if (
    $plan !== 'Monthly'
    &&
    $plan !== 'Weekly'
) {
    $plan = 'Monthly';
}


/* =====================================================
   CURRENT MONTH
===================================================== */

$currentMonth = date('Y-m');

$currentMonthName = date('F Y');


/* =====================================================
   CURRENT MONTH SUMMARY
===================================================== */

$summaryStmt = $conn->prepare("
    SELECT
        COUNT(ip.id) AS total_payments,
        COALESCE(
            SUM(ip.amount),
            0
        ) AS total_amount
    FROM installment_payments ip
    INNER JOIN customers c
        ON c.id = ip.customer_id
    WHERE c.plan = ?
    AND DATE_FORMAT(
        ip.payment_date,
        '%Y-%m'
    ) = ?
");

$summaryStmt->bind_param(
    "ss",
    $plan,
    $currentMonth
);

$summaryStmt->execute();

$summary =
    $summaryStmt
    ->get_result()
    ->fetch_assoc();


$totalPayments =
    (int)$summary['total_payments'];

$totalCollection =
    (float)$summary['total_amount'];


/* =====================================================
   CURRENT MONTH CUSTOMER DETAILS
===================================================== */

$detailsStmt = $conn->prepare("
    SELECT
        c.id,
        c.name,
        c.phone,
        ip.installment_no,
        ip.amount,
        ip.due_date,
        ip.payment_date

    FROM installment_payments ip

    INNER JOIN customers c
        ON c.id = ip.customer_id

    WHERE c.plan = ?

    AND DATE_FORMAT(
        ip.payment_date,
        '%Y-%m'
    ) = ?

    ORDER BY
        ip.payment_date DESC,
        c.name ASC,
        ip.installment_no ASC
");

$detailsStmt->bind_param(
    "ss",
    $plan,
    $currentMonth
);

$detailsStmt->execute();

$details =
    $detailsStmt->get_result();


include 'includes/header.php';

?>


<!-- =====================================================
     HEADER
===================================================== -->

<div
    class="d-flex
    justify-content-between
    align-items-center
    mb-4"
>

    <div>

        <div class="muted small">
            Current Month Collection
        </div>

        <h3 class="fw-bold mb-1">

            <?= htmlspecialchars($plan) ?>

            Collection

        </h3>

        <p class="muted mb-0">

            <?= $currentMonthName ?>

            payment details

        </p>

    </div>


    <a
        href="dashboard.php"
        class="btn btn-light"
    >

        <i
            class="bi bi-arrow-left me-2"
        ></i>

        Dashboard

    </a>

</div>


<!-- =====================================================
     SUMMARY CARDS
===================================================== -->

<div class="row g-4 mb-4">


    <!-- COLLECTION -->

    <div class="col-md-6">

        <div class="cardx p-4 h-100">

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div class="muted small">

                        <?= htmlspecialchars($plan) ?>

                        Collection

                    </div>

                    <h2
                        class="fw-bold mt-2 mb-1"
                    >

                        ₹<?= number_format(
                            $totalCollection,
                            2
                        ) ?>

                    </h2>

                    <small class="text-success">

                        <?= $currentMonthName ?>

                    </small>

                </div>


                <div class="iconbox">

                    <?php if (
                        $plan === 'Monthly'
                    ): ?>

                        <i
                            class="bi bi-calendar-month"
                        ></i>

                    <?php else: ?>

                        <i
                            class="bi bi-calendar-week"
                        ></i>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>


    <!-- PAYMENTS -->

    <div class="col-md-6">

        <div class="cardx p-4 h-100">

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div class="muted small">

                        Total Payments

                    </div>

                    <h2
                        class="fw-bold mt-2 mb-1"
                    >

                        <?= $totalPayments ?>

                    </h2>

                    <small class="muted">

                        Received this month

                    </small>

                </div>


                <div class="iconbox">

                    <i
                        class="bi bi-receipt"
                    ></i>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =====================================================
     PLAN SWITCH
===================================================== -->

<div class="cardx p-3 mb-4">

    <div
        class="d-flex
        flex-wrap
        justify-content-between
        align-items-center"
    >

        <div>

            <h6 class="fw-bold mb-1">

                Collection Type

            </h6>

            <small class="muted">

                Current month only

            </small>

        </div>


        <div
            class="btn-group
            mt-2 mt-md-0"
        >


            <a
                href="collection_details.php?plan=Monthly"
                class="btn
                <?= $plan === 'Monthly'
                    ? 'btn-success'
                    : 'btn-outline-success'
                ?>"
            >

                <i
                    class="bi bi-calendar-month me-1"
                ></i>

                Monthly

            </a>


            <a
                href="collection_details.php?plan=Weekly"
                class="btn
                <?= $plan === 'Weekly'
                    ? 'btn-success'
                    : 'btn-outline-success'
                ?>"
            >

                <i
                    class="bi bi-calendar-week me-1"
                ></i>

                Weekly

            </a>

        </div>

    </div>

</div>


<!-- =====================================================
     CURRENT MONTH DETAILS
===================================================== -->

<div class="cardx p-4">


    <div
        class="d-flex
        justify-content-between
        align-items-center
        mb-4"
    >

        <div>

            <h5 class="fw-bold mb-1">

                <?= $currentMonthName ?>

                Payment Details

            </h5>

            <small class="muted">

                Customer-wise payment collection

            </small>

        </div>


        <span
            class="badge text-bg-success"
        >

            <?= $totalPayments ?>

            Payments

        </span>

    </div>


    <?php if (
        $details->num_rows === 0
    ): ?>


        <!-- NO PAYMENT -->

        <div
            class="text-center
            py-5"
        >

            <i
                class="bi bi-receipt-cutoff"
                style="font-size:48px;"
            ></i>

            <h5
                class="fw-bold mt-3"
            >

                No Payment Received

            </h5>

            <p class="muted mb-0">

                <?= $currentMonthName ?>

                me abhi tak koi payment
                receive nahi hui.

            </p>

        </div>


    <?php else: ?>


        <!-- PAYMENT TABLE -->

        <div class="table-responsive">

            <table
                class="table
                align-middle"
            >

                <thead>

                    <tr>

                        <th>
                            Customer
                        </th>

                        <th>
                            Phone
                        </th>

                        <th>
                            Installment
                        </th>

                        <th>
                            Due Date
                        </th>

                        <th>
                            Paid On
                        </th>

                        <th>
                            Amount
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php while (
                    $row =
                    $details->fetch_assoc()
                ): ?>


                    <tr>


                        <!-- CUSTOMER -->

                        <td>

                            <div
                                class="d-flex
                                align-items-center"
                            >

                                <span
                                    class="avatar me-2"
                                >

                                    <?= strtoupper(
                                        substr(
                                            $row['name'],
                                            0,
                                            1
                                        )
                                    ) ?>

                                </span>


                                <strong>

                                    <?= htmlspecialchars(
                                        $row['name']
                                    ) ?>

                                </strong>

                            </div>

                        </td>


                        <!-- PHONE -->

                        <td>

                            <?= htmlspecialchars(
                                $row['phone']
                            ) ?>

                        </td>


                        <!-- INSTALLMENT -->

                        <td>

                            <span
                                class="badge
                                text-bg-secondary"
                            >

                                #<?= (int)
                                $row[
                                    'installment_no'
                                ] ?>

                            </span>

                        </td>


                        <!-- DUE DATE -->

                        <td>

                            <?php if (
                                !empty(
                                    $row['due_date']
                                )
                            ): ?>

                                <?= date(
                                    'd M Y',
                                    strtotime(
                                        $row['due_date']
                                    )
                                ) ?>

                            <?php else: ?>

                                —

                            <?php endif; ?>

                        </td>


                        <!-- PAID DATE -->

                        <td>

                            <?php if (
                                !empty(
                                    $row['payment_date']
                                )
                            ): ?>

                                <?= date(
                                    'd M Y',
                                    strtotime(
                                        $row['payment_date']
                                    )
                                ) ?>

                            <?php else: ?>

                                —

                            <?php endif; ?>

                        </td>


                        <!-- AMOUNT -->

                        <td>

                            <strong
                                class="text-success"
                            >

                                ₹<?= number_format(
                                    (float)
                                    $row['amount'],
                                    2
                                ) ?>

                            </strong>

                        </td>


                    </tr>


                <?php endwhile; ?>


                </tbody>

            </table>

        </div>


    <?php endif; ?>


</div>


<?php

include 'includes/footer.php';

?>