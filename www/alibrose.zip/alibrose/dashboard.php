<?php

date_default_timezone_set('Asia/Kolkata');

require_once 'includes/auth.php';
require_once 'config/db.php';

$page_title = 'Dashboard';


/* =====================================================
   TOTAL CUSTOMERS
===================================================== */

$customers = (int)$conn->query("
    SELECT COUNT(*) AS total
    FROM customers
")->fetch_assoc()['total'];


/* =====================================================
   TOTAL ACCOUNTS
===================================================== */

$accounts = (int)$conn->query("
    SELECT COUNT(*) AS total
    FROM accounts
")->fetch_assoc()['total'];


/* =====================================================
   COMPLETED CUSTOMERS
===================================================== */

$completed = (int)$conn->query("
    SELECT COUNT(*) AS total
    FROM customers
    WHERE status = 'Completed'
")->fetch_assoc()['total'];


/* =====================================================
   ACTIVE CUSTOMERS
===================================================== */

$activeCustomers = (int)$conn->query("
    SELECT COUNT(*) AS total
    FROM customers
    WHERE status = 'Active'
")->fetch_assoc()['total'];


/* =====================================================
   CURRENT MONTH
===================================================== */

$currentMonth = date('Y-m');

$currentMonthName = date('F Y');


/* =====================================================
   MONTHLY COLLECTION
===================================================== */

$monthlyStmt = $conn->prepare("
    SELECT
        COUNT(ip.id) AS total_payments,
        COALESCE(
            SUM(ip.amount),
            0
        ) AS total_amount

    FROM installment_payments ip

    INNER JOIN customers c
        ON c.id = ip.customer_id

    WHERE c.plan = 'Monthly'

    AND DATE_FORMAT(
        ip.payment_date,
        '%Y-%m'
    ) = ?
");

$monthlyStmt->bind_param(
    "s",
    $currentMonth
);

$monthlyStmt->execute();

$monthlyData =
    $monthlyStmt
    ->get_result()
    ->fetch_assoc();


$monthlyCollection =
    (float)$monthlyData['total_amount'];

$monthlyPayments =
    (int)$monthlyData['total_payments'];


/* =====================================================
   WEEKLY COLLECTION
===================================================== */

$weeklyStmt = $conn->prepare("
    SELECT
        COUNT(ip.id) AS total_payments,
        COALESCE(
            SUM(ip.amount),
            0
        ) AS total_amount

    FROM installment_payments ip

    INNER JOIN customers c
        ON c.id = ip.customer_id

    WHERE c.plan = 'Weekly'

    AND DATE_FORMAT(
        ip.payment_date,
        '%Y-%m'
    ) = ?
");

$weeklyStmt->bind_param(
    "s",
    $currentMonth
);

$weeklyStmt->execute();

$weeklyData =
    $weeklyStmt
    ->get_result()
    ->fetch_assoc();


$weeklyCollection =
    (float)$weeklyData['total_amount'];

$weeklyPayments =
    (int)$weeklyData['total_payments'];


/* =====================================================
   TOTAL CURRENT MONTH COLLECTION
===================================================== */

$totalCollection =
    $monthlyCollection +
    $weeklyCollection;


/* =====================================================
   ACTIVE ACCOUNT BALANCE
===================================================== */

$balance = (float)$conn->query("
    SELECT
        COALESCE(
            SUM(balance),
            0
        ) AS total

    FROM accounts

    WHERE status = 'Active'
")->fetch_assoc()['total'];


/* =====================================================
   MONTHLY DUE
=====================================================

   Due tab count hoga jab:
   - Customer Active hai
   - Monthly plan hai
   - next_due_date aa chuki hai

===================================================== */

$monthlyDue = (int)$conn->query("
    SELECT COUNT(*) AS total

    FROM customers

    WHERE plan = 'Monthly'

    AND status = 'Active'

    AND next_due_date IS NOT NULL

    AND next_due_date <= CURDATE()
")->fetch_assoc()['total'];


/* =====================================================
   WEEKLY DUE
===================================================== */

$weeklyDue = (int)$conn->query("
    SELECT COUNT(*) AS total

    FROM customers

    WHERE plan = 'Weekly'

    AND status = 'Active'

    AND next_due_date IS NOT NULL

    AND next_due_date <= CURDATE()
")->fetch_assoc()['total'];


/* =====================================================
   MONTHLY CUSTOMERS
===================================================== */

$monthlyCustomers = (int)$conn->query("
    SELECT COUNT(*) AS total
    FROM customers
    WHERE plan = 'Monthly'
")->fetch_assoc()['total'];


/* =====================================================
   WEEKLY CUSTOMERS
===================================================== */

$weeklyCustomers = (int)$conn->query("
    SELECT COUNT(*) AS total
    FROM customers
    WHERE plan = 'Weekly'
")->fetch_assoc()['total'];


/* =====================================================
   TOTAL REMAINING INSTALLMENTS
===================================================== */

$remainingStmt = $conn->query("
    SELECT
        COALESCE(
            SUM(
                GREATEST(
                    total_installments
                    -
                    paid_installments,
                    0
                )
            ),
            0
        ) AS total

    FROM customers

    WHERE status = 'Active'
");

$remainingInstallments =
    (int)$remainingStmt
    ->fetch_assoc()['total'];


include 'includes/header.php';

?>


<!-- =====================================================
     HERO
===================================================== -->

<div class="hero mb-4">

    <div
        class="position-relative"
        style="z-index:1"
    >

        <div class="small opacity-75">

            Welcome back, Admin

        </div>


        <h2 class="fw-bold mt-2">

            Banking Dashboard

        </h2>


        <p class="mb-0 opacity-75">

            Manage customers, accounts and
            collections from one place.

        </p>

    </div>

</div>


<!-- =====================================================
     TOP CARDS
===================================================== -->

<div class="row g-4 mb-4">


    <!-- TOTAL CUSTOMERS -->

    <div class="col-md-6 col-xl-3">

        <div class="cardx stat p-4 h-100">

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div class="muted small">

                        Total Customers

                    </div>


                    <div class="amount mt-2">

                        <?= $customers ?>

                    </div>


                    <small class="text-success">

                        <?= $activeCustomers ?>

                        Active

                    </small>

                </div>


                <div class="iconbox">

                    <i class="bi bi-people-fill"></i>

                </div>

            </div>

        </div>

    </div>


    <!-- TOTAL ACCOUNTS -->

    <div class="col-md-6 col-xl-3">

        <div class="cardx stat p-4 h-100">

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div class="muted small">

                        Total Accounts

                    </div>


                    <div class="amount mt-2">

                        <?= $accounts ?>

                    </div>


                    <small class="text-success">

                        Bank Accounts

                    </small>

                </div>


                <div class="iconbox">

                    <i
                        class="bi
                        bi-credit-card-2-front-fill"
                    ></i>

                </div>

            </div>

        </div>

    </div>


    <!-- MONTHLY COLLECTION -->

    <div class="col-md-6 col-xl-3">

        <div class="cardx stat p-4 h-100">

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div class="muted small">

                        Monthly Collection

                    </div>


                    <div class="amount mt-2">

                        ₹<?= number_format(
                            $monthlyCollection,
                            2
                        ) ?>

                    </div>


                    <small class="text-success">

                        <?= $monthlyPayments ?>

                        payments

                    </small>

                </div>


                <div class="iconbox">

                    <i
                        class="bi
                        bi-calendar-month"
                    ></i>

                </div>

            </div>


            <a
                href="collection_details.php?plan=Monthly"
                class="btn
                btn-sm
                btn-outline-success
                mt-3
                w-100"
            >

                View Details

                <i
                    class="bi
                    bi-arrow-right
                    ms-1"
                ></i>

            </a>

        </div>

    </div>


    <!-- WEEKLY COLLECTION -->

    <div class="col-md-6 col-xl-3">

        <div class="cardx stat p-4 h-100">

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div class="muted small">

                        Weekly Collection

                    </div>


                    <div class="amount mt-2">

                        ₹<?= number_format(
                            $weeklyCollection,
                            2
                        ) ?>

                    </div>


                    <small class="text-success">

                        <?= $weeklyPayments ?>

                        payments

                    </small>

                </div>


                <div class="iconbox">

                    <i
                        class="bi
                        bi-calendar-week"
                    ></i>

                </div>

            </div>


            <a
                href="collection_details.php?plan=Weekly"
                class="btn
                btn-sm
                btn-outline-success
                mt-3
                w-100"
            >

                View Details

                <i
                    class="bi
                    bi-arrow-right
                    ms-1"
                ></i>

            </a>

        </div>

    </div>

</div>


<!-- =====================================================
     DUE PAYMENT CARDS
===================================================== -->

<div class="row g-4 mb-4">


    <!-- MONTHLY DUE -->

    <div class="col-md-6 col-xl-3">

        <div
            class="cardx p-4 h-100"
            style="
                border-left:
                4px solid #f59e0b;
            "
        >

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div class="muted small">

                        Monthly Due

                    </div>


                    <h2
                        class="fw-bold mt-2 mb-1"
                    >

                        <?= $monthlyDue ?>

                    </h2>


                    <small class="text-warning">

                        Payment pending

                    </small>

                </div>


                <div
                    class="iconbox"
                    style="
                        color:#f59e0b;
                    "
                >

                    <i
                        class="bi
                        bi-exclamation-circle"
                    ></i>

                </div>

            </div>


            <a
                href="customers.php?plan=Monthly&due=1"
                class="btn
                btn-sm
                btn-outline-warning
                mt-3
                w-100"
            >

                View Due Customers

                <i
                    class="bi
                    bi-arrow-right
                    ms-1"
                ></i>

            </a>

        </div>

    </div>


    <!-- WEEKLY DUE -->

    <div class="col-md-6 col-xl-3">

        <div
            class="cardx p-4 h-100"
            style="
                border-left:
                4px solid #f59e0b;
            "
        >

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div class="muted small">

                        Weekly Due

                    </div>


                    <h2
                        class="fw-bold mt-2 mb-1"
                    >

                        <?= $weeklyDue ?>

                    </h2>


                    <small class="text-warning">

                        Payment pending

                    </small>

                </div>


                <div
                    class="iconbox"
                    style="
                        color:#f59e0b;
                    "
                >

                    <i
                        class="bi
                        bi-exclamation-circle"
                    ></i>

                </div>

            </div>


            <a
                href="customers.php?plan=Weekly&due=1"
                class="btn
                btn-sm
                btn-outline-warning
                mt-3
                w-100"
            >

                View Due Customers

                <i
                    class="bi
                    bi-arrow-right
                    ms-1"
                ></i>

            </a>

        </div>

    </div>


    <!-- COMPLETED -->

    <div class="col-md-6 col-xl-3">

        <div class="cardx p-4 h-100">

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div class="muted small">

                        Completed Plans

                    </div>


                    <h2
                        class="fw-bold mt-2 mb-1"
                    >

                        <?= $completed ?>

                    </h2>


                    <small class="text-success">

                        Fully completed

                    </small>

                </div>


                <div class="iconbox">

                    <i
                        class="bi
                        bi-check-circle-fill"
                    ></i>

                </div>

            </div>

        </div>

    </div>


    <!-- REMAINING -->

    <div class="col-md-6 col-xl-3">

        <div class="cardx p-4 h-100">

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <div class="muted small">

                        Remaining Payments

                    </div>


                    <h2
                        class="fw-bold mt-2 mb-1"
                    >

                        <?= $remainingInstallments ?>

                    </h2>


                    <small class="muted">

                        Active customers

                    </small>

                </div>


                <div class="iconbox">

                    <i
                        class="bi
                        bi-hourglass-split"
                    ></i>

                </div>

            </div>

        </div>

    </div>

</div>


<!-- =====================================================
     CURRENT MONTH COLLECTION
===================================================== -->

<div class="cardx p-4 mb-4">

    <div
        class="d-flex
        justify-content-between
        align-items-center"
    >

        <div>

            <div class="muted small">

                Current Month Collection

            </div>


            <h2
                class="fw-bold mt-2 mb-1"
            >

                ₹<?= number_format(
                    $totalCollection,
                    2
                ) ?>

            </h2>


            <small class="muted">

                <?= $currentMonthName ?>

            </small>

        </div>


        <div class="iconbox">

            <i
                class="bi
                bi-cash-stack"
            ></i>

        </div>

    </div>


    <div class="row g-3 mt-3">


        <!-- MONTHLY -->

        <div class="col-md-6">

            <div
                class="p-3 rounded-4"
                style="
                    background:#f0fdf4;
                    border:
                    1px solid #dcfce7;
                "
            >

                <div class="muted small">

                    Monthly

                </div>


                <h4
                    class="fw-bold
                    mt-1
                    mb-0"
                >

                    ₹<?= number_format(
                        $monthlyCollection,
                        2
                    ) ?>

                </h4>


                <small class="muted">

                    <?= $monthlyPayments ?>

                    payments

                </small>

            </div>

        </div>


        <!-- WEEKLY -->

        <div class="col-md-6">

            <div
                class="p-3 rounded-4"
                style="
                    background:#f0fdf4;
                    border:
                    1px solid #dcfce7;
                "
            >

                <div class="muted small">

                    Weekly

                </div>


                <h4
                    class="fw-bold
                    mt-1
                    mb-0"
                >

                    ₹<?= number_format(
                        $weeklyCollection,
                        2
                    ) ?>

                </h4>


                <small class="muted">

                    <?= $weeklyPayments ?>

                    payments

                </small>

            </div>

        </div>

    </div>

</div>


<!-- =====================================================
     MONTHLY / WEEKLY PLAN
===================================================== -->

<div class="row g-4 mb-4">


    <!-- MONTHLY PLAN -->

    <div class="col-lg-6">

        <div class="cardx p-4 h-100">

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <h5 class="fw-bold">

                        Monthly Plan

                    </h5>


                    <small class="muted">

                        12 month payment plan

                    </small>

                </div>


                <div class="iconbox">

                    <i
                        class="bi
                        bi-calendar-month"
                    ></i>

                </div>

            </div>


            <div class="row mt-4">


                <div class="col-6">

                    <div class="muted small">

                        Customers

                    </div>


                    <h4 class="fw-bold">

                        <?= $monthlyCustomers ?>

                    </h4>

                </div>


                <div class="col-6">

                    <div class="muted small">

                        This Month

                    </div>


                    <h4 class="fw-bold">

                        ₹<?= number_format(
                            $monthlyCollection,
                            2
                        ) ?>

                    </h4>

                </div>

            </div>


            <div class="row mt-2">


                <div class="col-6">

                    <div class="muted small">

                        Due

                    </div>


                    <h5
                        class="fw-bold
                        text-warning"
                    >

                        <?= $monthlyDue ?>

                    </h5>

                </div>


                <div class="col-6">

                    <div class="muted small">

                        Payments

                    </div>


                    <h5 class="fw-bold">

                        <?= $monthlyPayments ?>

                    </h5>

                </div>

            </div>


            <a
                href="collection_details.php?plan=Monthly"
                class="btn
                btn-outline-success
                mt-3"
            >

                View Monthly Details

                <i
                    class="bi
                    bi-arrow-right
                    ms-1"
                ></i>

            </a>

        </div>

    </div>


    <!-- WEEKLY PLAN -->

    <div class="col-lg-6">

        <div class="cardx p-4 h-100">

            <div
                class="d-flex
                justify-content-between"
            >

                <div>

                    <h5 class="fw-bold">

                        Weekly Plan

                    </h5>


                    <small class="muted">

                        52 week payment plan

                    </small>

                </div>


                <div class="iconbox">

                    <i
                        class="bi
                        bi-calendar-week"
                    ></i>

                </div>

            </div>


            <div class="row mt-4">


                <div class="col-6">

                    <div class="muted small">

                        Customers

                    </div>


                    <h4 class="fw-bold">

                        <?= $weeklyCustomers ?>

                    </h4>

                </div>


                <div class="col-6">

                    <div class="muted small">

                        This Month

                    </div>


                    <h4 class="fw-bold">

                        ₹<?= number_format(
                            $weeklyCollection,
                            2
                        ) ?>

                    </h4>

                </div>

            </div>


            <div class="row mt-2">


                <div class="col-6">

                    <div class="muted small">

                        Due

                    </div>


                    <h5
                        class="fw-bold
                        text-warning"
                    >

                        <?= $weeklyDue ?>

                    </h5>

                </div>


                <div class="col-6">

                    <div class="muted small">

                        Payments

                    </div>


                    <h5 class="fw-bold">

                        <?= $weeklyPayments ?>

                    </h5>

                </div>

            </div>


            <a
                href="collection_details.php?plan=Weekly"
                class="btn
                btn-outline-success
                mt-3"
            >

                View Weekly Details

                <i
                    class="bi
                    bi-arrow-right
                    ms-1"
                ></i>

            </a>

        </div>

    </div>

</div>


<!-- =====================================================
     QUICK ACTION
===================================================== -->

<div class="cardx p-4">

    <div
        class="d-flex
        justify-content-between
        align-items-center"
    >

        <div>

            <h5 class="fw-bold mb-1">

                Quick Action

            </h5>


            <small class="muted">

                Add a new customer to start
                a payment plan.

            </small>

        </div>


        <a
            href="add_customer.php"
            class="btn btn-success"
        >

            <i
                class="bi
                bi-person-plus-fill
                me-2"
            ></i>

            Add Customer

        </a>

    </div>

</div>


<?php

include 'includes/footer.php';

?>